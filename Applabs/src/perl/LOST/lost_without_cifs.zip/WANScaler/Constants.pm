package WANScaler::Constants;
use Exporter;
use vars qw(@EXPORT @ISA);
our @ISA = qw/Exporter/;
use constant TRUE 	=> 1;
use constant FALSE 	=> 0;
our @EXPORT = (TRUE,FALSE);
1;