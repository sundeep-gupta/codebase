<?
   include("includes/header.php");
   $Auth->CheckRights(AUTH_LEVEL_ADMIN);
?>

<font class="pageheading">Configure Settings: Tuning</font><BR><BR>

<?
      //
      // Get the acceleration by ip mode      
      if (isset($_GET["AccelIPsMode"])){
         $AccelMode = (int)$_GET["AccelIPsMode"];
         $CurAccelIPs = GetParameter("Acceleration.AcceleratedIPs");
         if ($AccelMode == 1){
            if (sizeof ($CurAccelIPs)>0 && MSG_BOX::Ask("Question?", "Are you sure you wish to clear all IP/Mask acceleration entries?") == MSG_BOX_YES){
               SetParameter("Acceleration.AcceleratedIPs", array() );
            }else{
               echo HTML::InsertRedirect("tuning.php", 0);
            }
         }else{
            SetParameter("Acceleration.OnlyAccelIPsOnList", $AccelMode==2);
         }         
      }

	  if (isset($_GET["WccpServiceGroupId"])) {
	     SetParameter("WCCP.WccpServiceGroupId",$_GET["WccpServiceGroupId"]);
	  }
	  $OrginalWccpServiceGroupId = GetParameter("WCCP.WccpServiceGroupId");
?>

<Script>
<!--
   function onWccpUpdate() {
      if(ValidateWccpServiceId(document.wccp))
      {
         var subform=document.wccp;
         subform.submit();
      }
   }

   function ValidateWccpServiceId(TheForm) {
      if (parseInt(TheForm.WccpServiceGroupId.value)+"" != TheForm.WccpServiceGroupId.value) {
         alert("Service Group Id must be an integer.");
		 TheForm.WccpServiceGroupId.value = <?=$OrginalWccpServiceGroupId?>;
         return false;
      }
      if (TheForm.WccpServiceGroupId.value > 255) {
         alert("Service Group Id must not exceed 255");
		 TheForm.WccpServiceGroupId.value = <?=$OrginalWccpServiceGroupId?>;
         return false;
      }
      if (TheForm.WccpServiceGroupId.value <= 50) {
         alert("Service Group Id must be greater than 50.");
		 TheForm.WccpServiceGroupId.value = <?=$OrginalWccpServiceGroupId?>;
         return false;
      }
	  
      return true;
   }
// -->
</Script>

<TABLE class="settings_table">
   <TR>
   <TH>
      Window Settings:
   </TH>

   <TD>

      <?
            //
            // Set the Window Size:
            //      9 - 512K
            //     10 - 1M
            //     11 - 2M
            //     ...
            if ( isset($_GET["LanScaleLimit"]) )
            {
               $SlowWindowShift = $_GET["WanScaleLimit"];
               SetParameter("Tcp.SlowWindowSize", pow (2, $SlowWindowShift)-1 );

               $FastWindowShift = $_GET["LanScaleLimit"];
               SetParameter("Tcp.FastWindowSize", pow (2, $FastWindowShift)-1 );
            }
            else
            {
               $SlowWindowSize = GetParameter("Tcp.SlowWindowSize");
               $SlowWindowShift = (int)log10( base_convert($SlowWindowSize+1, 10, 2) );

               $FastWindowSize = GetParameter("Tcp.FastWindowSize");
               $FastWindowShift = (int)log10( base_convert($FastWindowSize+1, 10, 2) );
            }

      ?>

      <FORM>
            <TABLE class=no_bg_color>
               <TR>
                  <TD>
                     WAN Scale Limit:
                  </TD>

                  <TD align=left>

                  <?
                     $ScalingVals = array();
                     for ($i=10; $i<=27; $i++)
                     {
                        array_push($ScalingVals, $i);
                     }
                     echo HTML_FORM::AddDropdown("WanScaleLimit", $ScalingVals, $ScalingVals, $SlowWindowShift-10);
                  ?>
                 </TD>
               </TR>
               <TR>
                  <TD>
                     LAN Scale Limit:
                  </TD>

                  <TD>

                  <?
                     $ScalingVals = array();
                     for ($i=10; $i<=20; $i++)
                     {
                        array_push($ScalingVals, $i);
                     }
                     echo HTML_FORM::AddDropdown("LanScaleLimit", $ScalingVals, $ScalingVals, $FastWindowShift-10);
                  ?>
               </TD>
             </TR>

            <TR>
               <TD></TD>
               <TD>
                  <?=HTML_FORM::AddSubmit();?>
               </TD>
            </TR>
         </TABLE>
      </FORM>
      </TD>
   </TD>
   </TR>
   
   <!-- Connection Timeouts -->
   <TR>
   <TH>
      Connection Timeout:
   </TH>
   <TD>

   <?
      $Table = new HTML_TABLE();
      $ParamForm = new HTML_PARAMETER_FORM();
      echo 
         "<TABLE class=no_bg_color>",
         $ParamForm->Begin("ConnectionTimeout"),
         "<TR>",
            "<TD>Idle Connection Timeout:</TD>" ,
            "<TD>", $ParamForm->AddTextParam("Tcp.FullyOpenOrphanTime", 15) . "</TD>",
         "</TR>",
         "<TR>",
            "<TD></TD>" ,
            "<TD>", $ParamForm->AddSubmit() . "</TD>",
         "</TR>",
         $ParamForm->End(),
         "</TABLE>";
   ?>
   
   </TD>
   </TR>

   <!-- Accelerated/Unaccelerated Ports -->
   <!--
   <TR>
   <TH>
      Accelerated Ports:
   </TH>
   <TD>-->
   <?/*
      $FieldNames = array("Accelerate All Ports", 
                          "Accelerate Only the Above Ports", 
                          "Accelerate Everything But the Above Ports");
      $Table = new HTML_TABLE();
      $ParamForm = new HTML_PARAMETER_FORM();
      echo 
         "<DIV class=\"no_bg_color\">",
         $Table->Begin(),
         $ParamForm->Begin("AcceleratedPorts"),

         $Table->AddEntry2($ParamForm->AddPortListParam("AcceleratedPorts", $FieldNames)),
         $Table->AddEntry("", $ParamForm->AddSubmit() ),
         $ParamForm->End(),
         $Table->End(),
         "<DIV class=\"no_bg_color\">";*/
   ?>
   <!--
   </TD>
   </TR>-->

   <!-- Accelerated/Unaccelerated IPs -->
   <!--
   <TR>
   <TH>
      Accelerated IPs:
   </TH>
   <TD>-->
   <?/*   
      $Results = GetParameter("Acceleration.AcceleratedIPs");
      
      if (isset($_GET["FormName"]) && $_GET["FormName"]=="AcceleratedIPs"){
         if (isset($_GET["Add"])){
            $NewIPMask["Display"] = $_GET["NewIPMask"];
            array_push($Results, $NewIPMask);
         }
         else if (isset($_GET["Delete"]) && isset($_GET["AccelIPs"])){
            $IPMaskToDelete = $_GET["AccelIPs"];
            
            $NewResults = array();
            foreach ($Results as $IPMask){
               if ($IPMask["Display"] != $IPMaskToDelete){
                  array_push($NewResults, $IPMask);
               }
            }
            $Results = $NewResults;
         }
         
         SetParameter("Acceleration.AcceleratedIPs", $Results);
      }
      
      $AccelItems = array();
      foreach ($Results as $IPMask){
         array_push($AccelItems, $IPMask["Display"]);
      }
   
      if (sizeof($AccelItems)==0){
         $AccelMode = 1;
         array_push($AccelItems,"-- EMPTY --");
      }else{
         $AccelMode = (GetParameter("Acceleration.OnlyAccelIPsOnList")?2:3);
      }      
            
      $Table = new HTML_TABLE();
      $Form = new HTML_FORM();
      echo 
         "<DIV class=\"no_bg_color\">",
         "<TABLE>",
         $Form->Begin("AcceleratedIPs"),
         "<TR>",
            "<TD>New IP:</TD>" ,
            "<TD>", $Form->AddTextField("NewIPMask", "", 12) . "<BR>Example: 192.168.1.0/24</TD>",
            "<TD>", $Form->AddSubmit("Add","Add") .             
         "</TR>",
         "<TR>",
            "<TD>Current IPs:</TD>" ,
            "<TD>", $Form->AddList("AccelIPs", $AccelItems, 6, 120) . "</TD>",
            "<TD align=left>", $Form->AddSubmit("Delete","Delete") . "</TD>",
         "</TR>",
         "<TR>",
            "<TD>Mode:</TD>" ,
            "<TD colspan=2>", $Form->AddRadioButton("AccelIPsMode", "1", $AccelMode==1) . "Accelerate All Traffic<BR>" .
                    $Form->AddRadioButton("AccelIPsMode", "2", $AccelMode==2) . "Only Traffic With a Source or Destination IP Listed Above<BR>" .
                    $Form->AddRadioButton("AccelIPsMode", "3", $AccelMode==3) . "Never Accelerate Traffic With a Source or Destination IP Listed Above<BR>" .
            "<TD></TD>",
         "</TR>",
         "<TR>",
            "<TD></TD>" ,
            "<TD align=left>", $Form->AddSubmit("ChangeMode","Change Mode") . "</TD>",
            "<TD></TD>",
         "</TR>",
         $Form->End(),
         "</TABLE>",
         "</DIV>";*/
   ?>
   <!--
   </TD>
   </TR>-->

   <!-- Special Ports -->
   <TR>
   <TH>Special Ports:</TH>
   <TD>
   <?
      $Table = new HTML_TABLE();
      $ParamForm = new HTML_PARAMETER_FORM();
      echo 
         "<TABLE class=no_bg_color>",
         $ParamForm->Begin("ConnectionTimeout"),
         "<TR>",
            "<TD>FTP Control:</TD>" ,
            "<TD>", $ParamForm->AddTextParam("Ports.FtpControl", 15) . "</TD>",
         "</TR>",
         "<TR>",
            "<TD>Rshell:</TD>" ,
            "<TD>", $ParamForm->AddTextParam("Ports.Rshell", 15) . "</TD>",
         "</TR>",
         "<TR>",
            "<TD></TD>" ,
            "<TD>", $ParamForm->AddSubmit() . "</TD>",
         "</TR>",
         $ParamForm->End(),
         "</TABLE>";
   ?>
   </TD>   
   </TR>

   <!-- IP Forwarding -->
   <TR>
   <TH>Virtual Inline:</TH>
   <TD>
   <?
      $Table = new HTML_TABLE();
      $ParamForm = new HTML_PARAMETER_FORM();
      echo 
         "<TABLE class=no_bg_color>",
         $ParamForm->Begin("IPForwarding"),
         "<TR>",
            "<TD>Enable IP Fowarding:</TD>" ,
            "<TD>", $ParamForm->AddBooleanParam("System.IPForwardMode") . "</TD>",
         "</TR>",
         "<tr>",
             "<td colspan=2>",
             $ParamForm->AddRadioButtonsParameter("System.VirtualInlineMode", array("Send to Gateway", "Return to Ethernet Sender"), 
                                         array("SendToGateway", "ReturnToEthernetSender")),
         "</td>",
         "</tr>",
         "<TR>",
            "<TD></TD>" ,
            "<TD>", $ParamForm->AddSubmit() . "</TD>",
         "</TR>",
         $ParamForm->End(),
         "</TABLE>";
   ?>
   </TD>
   </TR>

   <!-- WCCP-->
   <TR>
   <TH>WCCP:</TH>
   <TD>
   <?
      $Table = new HTML_TABLE();
      $ParamForm = new HTML_PARAMETER_FORM();
      echo
         "<TABLE class=no_bg_color>",
         $ParamForm->Begin("wccp"),
         "<TR>",
            "<TD>Enable WCCP 2.0:</TD>" ,
            "<TD>", $ParamForm->AddBooleanParam("WCCP.WccpDeploymentEnable") . "</TD>",
         "</TR>",
         "<tr>",
            "<TD>Service Group ID (51 ~ 255):</TD>" ,
            "<TD>", $ParamForm->AddTextField("WccpServiceGroupId", $OrginalWccpServiceGroupId, 3) . "</TD>",
         "</tr>",
         "<tr>",
            "<TD>Router IP:</TD>" ,
            "<TD>", $ParamForm->AddTextParam("WCCP.WccpRouterIp", 15) . "</TD>",
         "</tr>",
         "<TR>",
            "<TD></TD>" ,
            "<TD>", $ParamForm->AddButton("wccp", "Update",  "return onWccpUpdate()"), "</TD>",
         "</TR>",
         $ParamForm->End(),
         "</TABLE>";
   ?>
   </TD>


   <!-- Daisy Chaing support -->

   <TR>
   <TH>Daisy-Chain:</TH>
   <TD>
   <?
      $Table = new HTML_TABLE();
      $ParamForm = new HTML_PARAMETER_FORM();
      echo 
         "<TABLE class=no_bg_color>",
         $ParamForm->Begin("DaisyChain"),
         "<tr>",
             "<td>",
                "Enabled: ",
             "</td>",
             "<td>",
                $ParamForm->AddBooleanParam("Tcp.AllowOrbitalInTheMiddle"),
            "</td>",
         "</tr>",
         "<tr>",
            "<td></td>" ,
            "<TD>", $ParamForm->AddSubmit() . "</TD>",
         "</TR>",
         $ParamForm->End(),
         "</TABLE>";
   ?>
   </TD>
   </TR>


   <TR>
   <TH>Generic Settings:</TH>
   <TD>
 <?
   /************************************************************************
    *  Allow the user to set any parameter IF they know the name of the parameter
   ************************************************************************/
   $Setting   = "";
   $Value     = "";
   $ResultTxt = "";
   if ( isset($_GET["setting"]) ){
      $Setting = $_GET["setting"];
      $Value    = $_GET["value"];
      
      $Response = SetParameterAsXML($Setting, $Value);
      
      if ($Response == ""){
         $NewValue = GetParameterObject($Setting);
         $ResultTxt = "<font color=blue>New Value: " . $NewValue["Text"] . "</font>";
      }else{
         $ResultTxt = "<font color=red>Invalid setting name or value!</font>";
      }
   }
 ?>
 
 <form>
   <table class=no_bg_color>
   <tr>
      <td>Setting:</td>
      <td><input type="" name="setting" value="<?=$Setting?>" size=15></td>
   </tr>
  
   <tr> 
      <td>Value:</td>
      <td><input type="" name="value" value="<?=$Value?>" size=15></td>
   </tr>
   <tr>
      <td></td>
      <td><input type="submit" name="Foo" value="Set"><?=$ResultTxt?></td>
   </tr>
   </TD>
   </TR>
   </table>
 </form>

</td>


</tr>
</TABLE>
</div>

<? include(HTTP_ROOT_INCLUDES_DIR ."footer.php"); ?>
