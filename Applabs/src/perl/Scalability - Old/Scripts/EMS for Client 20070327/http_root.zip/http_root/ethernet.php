<?
   define('PAGE_IS_HA_CLUSTER_INDEPENDANT', true);
   include("includes/header.php");
   $Auth->CheckRights(AUTH_LEVEL_ADMIN);

   $prodName = ProdName();

   $LINK_CONSTANTS = array(0 => "Auto", 1 => "1000 Full", 2 => "100 Full", 3 => "100 Half", 4 => "10 Full", 5 => "10 Half");
   $LINK_CONSTANTS_VALUES = array(0,1,2,3,4,5);

   $TrafficAdapter = GetTrafficAdapter();
   $RearPanel   =    GetParameter("UI.RearImageFileName");

   if ( $RearPanel != "" ) {
       $RearPanel = "./images/" . $RearPanel;
   }
   /*-------------------------------------------------------------------------------------- */
?>

   <font class="pageheading">Configure Settings: Interface</font><BR><BR>

   <?  if ( $RearPanel != "" ) { ?>
            <IMG src = <?=$RearPanel?> >
            <BR>
            <BR>
   <? } ?>

   <!-- ADAPTER BLOCK -->
   <? 
      $Adapters = OrbitalGet("ADAPTER", array("InstanceNumber", "DisplayName", "LinkSpeedDuplex",
                                              "Duplex", "WireSpeed", "BridgeDisplayName", "BridgeName", "Enable"));
      for ( $MyIndex=0; $MyIndex < sizeof($TrafficAdapter); $MyIndex++) { 
         $ThisAdapter = $TrafficAdapter[ $MyIndex];
         $BridgeDisplayName  = $TrafficAdapter[ $MyIndex];
         foreach($Adapters as $ix => $value) {
            if ( $ThisAdapter  == $value[ "BridgeName"]) {
               $Enable = $value["Enable"];
               $BridgeDisplayName  = $value["BridgeDisplayName"];
               break;
            }
         }
   ?>
   <TABLE class=settings_table width=650>
   <COLGROUP width=30% span=1> </COLGROUP>
   <COLGROUP width=50% span=1> </COLGROUP>
   
   <TR>
   <TH>
      <?
         echo " Accelerated Adapter Pair : $BridgeDisplayName";
        if ($Enable) {
           echo "  ";
           echo "<a href=\"./managementip.php\"> Enabled";
        }
        else {
           echo "  ";
           echo "<a href=\"./managementip.php\"> Disabled";
        }
      ?>
   </Th>


   <TD>
   <?
      //
      // Now set the adapter link/duplex settings
      //
      if (  isset($_GET["LinkSpeedDuplex"]))
      {
         $NumAdapters = sizeof($Adapters);

         for ($i=0; $i<$NumAdapters; $i++)
         {
            $AdapterNumber = $Adapters[$i]["InstanceNumber"];
            if (isset($_GET[$AdapterNumber])) {
               $Param["LinkSpeedDuplex"] = (int)$_GET[$AdapterNumber];
               $Result = OrbitalSet("ADAPTER", $Param, $AdapterNumber);
            }
         }
      }

      //
      // Display the adapter link/duplex settings
      //

      echo HTML_FORM::Begin("ethernet.php");
      foreach($Adapters as $ix => $value) {
         if ( $ThisAdapter  == $value[ "BridgeName"])
	 {
            $i = $value["InstanceNumber"];
            $DisplayName = $value["DisplayName"];
            $BridgeName  = $value["BridgeName"];
            if ($DisplayName != "") {
               echo "<a href=\"./adapter_info.php?InstanceNumber=" . $i . "\"><img src=\"./images/icon-nic_card.gif\" border=\"0\" alt=\"Click Here For Adapter Info\"> $DisplayName </a>&nbsp;Link/Duplex:";
            }
            echo HTML_FORM::AddDropdown($i, $LINK_CONSTANTS, $LINK_CONSTANTS_VALUES, $value["LinkSpeedDuplex"], 0, true );
            if($value["WireSpeed"] != 0)
               echo "(" . FormatThroughput($value["WireSpeed"]) . "/" . $value["Duplex"] . ")<BR>";
            else
               echo "(Down)<BR>";
            echo "<BR>";
            echo "<BR>";
         }
      }
      echo HTML_FORM::AddSubmit("LinkSpeedDuplex", "Update Accelerated Pair Configuration", $Enable);
      echo HTML_FORM::End();
   ?>
   </TD>
   </TR>
   </TABLE>
   <br>
   <br>
   <? } ?>
   <? /*-------------------------------------------------------------------------------------- */ ?>



   <?
      $NonTrafficAdapter = GetNonTrafficAdapter();
      for ( $MyIndex=0; $MyIndex < sizeof($NonTrafficAdapter); $MyIndex++) { 
         $ThisAdapter = $NonTrafficAdapter[ $MyIndex];
   ?>

      <TABLE class=settings_table width=650>
      <COLGROUP width=30% span=1> </COLGROUP>
      <COLGROUP width=50% span=1> </COLGROUP>
      <TR>
      <TH>
         <?
            $Adapters = OrbitalGet("ADAPTER", array("InstanceNumber", "DisplayName", "DeviceName", "LinkSpeedDuplex", "Duplex", 
	                           "WireSpeed", "Enable") );
            $found = 0;
            foreach($Adapters as $ix => $value) {
               $DeviceName = $value["DeviceName"];
               $Enable     = $value["Enable"];
               if ( $ThisAdapter == $DeviceName) {
                   $DisplayName = $value["DisplayName"];
                   $found = 1;
                   break;
               }
            }
            
	    if ($found == 0) {
                echo " Couldn't Find Adapter : $ThisAdapter";
                echo "<br>";
                continue;
            }

            echo " Adapter : $DisplayName";
            if ($Enable) {
               echo "  ";
               echo "<a href=\"./managementip.php\"> Enabled";
            }
            else {
               echo "  ";
               echo "<a href=\"./managementip.php\"> Disabled";
            }
         ?>
      </Th>
      <TD>
      <?
         //
         // Display the adapter link/duplex settings
         //
         echo HTML_FORM::Begin("ethernet.php");
         $DeviceName = $value["DeviceName"];
         $Enable     = $value["Enable"];
         if ( $ThisAdapter == $DeviceName)
	 {
             $i = $value["InstanceNumber"];
             $DisplayName = $value["DisplayName"];
             if ($DeviceName != "") {
                if ($Enable) {
                   echo "<a href=\"./adapter_info.php?InstanceNumber=" . $i . "\"><img src=\"./images/icon-nic_card.gif\" border=\"0\" alt=\"Click Here For Adapter Info\"> $DisplayName </a>&nbsp;Link/Duplex:";
	          }
	        else {
	           /* When disabled, we don't put URL link to statistics page. */
                   echo "<img src=\"./images/icon-nic_card.gif\" border=\"0\" alt=\"Click Here For Adapter Info\"> $DisplayName </a>&nbsp;Link/Duplex:";
	         }
            }
            echo HTML_FORM::AddDropdown($i, $LINK_CONSTANTS, $LINK_CONSTANTS_VALUES, $value["LinkSpeedDuplex"] , 0, $Enable);
            if($value["WireSpeed"] != 0)
                echo "(" . FormatThroughput($value["WireSpeed"]) . "/" . $value["Duplex"] . ")<BR>";
            else
                echo "(Down)<BR>";
            echo "<BR>";
            echo "<BR>";
            }
         echo HTML_FORM::AddSubmit("LinkSpeedDuplex", "Update Adapter Configuration", $Enable);
         echo HTML_FORM::End();
      ?>
      </TD>
      </TR>
      </TABLE>
      <BR>
      <BR>
   <?
      }
   ?>

   <? /*-------------------------------------------------------------------------------------- */ ?>

   </DIV>
<? include(HTTP_ROOT_INCLUDES_DIR ."footer.php"); ?>
