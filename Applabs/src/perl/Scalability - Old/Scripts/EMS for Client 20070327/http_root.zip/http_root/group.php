<?
   include("includes/header.php");
   $Auth->CheckRights(AUTH_LEVEL_ADMIN);

   define('GROUP_MODE_ENABLE_PARAM',             "OrbGroup.Enabled");
   define('GROUP_MEMBERS_PARAM',                 "OrbGroup.Members");
   define('GROUP_FWD_RULES_PARAM',               "OrbGroup.FwdRules");
   define('GROUP_PASS_THROUGH_ON_FAILURE_PARAM',
      "OrbGroup.PassThroughOnFailure");
   define('GROUP_PACKET_ID_PARAM',               "OrbGroup.PacketGroupId");
   define('GROUP_FORWARDING_INTERFACE_PARAM',
      "OrbGroup.ForwardingInterfaceName");
   define('HA_ENABLED_PARAM',                    "HA.Enabled");

   function ValidateAddress($address)
   {
      return "<FONT COLOR=\"" .
         (PingHost($address) ? "blue" : "red") .
         "\">" . $address ."</FONT>";
   }

   function IsMember($vip, $members = 0, $system = 0)
   {
      $tvip = trim($vip);
      if (! isset($system) || $system === 0) {
         $system = OrbitalGet('SYSTEM', array('AgentID'));
      }
      if ($tvip === $system['AgentID']['IP']['Dotted']) {
         return true;
      }
      if (! isset($members) || $members === 0) {
         $members = GetParameter(GROUP_MEMBERS_PARAM);
      }
      foreach ($members as $member) {
         if ($tvip === $member["IpAddress"]["Dotted"]) {
            return true;
         }
      }
      return false;
   }

   function RemoveMember($index)
   {
      $members = GetParameter(GROUP_MEMBERS_PARAM);
      if ($index < 0 || $index > sizeof($members)) {
         return;
      }
      $memberIp = $members[$index]['IpAddress']['Dotted'];
      unset($members[$index]);
      if (MSG_BOX::Ask(
            "Remove Group Member?",
            "Are you sure you wish to delete group member with" .
               " ip address $memberIp ?",
            "Remove", "Cancel") == MSG_BOX_YES) {
         SetParameterAsXML(GROUP_MEMBERS_PARAM, array_values($members));
      }
      echo HTML::InsertRedirect();
   }

   function EnableDisableMember($index)
   {
      $members = GetParameter(GROUP_MEMBERS_PARAM);
      if ($index < 0 || $index > sizeof($members)) {
         return;
      }
      $enabled   = $members[$index]['EnabledFlag'];
      $memberIp  = $members[$index]['IpAddress']['Dotted'];
      $actionStr = $enabled ? "Disable" : "Enable";
      if (MSG_BOX::Ask(
            $actionStr . " Group Member?",
            "Are you sure you wish to " .
               ($enabled ? "disable" : "enable") . " group member with " .
               " ip address $memberIp ?",
            $actionStr, "Cancel") == MSG_BOX_YES) {
         $members[$index]['EnabledFlag'] = ! $enabled;
         SetParameterAsXML(GROUP_MEMBERS_PARAM, $members);
      }
      echo HTML::InsertRedirect();
   }

   function ReportDup($vip)
   {
      echo "<BR /><H2><I>Addition ignored, Duplicate Member VIP "
         . $vip . "</I></H2><BR />\n";
   }

   function AddMember()
   {
      $vip   = trim($_GET['VIP']);
      $sslCN = trim($_GET['SslCommonName']);
      if ($vip === "" || $sslCN === "") {
         ThrowException("Error adding member: " .
            ($vip === "" ? "Member VIP" : "Serial Number")
            . " Filed is Empty.", false);
         return;
      }
      $members = GetParameter(GROUP_MEMBERS_PARAM);
      if (IsMember($vip, $members)) {
         ReportDup($vip);
         return;
      }
      $member['IpAddress']['Dotted']    = $vip;
      $member['SslCommonName']          = $sslCN;
      $member['SecondarySslCommonName'] = trim($_GET['SecondarySslCommonName']);
      $member['EnabledFlag']            = isset($_GET['EnabledFlag']) ? 1 : 0;
      $members[sizeof($members)] = $member;
      SetParameterAsXML(GROUP_MEMBERS_PARAM, $members);
      echo HTML::InsertRedirect();
   }

   function EnableDisableGroupMode()
   {
      $enabled   = GetParameter(GROUP_MODE_ENABLE_PARAM);
      $actionStr = $enabled ? "Disable" : "Enable";
      if (MSG_BOX::Ask(
            $actionStr . " Group Mode?",
            "Are you sure you wish to " .
               ($enabled ? "disable" : "enable") . " group mode?",
            $actionStr, "Cancel") == MSG_BOX_YES) {
         SetParameterAsXML(GROUP_MODE_ENABLE_PARAM, ! $enabled);
      }
      echo HTML::InsertRedirect();
   }

   function MakePartnerOrbitalUrl($host, $path = 0)
   {
      $https = ! empty($_SERVER['HTTPS']);
      $port  = $_SERVER['SERVER_PORT'];
      return (
         ($https ? "https://" : "http://") .
         $host .
         ($port == ($https ? 443 : 80) ? "" : ":$port") .
         (is_string($path) ? $path : $_SERVER['PHP_SELF'])
      );
   }

   function GetSystemVars()
   {
      return OrbitalGet('SYSTEM', array(
         'AgentID',
         'SslClientName',
         'HaSecondaryHostSerialNumber',
         'GroupInfo',
         'IpAddressConfiguration')
      );
   }

   function AddFwdRule($index)
   {
      $vip       = trim($_GET['VIP']);
      $subnet    = trim($_GET['Subnet']);
      $portBegin = trim($_GET['PortBegin']);
      $portEnd   = trim($_GET['PortEnd']);
      if ($vip === "" || (
            $subnet    === "" &&
            $portBegin === ""  &&
            $portEnd   === "" )) {
         ThrowException("Error adding forwarding rule: " .
            ($vip === "" ? "Member VIP Field is" :
               "Subnet and Port Range Fields are")
            . " Empty.", false);
         return;
      }
      $subnet = trim($_GET['Subnet']);
      if ($subnet === "") {
         $subnet = "0.0.0.0/0";
      }
      if ($portBegin === "" && $portEnd === "") {
         $portBegin = 0;
         $portEnd   = 65535;
      } else if ($portBegin === "") {
         $portBegin = $portEnd;
      } else if ($portEnd === "") {
         $portEnd = $portBegin;
      }
      if ($portBegin < 0 ||
            $portEnd < 0 ||
            $portBegin > $portEnd ||
            $portBegin > 65535 ||
            $portEnd > 65535) {
         ThrowException("Error adding forwarding rule: " .
            "Illegal Port Range $portBegin - $portEnd", false);
         return;
      }
      if (! IsMember($vip) &&
            MSG_BOX::Ask(
               "Add rule for $vip?",
               "Are you sure you wish to " .
                  "add rule for $vip which is not in the group?",
               "Add", "Cancel") != MSG_BOX_YES) {
         return;
      }
      $rules = GetParameter(GROUP_FWD_RULES_PARAM);
      $rule['IpAddress']['Dotted'] = $vip;
      $rule['Subnet']['Printable'] = $subnet;
      $rule['PortRange']['Begin']  = $portBegin;
      $rule['PortRange']['End']    = $portEnd;
      $rule['NegateFlag']          = isset($_GET['NegateFlag']) ? 1 : 0;
      $rule['EnabledFlag']         = isset($_GET['EnabledFlag']) ? 1 : 0;
      if (! isset($index) || $index === "" || $index > sizeof($rules)) {
         $index = sizeof($rules);
      } else if ($index < 0) {
         $index = 0;
      }
      for ($i = sizeof($rules); $i > $index; $i--) {
         $rules[$i] = $rules[$i - 1];
      }
      $rules[$index] = $rule;
      SetParameterAsXML(GROUP_FWD_RULES_PARAM, array_values($rules));
      echo HTML::InsertRedirect();
   }

   function DeleteFwdRule($index)
   {
      $rules = GetParameter(GROUP_FWD_RULES_PARAM);
      if ($index < 0 || $index >= sizeof($rules)) {
         return;
      }
      $vip       = $rules[$index]['IpAddress']['Dotted'];
      $enabled   = $rules[$index]['EnabledFlag'];
      $actionStr = $enabled ? "Disable" : "Enable";
      if (MSG_BOX::Ask(
            "Delete Forwading Rule?",
            "Are you sure you wish to delete" .
               " forwarding rule for VIP $vip ?",
            "Delete", "Cancel") == MSG_BOX_YES) {
         unset($rules[$index]);
         SetParameterAsXML(GROUP_FWD_RULES_PARAM, array_values($rules));
      }
      echo HTML::InsertRedirect();
   }

   function EnableDisableFwdRule($index)
   {
      $rules = GetParameter(GROUP_FWD_RULES_PARAM);
      if ($index < 0 || $index >= sizeof($rules)) {
         return;
      }
      $vip       = $rules[$index]['IpAddress']['Dotted'];
      $enabled   = $rules[$index]['EnabledFlag'];
      $actionStr = $enabled ? "Disable" : "Enable";
      if (MSG_BOX::Ask(
            $actionStr . " Forwading Rule?",
            "Are you sure you wish to " . ($enabled ? "disable" : "enable") .
               " forwarding rule for VIP $vip ?",
            $actionStr, "Cancel") == MSG_BOX_YES) {
         $rules[$index]['EnabledFlag'] = ! $enabled;
         SetParameterAsXML(GROUP_FWD_RULES_PARAM, $rules);
      }
      echo HTML::InsertRedirect();
   }

   function MoveRuleTo($from, $to)
   {
      $rules = GetParameter(GROUP_FWD_RULES_PARAM);
      if ($from == $to ||
            $from < 0 || $from >= sizeof($rules) ||
            $to   < 0 || $to   > sizeof($rules)) {
         return;
      }
      $rule         = $rules[$from];
      $rules[$from] = $rules[$to];
      $rules[$to]   = $rule;
      SetParameterAsXML(GROUP_FWD_RULES_PARAM, array_values($rules));
      echo HTML::InsertRedirect();
   }

   function MoveUpFwdRule($index)
   {
      MoveRuleTo($index, $index - 1);
   }

   function MoveDownFwdRule($index)
   {
      MoveRuleTo($index, $index + 1);
   }

   function EnableDisablePassThroughOnFailure()
   {
      $enabled   = GetParameter(GROUP_PASS_THROUGH_ON_FAILURE_PARAM);
      $actionStr = $enabled ? "Continue to accelerate" : "Disable acceleration";
      if (MSG_BOX::Ask(
            $actionStr . " on member failure ?",
            "Are you sure you wish to " . $actionStr .
               " when group member failure detected?",
            $actionStr, "Cancel") == MSG_BOX_YES) {
         SetParameterAsXML(GROUP_PASS_THROUGH_ON_FAILURE_PARAM, ! $enabled);
      }
      echo HTML::InsertRedirect();
   }

   function EnableDisableLoopPrevent()
   {
      $enabled   = GetParameter(GROUP_PACKET_ID_PARAM);
      $actionStr = $enabled != 0 ? "Disable" : "Enable";
      if (MSG_BOX::Ask(
            $actionStr . " Forwarding Loop Detection and Prevention?",
            "Are you sure you wish to " .
               ($enabled != 0 ? "disable" : "enable") .
               " forwarding loop detection and prevention?",
            $actionStr, "Cancel") == MSG_BOX_YES) {
         SetParameterAsXML(GROUP_PACKET_ID_PARAM, $enabled != 0 ? 0 : 1);
      }
      echo HTML::InsertRedirect();
   }

   function SetMyIp()
   {
      $ifName     = $_GET['FwdInterface'];
      $prevIfName = GetParameter(GROUP_FORWARDING_INTERFACE_PARAM);
      if (isset($ifName) && $ifName !== $prevIfName) {
         $cfg = GetSystemVars();
         $cfg = $cfg['IpAddressConfiguration'];
         if (isset($cfg[$ifName]) && $cfg[$ifName]['Enable'] &&
               MSG_BOX::Ask(
                  "Change forwarding interface and ip address?",
                  "Are you sure you wish to change forwarding interface and " .
                  "ip address? " .
                  "Other members of the group need to be reconfigured to use " .
                  "this ip address.",
                  "Change", "Cancel") == MSG_BOX_YES) {
            SetParameterAsXML(GROUP_FORWARDING_INTERFACE_PARAM, $ifName);
         }
      }
      echo HTML::InsertRedirect();
   }

   if (isset($_GET['AddMember'])) {
      AddMember();
   } else if (isset($_GET['RemoveMember'])) {
      RemoveMember($_GET['RemoveMember']);
   } else if (isset($_GET['EnableDisableMember'])) {
      EnableDisableMember($_GET['EnableDisableMember']);
   } else if (isset($_GET['AddFwdRule'])) {
      AddFwdRule($_GET['Index']);
   } else if (isset($_GET['DeleteFwdRule'])) {
      DeleteFwdRule($_GET['DeleteFwdRule']);
   } else if (isset($_GET['EnableDisableFwdRule'])) {
      EnableDisableFwdRule($_GET['EnableDisableFwdRule']);
   } else if (isset($_GET['MoveUpFwdRule'])) {
      MoveUpFwdRule($_GET['MoveUpFwdRule']);
   } else if (isset($_GET['MoveDownFwdRule'])) {
      MoveDownFwdRule($_GET['MoveDownFwdRule']);
   } else if (isset($_GET['EnableDisableGroupMode'])) {
      EnableDisableGroupMode();
   } else if (isset($_GET['EnableDisableLoopPrevent'])) {
      EnableDisableLoopPrevent();
   } else if (isset($_GET['EnableDisablePassThroughOnFailure'])) {
      EnableDisablePassThroughOnFailure();
   } else if (isset($_GET['SetMyIp'])) {
      SetMyIp();
   }

   // Remove myself if needed
   $system                  = GetSystemVars();
   $members                 = GetParameter(GROUP_MEMBERS_PARAM);
   $forwardingInterfaceName = GetParameter(GROUP_FORWARDING_INTERFACE_PARAM);
   $isHaEnabled             = GetParameter(HA_ENABLED_PARAM);
   $myIp                    = ($isHaEnabled ||
         $forwardingInterfaceName === '' ||
         ! isset($system['IpAddressConfiguration'][$forwardingInterfaceName]) ||
         ! $system['IpAddressConfiguration'][$forwardingInterfaceName]['Enable']) ?
      $system['AgentID']['IP']['IntegerAddress'] :
      $system['IpAddressConfiguration'][$forwardingInterfaceName]['Address'];
   $arrayModFlag = false;
   for ( ; ; ) {
      for ($i = 0; $i < sizeof($members); $i++) {
         if (isset($members[$i]) &&
               $myIp === $members[$i]['IpAddress']['IntegerAddress']) {
            $arrayModFlag = true;
            break;
         }
      }
      if ($i < sizeof($members)) {
         unset($members[$i]);
      } else {
         break;
      }
   }
   if ($arrayModFlag) {
      SetParameterAsXML(GROUP_MEMBERS_PARAM, array_values($members));
      $members = GetParameter(GROUP_MEMBERS_PARAM);
      $system  = GetSystemVars();
   }

   $passThroughOnFailure    = GetParameter(GROUP_PASS_THROUGH_ON_FAILURE_PARAM);
   $groupModeEnabledFlag    = GetParameter(GROUP_MODE_ENABLE_PARAM);
   $groupStatus             = $system['GroupInfo'];
   $fwdRules                = GetParameter(GROUP_FWD_RULES_PARAM);
   $packetGroupId           = GetParameter(GROUP_PACKET_ID_PARAM);
   if ($isHaEnabled  ||
         $forwardingInterfaceName === '' ||
         ! isset($system['IpAddressConfiguration'][$forwardingInterfaceName]) ||
         ! $system['IpAddressConfiguration'][$forwardingInterfaceName]['Enable']) {
      $myselfIp = $system['AgentID']['IP'];
      foreach ($system['IpAddressConfiguration']['SortOrder'] as $i) {
         $if = $system['IpAddressConfiguration'][$i];
         if ($if['Enable'] && $if['Address']['IntegerAddress'] ==
               $myselfIp['IntegerAddress']) {
            $forwardingInterfaceName = $if['DeviceName'];
            break;
         }
      }
   } else {
      $myselfIp =
         $system['IpAddressConfiguration'][$forwardingInterfaceName]['Address'];
   }
?>

<DIV ID="linkspandetail">
<FONT class="pageheading">Group Mode Status:&nbsp;
<?
$statusMsg = $groupStatus["GroupPassThroughFlag"] ? "PASS THROUGH" :
      (sizeof($groupStatus["Members"]) > 0 ? "NORMAL" : "DISABLED");
if (isset($groupStatus["Alert"])) {
?>
   <A HREF="/alerts.php">
   <FONT COLOR="<?=$groupStatus["GroupPassThroughFlag"] ? "red" : "blue"?>">
   <?=$statusMsg?>
   </FONT>
   <SPAN><FONT size="-1"><?=$groupStatus["Alert"]["Msg"]?></FONT></SPAN>
   </A>
<? } else { ?>
   <FONT COLOR="<?=$groupStatus["GroupPassThroughFlag"] ? "red" : "blue"?>">
   <?=$statusMsg?>
   </FONT>
<? } ?>
</FONT>
</DIV>
<BR />
<BR />
<?
if (sizeof($groupStatus["Members"]) > 0) {
?>
<TABLE class="settings_table">
   <TR>
      <TH>Member VIP</TH>
      <!-- TH>Enabled</TH -->
      <TH>Status</TH>
      <TH>Configuration</TH>
      <TH>Time Since Last Heart Beat</TH>
   </TR>
   <!-- BEGIN GROUP MEMBERS STATUS RENDERING -->
   <?
   foreach ($groupStatus["Members"] as $status) {
      if ($status['DupTupleIndex'] >= 0 || ! $status['EnabledFlag']) {
         continue;
      }
   ?>
   <TR>
      <TD>
         <A HREF="<?=MakePartnerOrbitalUrl($status['IpAddress']['Dotted'])?>">
            <?=$status['IpAddress']['Dotted']?>
         </A>
      </TD>
      <!-- TD>
      <?=($status['EnabledFlag'] ? "Enabled" : "Disabled")?>
      </TD -->
      <TD>
      <DIV ID="linkspandetail">
      <?if (! $status['OperationalFlag']) {?>
         <IMG SRC="./images/icon-warning.gif">
      <?} else {?>
         &nbsp;&nbsp;&nbsp;&nbsp;
      <?}?>
      <?=(isset($status['Alert']) ? "<A HREF=\"/alerts.php\">" : "")?>
      <?=($status['OperationalFlag'] ?
         "On-Line" : "<FONT COLOR=\"red\">Off-Line</FONT>")?>
      <?=(isset($status['Alert']) ?
         ("<SPAN>" . $status['Alert']['Msg'] . "</SPAN></A>") : "")?>
      </DIV>
      </TD>
      <TD>
      <?if ($status['BadConfigFlag']) {?>
         <IMG SRC="./images/icon-warning.gif">
      <?} else {?>
         &nbsp;&nbsp;&nbsp;&nbsp;
      <?}?>
      <?=($status['BadConfigFlag'] ? "Mismatch" : "&nbsp;&nbsp;&nbsp;OK")?>
      </TD>
      <TD>
      <?=(int)$status['TimeSinceLastHeartBeatRecv']?> Secs
      </TD>
   </TR>
   <?
   }
   ?>
</TABLE>
<BR />
<BR />
<?
}
?>

<FONT class="pageheading">Configure Settings: Group Mode</FONT><BR /><BR />
<!-- SHOW CURRENT GROUP MEMBERS -->
<TABLE class="settings_table">
   <TR>
      <TH>Member VIP</TH>
      <TH>Serial Number</TH>
      <TH>HA Secondary Serial Number</TH>
      <TH> </TH>
      <TH> </TH>
   </TR>

   <!-- BEGIN GROUP MEMBERS RENDERING -->
   <?
   $myself['IpAddress']              = $myselfIp;
   $myself['SslCommonName']          = $system['SslClientName'];
   $myself['SecondarySslCommonName'] = $system['HaSecondaryHostSerialNumber'];
   $myself['EnabledFlag']            = true;
   $allmembers = array_values($members);
   array_unshift($allmembers, $myself);
   $index = -1;
   foreach ($allmembers as $member) {
   ?>
      <TR>
         <TD>
            <FONT COLOR="
            <?=($member['EnabledFlag'] ? "black\">" : "red\">X")?>
            </FONT>
            <A HREF="<?=MakePartnerOrbitalUrl($member['IpAddress']['Dotted'])?>">
               <?=ValidateAddress($member['IpAddress']['Dotted'])?>
            </A>
         </TD>
         <TD>
            <?=$member['SslCommonName']?>
         </TD>
         <TD>
            <?=$member['SecondarySslCommonName']?>
         </TD>
      <?
      if ($index >= 0) {
      ?> 
         <TD>
            <FORM name="EnableDisableMemberForm">
               <INPUT type="hidden" name="EnableDisableMember"
                  value="<?=$index?>" />
               <INPUT type="submit"
                  value="<?=($member['EnabledFlag'] ? "Disable" : "Enable")?>" />
            </FORM>
         </TD>
         <TD>
            <FORM name="RemoveMemberForm">
               <INPUT type="hidden" name="RemoveMember" value="<?=$index?>">
               <INPUT type="submit" value="Remove">
            </FORM>
         </TD>
      <?
      } else if (! $isHaEnabled) {
      ?>
         <FORM name="SetMyIpForm">
         <TD>
            <?=HTML_FORM::AddInterfaceDropdown("FwdInterface", -1, 0, true,
               true, $forwardingInterfaceName)?>
         </TD>
         <TD>
            <INPUT type="hidden" name="SetMyIp" value="<?=$index?>">
            <INPUT type="submit" value="Change VIP">
         </TD>
         </FORM>
      <?
      } else {
      ?>
         <TD> </TD>
         <TD> </TD>
      <? 
      }
      ?> 
      </TR>
   <?
      $index++;
   }
   ?>
   <FORM name="AddMemberForm">
      <INPUT type="hidden" name="AddMember" value="AddMember">
      <TR>
         <TD>
            <INPUT type="text" name="VIP" size="12" />
         </TD>
         <TD>
            <INPUT type="text" name="SslCommonName" size="18" />
         </TD>
         <TD align="center">
            <INPUT type="text" name="SecondarySslCommonName" size="18" />
         </TD>
         <TD>
            <INPUT type="checkbox" name="EnabledFlag" "checked" />Enable
         </TD>
         <TD>
            <INPUT type="Submit" name="AddMember" value="   Add  " type="Get" />
         </TD>
      </TR>
   </FORM>
   <TR><TD colspan="5" align="center">
      <FORM name="EnableDisablePassThroughOnFailureForm">
         <INPUT type="Submit" name="EnableDisablePassThroughOnFailure"
            value="<?=($passThroughOnFailure ? "Continue to" : "Do NOT")?> Accelerate When Member Failure Detected"
            type="Get" />
      </FORM>
      <BR />
      <FORM name="GroupModeLoopPreventForm">
         <INPUT type="Submit" name="EnableDisableLoopPrevent"
            value="<?=($packetGroupId != 0 ? "Disable" : "Enable")?> Forwarding Loop Prevention"
            type="Get" />
      </FORM>
      <BR />
      <FORM name="GroupModeDisableForm">
         <INPUT type="Submit" name="EnableDisableGroupMode"
            value="<?=($groupModeEnabledFlag ? "Disable" : "Enable")?> Group Mode"
            type="Get" />
      </FORM>
   </TD></TR>
</TABLE>
<BR />

<FONT class="pageheading">Configure Settings: Group Forwarding Rules</FONT>
<BR />
<BR />
<TABLE class="settings_table">
   <TR>
      <TH>Priority</TH>
      <TH>Member VIP</TH>
      <TH> </TH>
      <TH>Subnet</TH>
      <TH>Port Range</TH>
      <TH> </TH>
      <TH> </TH>
      <!--TH> </TH-->
   </TR>
   <!-- BEGIN GROUP FORWARDING RULES RENDERING -->
   <?
   $index = 0;
   foreach ($fwdRules as $rule) {
      $memberFlag = IsMember($rule['IpAddress']['Dotted'], $members, $system);
   ?>
   <TR>
      <TD>
         <FONT COLOR="
         <?=($rule['EnabledFlag'] ? "black\">" : "red\">X")?>
         <?=$index?>
         </FONT>
      </TD>
      <TD>
         <? if ($memberFlag) {?>
            <A HREF="<?=MakePartnerOrbitalUrl($rule['IpAddress']['Dotted'])?>">
               <?=$rule['IpAddress']['Dotted']?>
            </A>
         <? } else { ?>
            <DIV ID="linkspandetail">
            <IMG SRC="./images/icon-warning.gif">
            <A HREF="<?=MakePartnerOrbitalUrl($rule['IpAddress']['Dotted'])?>">
            <FONT COLOR="red">
                <?=$rule['IpAddress']['Dotted']?>
           </FONT>
           <SPAN>This rule has NO effect because the VIP does NOT belong to the group.</SPAN>
            </A>
            </DIV>
         <?}?>
      </TD>
      <TD>
         Is&nbsp;<?=$rule['NegateFlag'] ? "<FONT clor=\"red\">NOT</FONT>" : ""?>
      </TD>
      <TD>
         <?=$rule['Subnet']['Printable']?>
      </TD>
      <TD>
         <?=$rule['PortRange']['Begin']?>&nbsp;-&nbsp;<?=$rule['PortRange']['End']?>
      </TD>
      <TD>
         <FORM name="MoveUpFwdRuleForm">
            <INPUT type="hidden" name="MoveUpFwdRule" value="<?=$index?>">
            <PRE><INPUT type="submit" value="  Move Up   "></PRE>
         </FORM>
         <FORM name="MoveDownFwdRuleForm">
            <INPUT type="hidden" name="MoveDownFwdRule" value="<?=$index?>">
            <INPUT type="submit" value="Move Down">
         </FORM>
      </TD>
      <TD>
         <FORM name="EnableDisableFwdRuleForm">
            <INPUT type="hidden" name="EnableDisableFwdRule"
               value="<?=$index?>" />
            <PRE><INPUT type="submit"
               value="<?=($rule['EnabledFlag'] ? "Disable" : "Enable  ")?>" /></PRE>
         </FORM>
      <!--/TD>
      <TD-->
         <FORM name="DeleteFwdRuleForm">
            <INPUT type="hidden" name="DeleteFwdRule" value="<?=$index?>">
            <INPUT type="submit" value=" Delete ">
         </FORM>
      </TD>
   </TR>
   <?
      $index++;
   }
   ?>
   <FORM name="AddFwdRuleForm">
      <INPUT type="hidden" name="AddFwdRule" value="AddFwdRule">
      <TR>
         <TD>
            <INPUT type="text" name="Index" size="2" />
         </TD>
         <TD>
            <INPUT type="text" name="VIP" size="12" />
         </TD>
         <TD>
            <PRE>Is <INPUT type="checkbox" name="NegateFlag" />NOT</PRE>
         </TD>
         <TD>
            <INPUT type="text" name="Subnet" value="0.0.0.0/0" size="18" />
         </TD>
         <TD><INPUT type="text" name="PortBegin" value="0" size="5" />-<INPUT
               type="text" name="PortEnd" value="65535" size="5" />
         </TD>
         <!--TD> </TD-->
         <TD>
            <INPUT type="checkbox" name="EnabledFlag" "checked" />Enable
         </TD>
         <TD>
            <INPUT type="Submit" name="AddFwdRule" value="   Add  " type="Get" />
         </TD>
      </TR>
   </FORM>
</TABLE>

<br />

<DIV class=helptext>
   <IMG src="./images/icon-info.gif">&nbsp;
   The forwarding rules are applied to packet source and destination addresses.
</DIV>

<BR />

<DIV class=helptext>
   <IMG src="./images/icon-info.gif">&nbsp;
   Group mode can be used to allow acceleration in deployments with multiple
   redundant WAN routes.
</DIV>

<? include(HTTP_ROOT_INCLUDES_DIR ."footer.php"); ?>
