<?
   define('PAGE_IS_HA_CLUSTER_INDEPENDANT', true);
   include("includes/header.php");
   $Auth->CheckRights(AUTH_LEVEL_ADMIN);
?>


<font class="pageheading">Configure Settings: Date/Time</font><BR><BR>

<FORM>
<TABLE class=settings_table>
   <!-- SYSTEM TIME -->
   <?
   if ( isset($_GET["SetDate"]) )
   {
      $TimeZone  = $_GET["TimeZone"];
      $NTPServer = $_GET["NTPServer"];
      $DateValue = $_GET["DateValue"];

      if ($DateValue!=$_GET["OldDateValue"]){
         $SetCommand = "/usr/bin/sudo /bin/date --set=\"$DateValue\"";
         system($SetCommand);
      }
      
      SetParameter("UI.Time.NTPServer", $_GET["NTPServer"]);
      SetParameter("UI.Time.TimeZone",  $_GET["TimeZone"]);

      putenv("TZ=" . $TimeZone);
   }
   
   
   $NTPServer = GetParameter("UI.Time.NTPServer");
   $TimeZone  = GetParameter("UI.Time.TimeZone");
 
   //
   // Read and parse the zone file
   //
   $zonefile = fopen("/usr/share/zoneinfo/zone.tab", "r");
   if (!$zonefile){ ThrowException("Unable to open zone.tab file!", true); }
   
   $timezones = array();
   array_push($timezones, "UTC");
   while (!feof($zonefile)){
      $line = fgets($zonefile, 1024);
      if ($line[0] != '#'){
         $entries = explode(chr(9), $line);
         
         if (sizeof($entries) > 2){
            array_push($timezones, trim($entries[2]));
         }
      }
   }
   sort($timezones);
   ?>

   <TR>
      <TH>Time Zone:</TH>
      <TD>
         <? 
            echo HTML_FORM::AddDropdown("TimeZone", $timezones, $timezones, array_search($TimeZone, $timezones) );
         ?>
      </TD>

   </TR>

   <TR>
      <TH>NTP Server:</TH>
      <TD>
         <INPUT type="text" name="NTPServer" value="<?=$NTPServer?>" size=20>
      </TD>

   </TR>

   <TR>
      <TH>Current Time:</TH>
      <TD>
         <INPUT type="text"   name="DateValue"    value="<? echo strftime ("%b %d, %Y %H:%M:%S"); ?>">
         <INPUT type="hidden" name="OldDateValue" value="<? echo strftime ("%b %d, %Y %H:%M:%S"); ?>">
      </TD>

   </TR>

   <TR><TH></TH><TD><INPUT type="submit" name="SetDate" value="Update"></TD></TR>
</TABLE>
</FORM>

<?
  #echo date("l dS of F Y h:i:s A T");
  #echo "<BR>";
  #echo strftime ("%b %d, %Y %H:%M:%S"); 
?>

<? include(HTTP_ROOT_INCLUDES_DIR ."footer.php"); ?>
