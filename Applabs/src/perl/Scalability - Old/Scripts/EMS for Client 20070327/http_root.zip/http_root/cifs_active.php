<?
   include("includes/header.php");
   $Auth->CheckRights(AUTH_LEVEL_VIEWER);


   function SortIt($a,$b) {
      if ($a["IdleTime"] == $b["IdleTime"]) return 0;
      return $a["IdleTime"] > $b["IdleTime"] ? 1 : -1;
   }

   function CifsRow($h,$n) {
      echo "<TR> <TH align=center> ",
      	$h,
      	" </th> <td align=center> ",
      	$n,
      	" </td> </tr>";
   }
?>





<?
      //
      // Display Graph auto refresh toggle
      //
      $GraphRefreshRate = GetParameter("UI.Graph.RefreshRate");
      $AutoRefresh      = GetParameter("UI.Graph.AutoRefresh");

      if (isset($_GET["ToggleAutoRefresh"]))
      {
         $AutoRefresh = !$AutoRefresh;
         SetParameter("UI.Graph.AutoRefresh", $AutoRefresh);
      }

      if ($AutoRefresh){
         echo HTML::InsertRedirect("./cifs_active.php", $GraphRefreshRate);
      }

?>
   <BODY>
      <div align="center">
         Auto-refresh <B><?=$AutoRefresh?"ON":"OFF"?></B>: <A href="./cifs_active.php?ToggleAutoRefresh">Toggle</A>
      </div>
   
      
   <br><br>
   <font class=pageheading>CIFS Status: Accelerated Connections</font><BR>

<?
   $S = OrbitalGet("SYSTEM",
   		array("CifsUnacceleratedConnections",
   			"CifsUnhandledOperations",
   			"CifsProtocolErrors",
   			"CifsLockBreaks",
   			"CifsWriteIoErrors",
   			"CifsWriteBehindBytes",
   			"CifsDiscardedReadBytes",
   			"CifsReadAheadBytes",
   			"CifsActiveCount",
   			"CifsPassthroughCount",
   			"CifsUnacceleratedReqs",
   			"CifsAcceleratedReqs"
   			));
   echo "<br><br><br>";
   echo "<TABLE class=settings_table>";
   CifsRow("Currently Active Accelerated Connections:",$S["CifsActiveCount"]);
   CifsRow("Currently Active Non-accelerated Connections:",$S["CifsPassthroughCount"]);
   if ($S["CifsUnacceleratedConnections"] != 0) CifsRow("Historically Non-accelerated Connections",$S["CifsUnacceleratedConnections"]);
   if ($S["CifsWriteIoErrors"] != 0) CifsRow("Historical write accelerated operations reporting errors",$S["CifsWriteIoErrors"]);
   if ($S["CifsUnhandledOperations"] != 0) CifsRow("Historical unhandled protocol operations",$S["CifsUnhandledOperations"]);
   if ($S["CifsProtocolErrors"] != 0) CifsRow("Historical protocol errors detected",$S["CifsProtocolErrors"]);
   if ($S["CifsLockBreaks"] != 0) CifsRow("Lock Breaks",$S["CifsLockBreaks"]);
   echo "</TABLE>";

   $CifsInstances = GetInstances("CIFS");
   $Conns = OrbitalGet("CIFS",array("ConnectionInstanceNumber","TotalReadAheadBytes","TotalWriteBehindBytes","Passthrough"),
               $CifsInstances["Instances"]);
   $CifsConnections = array();
   foreach($Conns as $OneCon) {
      array_push($CifsConnections,$OneCon["ConnectionInstanceNumber"]);
   }
   $Attributes = array("ClientLogicalAddress", "ClientPhysicalAddress",
                        "ServerLogicalAddress", "ServerPhysicalAddress",
                        "Duration", "InstanceNumber", "BytesTransferred", "IdleTime", "Accelerated", "Agent", "FilterInstanceNumber");
   $Cifs = OrbitalGet("CONNECTION",$Attributes,$CifsConnections);
   //
   // Now, graft the Totals onto the specific instances
   //
   $i = 0;
   foreach($Conns as $OneCon) {
      $Cifs[$i]["TotalReadAheadBytes"] = $OneCon["TotalReadAheadBytes"];
      $Cifs[$i]["TotalWriteBehindBytes"] = $OneCon["TotalWriteBehindBytes"];
      $Cifs[$i]["CifsPassthrough"] = $OneCon["Passthrough"];
      $i = $i + 1;
   }

   //
   // Now sort into the two bins, pipelined and unpipelined connections
   //
   $Pipe = array();
   $Unpipe = array();
   foreach($Cifs as $OneCon) {
      if ($OneCon["CifsPassthrough"] == 1) {
         array_push($Unpipe,$OneCon);
      } else {
         array_push($Pipe,$OneCon);
      }

   }

   //
   // List the unaccelerated connections (or at least the first ten)
   //
   usort($Unpipe,"SortIt");
   ?>
      <BR><BR>
      <TABLE class=settings_table2 width=100%>
      <tr> <th colspan=7><?=sizeof($Unpipe)?> Non-accelerated CIFs Connections </th></tr>
      <tr>
         <th>Details</th>
         <th>Client</th>
         <th></th>
         <th>Server</th>
         <th>Duration</th>
         <th>Idle</th>
        <TH>Remote Unit</TH>
     </tr>
   <?
   for ($i = 0; $i < 10 && $i < sizeof($Unpipe); $i = $i + 1) {
      $OneConnection = $Unpipe[$i];
      $ClientAddress = FormatIPAddressPort($OneConnection["ClientLogicalAddress"], false);
      $ServerAddress = FormatIPAddressPort($OneConnection["ServerLogicalAddress"]);
      $BytesTransferred = $OneConnection["BytesTransferred"];
      if ($OneConnection["Agent"]["Accelerated"]) {
         $Agent = FormatAgent($OneConnection["Agent"]);
      } else {
         $Agent = "<i>None</i>";
      }
      $Duration      = $OneConnection["Duration"];
      $InstanceNumber = $OneConnection["InstanceNumber"];
      $IdleTime = $OneConnection["IdleTime"];
      ?>
       <TR>
         <TD align=center><a href="./connection_info.php?InstanceNumber=<?=$InstanceNumber?>">
            <img src="./images/icon-info.gif" border="0" alt="Click Here For Detailed Connection Information"> </a></TD>
         <TD><?=$ClientAddress?></TD>
         <TD align="center"><=></TD>
         <TD><?=$ServerAddress?></TD>
         <TD align="center"><?=(int)$Duration?>&nbsp;secs</TD>
         <TD align="center"><?=(int)$IdleTime?>&nbsp;secs</TD>
         <TD align="center"><?=$Agent?></TD>
       </TR>

<? }  ?>
   </table>

   <BR><BR>
   <TABLE  class=settings_table2 width=100%>
      <TR><TH colspan=9><?=sizeof($Pipe)?> Accelerated CIFS Connection</TH></TR>
      <TR>
         <TH>Details</TH>
         <TH>Client</TH>
         <TH></TH>
         <TH>Server</TH>
         <TH>Duration</TH>
         <TH>Idle</TH>
         <TH>Read</TH>
         <TH>Write</TH>
         <TH>Remote Unit</TH>
      </TR>
<?

   usort($Pipe,"SortIt");
   foreach ($Pipe as $OneConnection)
   {
         $ClientAddress = FormatIPAddressPort($OneConnection["ClientLogicalAddress"], false);
         $ServerAddress = FormatIPAddressPort($OneConnection["ServerLogicalAddress"]);
         $BytesTransferred = $OneConnection["BytesTransferred"];
         if ($OneConnection["Agent"]["Accelerated"]) {
            $Agent = FormatAgent($OneConnection["Agent"]);
         } else {
            $Agent = "<i>None</i>";
         }
         $Duration      = $OneConnection["Duration"];
         $InstanceNumber = $OneConnection["InstanceNumber"];
	     $IdleTime = $OneConnection["IdleTime"];
   ?>
         <TR>
            <TD align=center><a href="./connection_info.php?InstanceNumber=<?=$InstanceNumber?>">
               <img src="./images/icon-info.gif" border="0" alt="Click Here For Detailed Connection Information"> </a></TD>
            <TD><?=$ClientAddress?></TD>
            <TD align="center"><=></TD>
            <TD><?=$ServerAddress?></TD>
            <TD align="center"><?=(int)$Duration?>&nbsp;secs</TD>
            <TD align="center"><?=(int)$IdleTime?>&nbsp;secs</TD>
            <TD align="center"><?=FormatBytes($OneConnection["TotalReadAheadBytes"])?></TD>
            <TD align="center"><?=FormatBytes($OneConnection["TotalWriteBehindBytes"])?></TD>
            <TD align="center"><?=$Agent?></TD>
         </TR>
   <?
   }

?>

<? include(HTTP_ROOT_INCLUDES_DIR . "footer.php"); ?>
