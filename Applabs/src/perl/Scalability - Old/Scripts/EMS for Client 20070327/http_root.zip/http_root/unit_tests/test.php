<?php

require_once '../PHPUnit/TestCase.php';
require_once '../PHPUnit/TestResult.php';
require_once '../PHPUnit/TestSuite.php';
require_once '../PHPUnit/PHPUnit.php';

/**
 * Test of PHP unit code
 *
 */
  class MathTest extends PHPUnit_TestCase {
      var $fValue1;
      var $fValue2;
 
     function MathTest($name) {
       $this->PHPUnit_TestCase($name);
     }

     function setUp() {
       $this->fValue1 = 2;
       $this->fValue2 = 3;
     }

     function testAdd() {
       $this->assertTrue($this->fValue1 + $this->fValue2 == 5);
     }
     function testSub() {
       $this->assertTrue($this->fValue2 - $this->fValue1 == 1);
     }
 }

 $suite  = new PHPUnit_TestSuite('MathTest');
 $result = PHPUnit::run($suite);
 print $result->toHTML();
 ?>
