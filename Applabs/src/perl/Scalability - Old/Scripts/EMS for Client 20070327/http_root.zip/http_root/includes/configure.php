<?php
   //
   // Constants go here
   //
   define('PERF_GRAPH_DATAPOINTS', 60);
   define('RPC_SERVER', "localhost");
   define('RPC_URI', "/RPC2");
   define('RPC_PORT', "2050");
   define('OD_TEMP_DIR', "temp/");
   define('SYSTEM_TEMP_DIR', "/tmp/");
   
   //echo phpinfo();
   
   //
   // Are we Apache on Linux...
   //
   if (substr(php_uname(), 0, 7) != "Windows") 
   {
	   define('ORBITAL_ROOT', "/orbital/current/");
      define('HTTP_ROOT_INCLUDES_DIR', ORBITAL_ROOT . "http_root/includes/");
	   define('HTTP_ROOT_DIR', ORBITAL_ROOT . "http_root/");
      define('RUNNING_WINDOWS', false);
   
   //
   // Or are we IIS on Windows
   //
   }elseif ($_SERVER["SERVER_SOFTWARE"] == "Microsoft-IIS/5.1")
   {
      define('ORBITAL_ROOT', "." ); // Seems like this isn't needed anymore
      define('HTTP_ROOT_DIR', getcwd () . "/");      
      define('HTTP_ROOT_INCLUDES_DIR', HTTP_ROOT_DIR. "includes/");
      define('RUNNING_WINDOWS', true);

   //
   // Or are we Apache on Windows
   //
   } else 
   {   	
	   define('ORBITAL_ROOT', dirname($_SERVER["DOCUMENT_ROOT"]) );
	   define('HTTP_ROOT_DIR', ORBITAL_ROOT . "/http_root/");      
      define('HTTP_ROOT_INCLUDES_DIR', HTTP_ROOT_DIR. "includes/");
      define('RUNNING_WINDOWS', true);
   }
   define('BASE_URL', "http://" . $_SERVER["HTTP_HOST"] . "/");
   
   define('ORBITAL_BINARY_DIR', ORBITAL_ROOT . "server/");
   define('SYSTEM_DUMP_DIR', ORBITAL_ROOT . "http_root/temp/");  
   define('SYSTEM_TRACE_DIR', ORBITAL_ROOT . "server/Trace/");
   define('SYSTEM_LOG_DIR', ORBITAL_ROOT . "server/Log/");
   define('SCRIPT_DIR', ORBITAL_ROOT . "scripts/");
   
   define('ORB_WEB_MAN_PORT', 80);
   define('GRAPH_DEFAULT_REFRESH_RATE', 10);
   define('RESTART_TIME', 280);
   define('RESTART_TIME_HA', 10);
   define('INSTALL_TIME', 460);

   define('ADMIN_PW_DEFAULT', "fec735026372d0b1af114bc215ac11c38a074c1c");
   define('SUPERUSER_PW_DEFAULT', "1282bca9c4c2d2abf754f1b340fdd71ac07c586f");
?>
