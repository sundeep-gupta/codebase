<?
   include("includes/header.php");
   $Auth->CheckRights(AUTH_LEVEL_ADMIN);

   $SoftboostEnable = isSoftboost();
   $PartialBandwidth = GetParameter("Adapter.PassthroughTrafficAccount");
   $MinSendRate = (int)(GetParameter("Adapter.PassthroughMinAccelTxRate") / 1000);
   $LinkSendRate = (int)(GetParameter("SlowSendRate") / 1000);
   if ($PartialBandwidth)
      $ParentMinBw = $MinSendRate;
   else
      $ParentMinBw = $LinkSendRate;
   $ParentMaxBw = $ParentMinBw;
   $ParentShare = 100;

   $queueTextFieldName = array("A", "B", "C", "D", "E");
   $bdwShareTextFieldName = array("share0", "share1", "share2", "share3", "share4");

   // from onUpdate()->submit()
   if (isset($_GET["share0"]) || isset($_GET["share1"]) || isset($_GET["share2"]) || isset($_GET["share3"]) || isset($_GET["share4"])) {
      UpdateShare();
   }
   if (isset($_GET["A"]) || isset($_GET["B"]) || isset($_GET["C"]) || isset($_GET["D"]) || isset($_GET["E"])) {
      UpdateQueueName();
   }
   ?>

<Script>
   String.prototype.trim =      function() {
     return (this.replace(/^[\s\xA0]+/, "").replace(/[\s\xA0]+$/, ""));
   }

   function onUpdate() {
      var subform=document.QosAcceleratedShare;
      // x100: handle 2 decimal points
      // parseInt() loses decimals. divide / won't
      // parseInt("10.2") -> 10.19 :(
/*
      intShare = new Array(
            parseInt(100*subform.share0.value)/100,
            parseInt(100*subform.share1.value)/100,
            parseInt(100*subform.share2.value)/100,
            parseInt(100*subform.share3.value)/100,
            parseInt(100*subform.share4.value)/100
          );
*/
      floatShare = new Array(
            parseFloat(subform.share0.value),
            parseFloat(subform.share1.value),
            parseFloat(subform.share2.value),
            parseFloat(subform.share3.value),
            parseFloat(subform.share4.value)
          );
      // trim leading and trailing blanks
      subform.A.value = subform.A.value.trim();
      subform.B.value = subform.B.value.trim();
      subform.C.value = subform.C.value.trim();
      subform.D.value = subform.D.value.trim();
      subform.E.value = subform.E.value.trim();
      QueueName = new Array(
            subform.A.value,
            subform.B.value,
            subform.C.value,
            subform.D.value,
            subform.E.value
          );

      // validate queue name
      for (var i=0; i<QueueName.length; i++)
      {
         if (QueueName[i].length == 0)
         {
            alert ("Error: empty service group/queue name for queue " + i);
            return false;
         }
      }
      for (var i=0; i<QueueName.length-1; i++)
      for (var j=i+1; j<QueueName.length; j++)
      {
         if (QueueName[i] == QueueName[j])
         {
            alert ("Error: duplicate service group/queue name " + QueueName[i]);
            return false;
         }
      }

      // validate bdw share
      var SubtotalShare = 0;
      for (var i=0; i<floatShare.length; i++)
         SubtotalShare += floatShare[i];
      for (var i=0; i<floatShare.length; i++) {
         if (floatShare[i]<0 || floatShare[i]>100) {
            alert ("Error: " + QueueName[i] + " Bdw Share " + floatShare[i] + " out of range [0..100]%");
            return false;
         }
         else if (floatShare[i]%1 > 0 && floatShare[i]%1 < 1) {
            alert ("Error: " + QueueName[i] + " Bdw Share " + floatShare[i] + " contains decimal. Only integer % supported");
            return false;
         }
      }
      if (SubtotalShare != 100) {
         alert ("Error: Subtotal Sum " + SubtotalShare + " != 100%");
         //alert ("Error: Subtotal Sum " + SubtotalShare/100 + "." + SubtotalShare%100 + " != 100.00%");
         return false;
      }

      subform.submit();
      return true;
   }
</Script>



   <!-- ------------------------------------------------- -->
   
   <BR><font class="pageheading">Configure Settings: QoS (Quality of Service)</font><BR><BR>
   <BR><font class="pageheading">WAN Link Egress Bandwidth Allocation</font><BR><BR>
   <TABLE class=settings_table >


      <TR>
      <TH>Traffic Type</TH><TH title="Guaranteed minimum bw, configured from Bdw Mgmt page">Min Guaranteed Bw (Kbps)</TH> <TH title="bdw limit at sharing excessive bw">Max Bw (Kbps)</TH>
      </TR>

      <!-- BEGIN FULL Mgmt Entry RENDERING -->

      <FORM name="QosConfigForm" action="qos.php">
         <INPUT type="hidden" name="Action" value="AddMgmt">

         <TR>
            <TD>Accelerated TCP Traffic</TD>

            <TD>
            <?
                if ($PartialBandwidth)
                   echo $MinSendRate;
                else
                   echo $LinkSendRate;
            ?>
            </TD>
            <TD>
                <?echo $LinkSendRate?>
            </TD>

         </TR>
         <TR>
            <TD>Unaccelerated Traffic</TD>

            <TD>
            <?
                if ($PartialBandwidth)
                   echo $LinkSendRate - $MinSendRate;
                else
                   echo 0
            ?>
            </TD>
            <TD>
                <?echo $LinkSendRate?>
            </TD>

         </TR>
      <TR>
         <TH>Total Bw Limit (Send)</TH>
         <TH><?echo $LinkSendRate?></TH>
         <TH><?echo $LinkSendRate?></TH>
      </TR>
      </FORM>
      </TABLE>
      


   <BR><BR><font class="pageheading">WAN Link Egress Bandwidth Allocation: Accelerated TCP Traffic</font><BR><BR>
<?
   $Table = new HTML_TABLE();
   $ParamForm = new HTML_PARAMETER_FORM();
   // Pamameter.txt: pN scaled up 100
   $BdwShare = GetParamAsStruct("QosAcceleratedBdwShare");
   $SubtotalShare = 0;
   for ($i=0; $i<sizeof($BdwShare); $i++) {
      $SubtotalShare += $BdwShare[$i];
   }
   $SubtotalBw = $SubtotalShare* $ParentMinBw / 100;
   $QueueName = GetParamAsStruct("AcceleratedTcpQueueName");
   echo
      $Table->Begin("settings_table"),
      $ParamForm->Begin("QosAcceleratedShare"),
      "<TR> <TH>QoS Traffic Class</TH><TH title=\"integer %, [0..100], sum=100%\">Bandwidth Share (%)</TH><TH title=\"Guaranteed minimum bw\">Min Guaranteed Bw (Kbps)</TH> <TH title=\"bw limit at sharing excessive bw\">Max Bw (Kbps)</TH> </TR>",
      //$Table->AddEntry4Name("Service Group", "Bdw Share (%)", "Guaranteed Min Bdw (Kbps)", "Max Bdw (Kbps)" ),
/*
      for ($i=0; $i<sizeof($QueueName); $i++) {
         $Table->AddEntry4($ParamForm->AddTextField($queueTextFieldName[$i], $QueueName[$i], 12), $ParamForm->AddTextField($bdwShareTextFieldName[$i], $BdwShare[$i], 10), $BdwShare[$i] * $ParentMinBw / 100, "fill up" ),
      }
*/
      $Table->AddEntry4($ParamForm->AddTextField("A", $QueueName[0], 12), $ParamForm->AddTextField("share0", $BdwShare[0], 10), $BdwShare[0] * $ParentMinBw / 100, $LinkSendRate ),
      $Table->AddEntry4($ParamForm->AddTextField("B", $QueueName[1], 12), $ParamForm->AddTextField("share1", $BdwShare[1], 10), $BdwShare[1] * $ParentMinBw / 100, $LinkSendRate ),
      $Table->AddEntry4($ParamForm->AddTextField("C", $QueueName[2], 12), $ParamForm->AddTextField("share2", $BdwShare[2], 10), $BdwShare[2] * $ParentMinBw / 100, $LinkSendRate ),
      $Table->AddEntry4($ParamForm->AddTextField("D", $QueueName[3], 12), $ParamForm->AddTextField("share3", $BdwShare[3], 10), $BdwShare[3] * $ParentMinBw / 100, $LinkSendRate ),
      $Table->AddEntry4($ParamForm->AddTextField("E", $QueueName[4], 12), $ParamForm->AddTextField("share4", $BdwShare[4], 10), $BdwShare[4] * $ParentMinBw / 100, $LinkSendRate ),
      $Table->AddEntry4Name("Subtotal Sum", $SubtotalShare, $SubtotalBw, 
      $ParamForm->AddButton("QosAcceleratedShare", "Update",  "return onUpdate()") ),
      $Table->AddEntry4Name("Subtotal Avail", 100, $ParentMinBw, "" ),
      $ParamForm->End(),
      $Table->End();

   function UpdateShare() {
      $bdwShareTextFieldName = array("share0", "share1", "share2", "share3", "share4");
      $shares = array();
      for ($i=0; $i<sizeof($bdwShareTextFieldName); $i++) {
         array_push($shares, $_GET[$bdwShareTextFieldName[$i]]);
      }
      SetParamAsStruct("QosAcceleratedBdwShare", $shares);
   }

   function UpdateQueueName() {
      $queueTextFieldName = array("A", "B", "C", "D", "E");
      $names = array();
      for ($i=0; $i<sizeof($queueTextFieldName); $i++) {
         array_push($names, $_GET[$queueTextFieldName[$i]]);
      }
      SetParamAsStruct("AcceleratedTcpQueueName", $names);
   }
?>



<? include(HTTP_ROOT_INCLUDES_DIR ."footer.php"); ?>

