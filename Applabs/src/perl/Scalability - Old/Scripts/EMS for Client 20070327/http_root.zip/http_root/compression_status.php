<?
   define('PAGE_REQUIRES_COMPRESSION_LICENSE', true);
   include("includes/header.php");
   
   $Auth->CheckRights(AUTH_LEVEL_VIEWER);

   //
   // Display Graph auto refresh toggle
   //
   $GraphRefreshRate = GetParameter("UI.Graph.RefreshRate");
   $AutoRefresh      = GetParameter("UI.Graph.AutoRefresh");

   if (isset($_GET["ToggleAutoRefresh"]))
   {
      $AutoRefresh = !$AutoRefresh;
      SetParameter("UI.Graph.AutoRefresh", $AutoRefresh);
   }

   if ($AutoRefresh){
      echo HTML::InsertRedirect("./compression_status.php", $GraphRefreshRate);
   }

   $CompressionStats = OrbitalGet("SYSTEM",
         array(
               "CompressConnectionCount",
               "CompressionClearTextBytes",
               "CompressionCipherTextBytes",
               "DecompressionClearTextBytes",
               "DecompressionCipherTextBytes",
               "TimeSincePerfCounterReset"
            ));

   $UncompressedSent = $CompressionStats["CompressionClearTextBytes"]["Total"];
   $CompressedSent   = $CompressionStats["CompressionCipherTextBytes"]["Total"];

   $UncompressedRecv = $CompressionStats["DecompressionClearTextBytes"]["Total"];
   $CompressedRecv   = $CompressionStats["DecompressionCipherTextBytes"]["Total"];

   $TimeSincePerfCounterReset = (int)$CompressionStats["TimeSincePerfCounterReset"];

   $SendCompRatio    = FormatRatio($UncompressedSent,	$CompressedSent);
   $RecvCompRatio    = FormatRatio($UncompressedRecv, $CompressedRecv);

   $SlowSendRate        = GetParameter("SlowSendRate");
   if (($CompressedSent + $CompressedRecv) != 0) {
      $EffectiveThroughput = (($UncompressedSent + $UncompressedRecv) / ($CompressedSent + $CompressedRecv)) * $SlowSendRate;
   }else{
      $EffectiveThroughput = "N/A";
   }

	if (isset($_GET["ResetStats"])) {
      CallRPCMethod("ResetPerfCounters");
      echo HTML::InsertRedirect("./compression_status.php",2);
		exit();
   }

   $SelectedTab = CreateTabs("CompressionStatus", 
              array("ShowCompressionStatus"    => "Compression Status", 
                    "ShowCompressionBreakdown" => "Compression Breakdown")
             );
?>


      <center>
         <br>
         Auto-refresh <B><?=$AutoRefresh?"ON":"OFF"?></B>: <A href="./compression_status.php?ToggleAutoRefresh">Toggle</A><p></p>
      </center> 

<?   
      ///////////////////////////////////////////////////////////////////////////
      // Show compression breakdown
      ///////////////////////////////////////////////////////////////////////////
      if ( $SelectedTab == "ShowCompressionBreakdown" ){
         echo "<div align=center>" .
                  "<center>" . 
                  "<img src='images/compression_breakdown_legend.png'><br><br>" .
                  "</center>"; 

                  $GraphName = DrawCompressionBreakdownChart("LastMinute");

                  echo "<img src='$GraphName?NoCache=" . time() . "' name=$GraphName>";
                  echo "<br><br>";

?>
      <br><br>
   </div>
<?  }else{  
      ///////////////////////////////////////////////////////////////////////////
      // Show compression ratio
      ///////////////////////////////////////////////////////////////////////////

         $GraphMaxY = max($UncompressedSent, $CompressedSent, $UncompressedRecv, $CompressedRecv);
         
         echo "<BR><BR>";
         echo "<font class=pageheading>Compression Status: Data Before And After Compression</font><BR><BR>";
         
         $SendChartname = DrawCompressionBarChart_Send();
	      echo "<IMG src='$SendChartname?NoCache=<?=time()?>'> ";

         $RecvChartname = DrawCompressionBarChart_Recv();
	      echo "<IMG src='$RecvChartname?NoCache=<?=time()?>'>";
            //echo "<font color=red>No compressed connections have flowed through the Appliance</font>";
?>
   <br><br><br>

   <TABLE class="settings_table">
		<TR><TH>Uncompressed Bytes Sent:</TH> <TD><?=FormatBytes($UncompressedSent)?></TD></TR>
		<TR><TH>Compressed Bytes Sent:</TH>   <TD><?=FormatBytes($CompressedSent)?></TD></TR>
		<TR><TH>Send Compression Ratio:</TH><TD><?=$SendCompRatio?></TD></TR>

		<TR></TR>
		<TR><TH>Uncompressed Bytes Recv:</TH> <TD><?=FormatBytes($UncompressedRecv)?></TD></TR>
		<TR><TH>Compressed Bytes Recv:</TH>   <TD><?=FormatBytes($CompressedRecv)?></TD></TR>
		<TR><TH>Recv Compression Ratio:</TH><TD><?=$RecvCompRatio?></TD></TR>

		<TR></TR>
		<TR><TH>Effective Bandwidth:</TH><TD><?=FormatThroughput($EffectiveThroughput)?></TD></TR>

		<TR></TR>
		<TR><TH>Elapsed Time Collecting Stats:</TH><TD><?=ToPrintableTime($TimeSincePerfCounterReset)?></TD></TR>

		<TR></TR>
		<TR><TH>Clear These Compression Stats:</TH>
            <TD>
               <FORM name="ResetStats"><INPUT type="submit" name="ResetStats" value="Clear"></INPUT></FORM>
            </TD>
      </TR>

   </TABLE>
<? } ?>

<? include(HTTP_ROOT_INCLUDES_DIR ."footer.php"); ?>
