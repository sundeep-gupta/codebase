<?php

require_once '../PHPUnit/TestResult.php';
require_once '../PHPUnit/TestSuite.php';
require_once '../PHPUnit/PHPUnit.php';
include 'serviceClassTest.php';


	echo 'WANScaler UI Unit Tests: ';
	$suite  = new PHPUnit_TestSuite('ServiceClassTest');
	$result = PHPUnit::run($suite);
	print $result->toHTML();
?>
