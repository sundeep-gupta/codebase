<?
   define('PAGE_IS_HA_CLUSTER_INDEPENDANT', true);
   define('DONT_REQUIRE_RUNNING_SERVER', true);
   include("includes/header.php");

   $DisplayableResponse = "";
   
   //
   // Perform the ping test
   //
   if (isset($_GET["Ping"])){
      $IPAddress = $_GET["IPAddress"];
      $DataSize  = $_GET["DataSize"];
      $NumPings  = $_GET["NumPings"];
      $SendInterface = $_GET["Interface"];
      $Address   = "0.0.0.0";
      $found     = 0;

      $Param["Class"] = "SYSTEM";
      $Param["Attribute"] = "IpAddressConfiguration";
      $IpConfiguration = GetSystemParam("IpAddressConfiguration");

      foreach ($IpConfiguration['SortOrder'] as $Interface) {
         $ThisInterface = $IpConfiguration[$Interface];
         if($ThisInterface['DeviceName'] == $SendInterface) {
             $Address = $ThisInterface['Address']['Dotted'];
             $found = 1;
             break;
         }
      }
      if ( $found) {
          // $Interface here is an IP address
          exec ("/bin/ping -s $DataSize -I $Address -c $NumPings $IPAddress", $PingResponse);

          foreach ($PingResponse as $Line){
             $DisplayableResponse .= $Line . "<BR>\n";   
          }
      }
      echo "<B>Ping Response:</B><BR><BR>\n";
   }
   //
   // Perform the traceroute test
   //
   elseif (isset($_GET["Traceroute"])){
      $IPAddress = $_GET["IPAddress"];
      $MaxHops  = $_GET["MaxHops"];
      $SendInterface = $_GET["Interface"];
      $Address   = "0.0.0.0";
      $found     = 0;

      $Param["Class"] = "SYSTEM";
      $Param["Attribute"] = "IpAddressConfiguration";
      $IpConfiguration = GetSystemParam("IpAddressConfiguration");

      foreach ($IpConfiguration['SortOrder'] as $Interface) {
         $ThisInterface = $IpConfiguration[$Interface];
         if($ThisInterface['DeviceName'] == $SendInterface) {
             $Address = $ThisInterface['Address']['Dotted'];
             $found = 1;
             break;
         }
      }
      if ( $found) {
          // $Interface here is an IP address
          exec ("/usr/sbin/traceroute -n -m $MaxHops -s $Address -z 100 $IPAddress", $TracerouteResponse);

          foreach ($TracerouteResponse as $Line){
             $DisplayableResponse .= $Line . "<BR>\n";   
          }
      }
      echo "<B>Traceroute Response:</B><BR><BR>\n";
   }
   
   //
   // Display the results
   //
   echo $DisplayableResponse;

?>
