<?
   define('PAGE_IS_HA_CLUSTER_INDEPENDANT', true);
   include("includes/header.php");  
   $Auth->CheckRights(AUTH_LEVEL_ADMIN);
?>

<?
$Param["Class"] = "SYSTEM";
$Param["Attribute"] = "IpAddressConfiguration";
$IpConfiguration = GetSystemParam("IpAddressConfiguration");

$UpdateSettings = false;
$FoundRedirectIPAddress = false;
if (isset($_GET['Hostname'])) { 
   $NewSettings['Hostname'] = $_GET['Hostname']; 
   $NewSettings['Dns']['Dotted'] = $_GET['DNSServer'];
}
foreach ($IpConfiguration['SortOrder'] as $Interface) {
   if (isset($_GET[$Interface . '_IPAddress'])) {
      $NewSettings[$Interface]['DeviceName'] = $Interface;
      $NewSettings[$Interface]['DisplayName'] = 'Unused';
      $NewSettings[$Interface]['Dhcp'] = false;
      $NewSettings[$Interface]['Enable'] = isset($_GET[$Interface . '_Enable']);
      $NewSettings[$Interface]['Address']['Dotted'] = $_GET[$Interface . '_IPAddress'];
      if (( $FoundRedirectIPAddress == false)  && 
           $NewSettings[$Interface]['Enable']) {
          $RedirectIPAddress = $NewSettings[$Interface]['Address']['Dotted'];
          $FoundRedirectIPAddress = true;
      }
      $NewSettings[$Interface]['Mask']['Dotted'] = $_GET[$Interface . '_NetworkMask'];
      $NewSettings[$Interface]['Gateway']['Dotted'] = $_GET[$Interface . '_Gateway'];
      $NewSettings[$Interface]['UseVlan'] = isset($_GET[$Interface . '_UseVlan']) ? 1 : 0;
      $NewSettings[$Interface]['VlanTag'] = $_GET[$Interface . '_VlanTag'] ? $_GET[$Interface . '_VlanTag'] : 0;
      $UpdateSettings = true;
   }
}

if ($UpdateSettings) {
   $Results = SetSystemParam('IpAddressConfiguration', $NewSettings);
   HTML::InsertCountdownRedirect(RESTART_TIME, "http://" . $RedirectIPAddress . "/index.php");
   SendCommand("reboot", "");
   exit();
 }

$RearPanel   =    GetParameter("UI.RearImageFileName");

if ( $RearPanel != "" ) {
   $RearPanel = "./images/" . $RearPanel;
 }
?>

<Script>
<!--
function confirmSubmit() {

   if(HostnameCheck(document.UpdateNetworkSettings.Hostname, "Hostname")) return;      
   if(IPAddressCheck(document.UpdateNetworkSettings.DNSServer , "DNSServer")) return;

   <?
   foreach ($IpConfiguration['SortOrder'] as $Interface) {
      $ThisInterface = $IpConfiguration[$Interface];
   ?>
         if (IPAddressCheck(document.UpdateNetworkSettings.<?=$Interface?>_IPAddress, "IP Address")) return;
         if (IPAddressCheck(document.UpdateNetworkSettings.<?=$Interface?>_NetworkMask, "Network Mask")) return;       
         if (IPAddressCheck(document.UpdateNetworkSettings.<?=$Interface?>_Gateway, "Gateway")) return; 

         if(document.UpdateNetworkSettings.<?=$Interface?>_UseVlan.checked && 
            !isNumberInRange(document.UpdateNetworkSettings.<?=$Interface?>_VlanTag.value, 0, 4095)) {
            alert("VLAN Tag is not valid.  It must be in range 0 - 4095");
            return;
         }
   <?
   }
   ?>

   if (!confirm("Are you sure you wish to change the network settings and restart this Unit (This will take serveral minutes)?")) {
      return;
   }
   
   var subform=document.UpdateNetworkSettings;
   subform.submit();
   return;
}
// -->
</Script>

<font class="pageheading">Configure Settings: IP Addresses</font><BR><BR>

   <?  if ( $RearPanel != "" ) { ?>
            <IMG src = <?=$RearPanel?> >
            <BR>
            <BR>
   <? } ?>

    <FORM name="UpdateNetworkSettings" action="managementip.php">

      <TABLE class=settings_table width=80%>
        <COLGROUP width=50% span=2> </COLGROUP>
        <TR>
          <TH COLSPAN=2>
            <font class="pageheading"> 
              Common Management Settings
            </font>
          </TH>
        </TR>

        <TR>
          <TH>
            DNS Server:
          </TH>
          <TD>
            <INPUT name="DNSServer" SIZE="25" MAXLENGTH="25" type="text" value="<?=$IpConfiguration['Dns']['Dotted']?>"></INPUT>
          </TD>
        </TR>
        <TR>
          <TH>
            Hostname:
          </TH>
          <TD>
            <INPUT name="Hostname" SIZE="64" MAXLENGTH="64" type="text" value="<?=$IpConfiguration['Hostname']?>"></INPUT>
          </TD>
        </TR>
      </TABLE>

      <BR>
      <BR>


      <?
      foreach ($IpConfiguration['SortOrder'] as $Interface) {
         $ThisInterface = $IpConfiguration[$Interface];
      ?>

      <TABLE class=settings_table width=80%>
        <COLGROUP width=50% span=2> </COLGROUP>
        <TR>
          <TH COLSPAN=2>
            <font class="pageheading"> 
              <? print $ThisInterface['DisplayName'] ?>
            </font>
          </TH>
        </TR>
        <TR>
          <TH>
          </TH>
          <TD>
            <table class=settings_table_layout width=60% >
              <tr>
                <td>
                  Enabled:
                </td>
                <td>
                  <INPUT type="checkbox" <?if($ThisInterface['Enable'])echo "checked";?> name="<?=$Interface?>_Enable" value="<?=$ThisInterface['Enable']?>"></INPUT>
                </td>
              </tr>
            </table
          </TD>
        </TR>
        <TR>
          <TH>
            IP Address:
          </TH>
          <TD>
            <INPUT name="<?=$Interface?>_IPAddress" SIZE="15" MAXLENGTH="15" type="text" value="<?=$ThisInterface['Address']['Dotted']?>">
          </TD>
        </TR>
        <TR>
          <TH>
            Network Mask:
          </TH>
          <TD>
            <INPUT name="<?=$Interface?>_NetworkMask" SIZE="15" MAXLENGTH="15" type="text" value="<?=$ThisInterface['Mask']['Dotted']?>"></INPUT>
          </TD>
        </TR>
        <TR>
          <TH>
            Gateway:
          </TH>
          <TD>
            <INPUT name="<?=$Interface?>_Gateway" SIZE="15" MAXLENGTH="15" type="text" value="<?=$ThisInterface['Gateway']['Dotted']?>"></INPUT>
          </TD>
        </TR>
        <TR>
          <TH>
            VLAN:
          </TH>
          <TD>
            <table class=settings_table_layout width=80%>
              <tr>
                <td>
                  Enabled:
                </td>
                <td>
                  <INPUT type="checkbox" <?if($ThisInterface['UseVlan'])echo "checked";?> name="<?=$Interface?>_UseVlan" value="<?=$ThisInterface['UseVlan']?>">
                </td>
              </tr>
              <tr>
                <td>
                  Group:
                </td>
                <td>
                  <INPUT SIZE="6" MAXLENGTH="6" type="text" name="<?=$Interface?>_VlanTag" value="<?=$ThisInterface['VlanTag']?>">
                </td>
              </tr>
            </table>
          </TD>
        </TR>
      </TABLE>
      <br>
      <br>
   <?
   }
   ?>

      <br>
      <br>

      <font size:80pt>
        Changes on this page only take effect when an "update" is performed.
      </font><BR><BR>

      <TABLE class=settings_table width=80%>
        <COLGROUP width=50% span=2> </COLGROUP>
        <TR align=right>
          <TH>
            Apply these changes and Restart
          </TH>
          <TD>
            <INPUT type="button" name="UpdateNetworkSettings" value="Update" onClick="confirmSubmit()"></INPUT>
            <BR><BR>
            <BR><BR>
          </TD>
        </TR>
      </TABLE>
      
    </FORM>

<? include(HTTP_ROOT_INCLUDES_DIR ."footer.php"); ?>

