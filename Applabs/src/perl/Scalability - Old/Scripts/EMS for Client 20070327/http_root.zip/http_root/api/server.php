<?php

// first, include the SOAP/Server class
require_once 'SOAP/Server.php';

$server = new SOAP_Server;
/* tell server to translate to classes we provide if possible */
$server->_auto_translation = true;

//
// Define the SOAP RPC methods
//

// first, include the SOAP/Server class
require_once 'SOAP/Value.php';
require_once 'SOAP/Fault.php';

// SOAPStruct is defined in the following file
require_once 'example_types.php';

// create a class for your soap functions
class SOAP_WANScaler_Server {
    /**
     * The dispactch map does not need to be used, but aids
     * the server class in knowing what parameters are used
     * with the functions.  This is the ONLY way to have
     * multiple OUT parameters.  If you use a dispatch map, you
     * MUST add ALL functions you wish to allow be called.  If
     * you do not use a dispatch map, then any public function
     * can be called from soap (in php4, we consider this to be
     * any function in the class unless it starts with underscore,
     * php5 support is not complete yet in this regard).
     * if you do not define in/out parameters, the function can be
     * called with parameters, but no validation on parameters will
     * occure.
     */
    var $__dispatch_map = array();

    function SOAP_WANScaler_Server() {
        /**
        * when generating wsdl for a server, you have to define
        * any special complex types that you use (ie classes).
        * using a namespace id before the type will create an
        * xml schema with the targetNamespace for the type
        * multiple types with the same namespace will appear
        * in the same schema section.  types with different
        * namespaces will be in seperate schema sections.
        * the following SOAPStruct typedef cooresponds to the
        * SOAPStruct class above.
        */
        $this->__typedef['{http://soapinterop.org/xsd}SOAPStruct'] =
                    array(
                        'varString' => 'string',
                        'varInt' => 'int',
                        'varFloat' => 'float'
                         );

   $this->__dispatch_map['getConnections'] =
      array('in' => array('start' => 'int', 'count' => 'int'),
            'out' => array('return' => 'CONNECTIONArray'),
            );

   /**
   * Struct 'CONNECTION'
   */
   $this->__typedef['CONNECTION'] =
          array(
         'SrcIP' => 'string',
         'SrcPort' => 'int',
         'DstIP' => 'string',
         'DstPort' => 'int',
         'InstanceNum' => 'int',
         'BytesXfered' => 'string',
         'Duration' => 'string',
         'Idle' => 'string',
         'Compressed' => 'bool',
         'CompressionRatio' => 'string',
         'RemoteUnit' => 'string',
          );



   /**
   * CONNECTIONArray - array of 'CONNECTION' structs
   */
   $this->__typedef['CONNECTIONArray'] =
          array(
            array(
                'item' => 'CONNECTION'
            )
          );


        // an aliased function with multiple out parameters

   $this->__dispatch_map['echoStringSimple'] =
      array('in' => array('inputStringSimple' => 'string'),
            'out' => array('outputStringSimple' => 'string'),
            );

   $this->__dispatch_map['echoMimeAttachment'] = array();
    }

    /* this private function is called on by SOAP_Server to determine any
        special dispatch information that might be necessary.  This, for example,
        can be used to set up a dispatch map for functions that return multiple
        OUT parameters */
    function __dispatch($methodname) {
        if (isset($this->__dispatch_map[$methodname]))
            return $this->__dispatch_map[$methodname];
        return NULL;
    }


   // a simple echo array function
   function getConnections($start, $count)
   {
      if ($count > 1000){
         return new SOAP_Fault('You cannot query for more then 1000 connections at a time!', 'getConnections');
      }

      for($i = 0; $i < 5; $i++) {
         $this->Connections[$i] = new SOAP_Value(
                                             'item',
                                             'CONNECTION',
                                             array(
                                                   "SrcIP"         => new SOAP_Value("SrcIP","string","1.2.3.4"),
                                                   "SrcPort"        => new SOAP_Value("SrcPort","int","4321")
                                             )
         );
      }

      $MethodDebug["Total"]       = new SOAP_Value("Total","int",(integer)123);
      $MethodDebug["NumReturned"] = new SOAP_Value("NumReturned","int",(integer)123);

      return new SOAP_Value('return','GetMP3TracksResult',array(
           "MethodDebug" => new SOAP_Value('MethodDebug','MethodDebug',$MethodDebug),
           "CONNECTION"   => new SOAP_Value('CONNECTION','CONNECTIONArray',$this->Connections)
           )
       );



      for ($i = 0; $i < $count; $i++) {
         $return[$i] = "Foo - " . " $i";
      }
      return new SOAP_Value('return','MP3TracksArray',$return);
   }

    // a simple echoString function
    function echoStringSimple($inputString)
    {
   return $inputString;
    }

    // an explicit echostring function
    function echoString($inputString)
    {
   return new SOAP_Value('outputString','string',$inputString);
    }


}

//
// The SOAP server. Registers a listener
//
$soapclass = new SOAP_WANScaler_Server();
$server->addObjectMap($soapclass,'urn:SOAP_WANScaler_Server');

if (isset($_SERVER['REQUEST_METHOD']) &&
    $_SERVER['REQUEST_METHOD']=='POST') {
    $server->service($HTTP_RAW_POST_DATA);
} else {
    require_once 'SOAP/Disco.php';
    $disco = new SOAP_DISCO_Server($server,'ServerExample');
    header("Content-type: text/xml");
    if (isset($_SERVER['QUERY_STRING']) &&
       strcasecmp($_SERVER['QUERY_STRING'],'wsdl')==0) {
        echo $disco->getWSDL();
    } else {
        echo $disco->getDISCO();
    }
    exit;
}
?>