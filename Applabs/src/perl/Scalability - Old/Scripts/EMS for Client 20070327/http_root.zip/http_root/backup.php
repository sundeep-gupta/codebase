<?
define('PAGE_IS_HA_CLUSTER_INDEPENDANT', true);
include_once("includes/orbital_lib.php");
$Auth = new OD_AUTH();
$Auth->CheckLogin();
$Auth->CheckRights(AUTH_LEVEL_ADMIN);

function GetAllSerializedNonDefaultParameters($System=RPC_SERVER)
{
    $Result = xu_rpc_http_concise(
                                  array(
                                        'method' => "SerializeAllNonDefaultParameters",
                                        'args'   => "",
                                        'host'   => $System,
                                        'uri'    => RPC_URI,
                                        'port'   => RPC_PORT
                                        )
                                  );

    $Settings = $Result["ParameterStream"];
   
    return $Settings;
}

function RestoreSerializedParameters($Stream, $System=RPC_SERVER)
{
   //   $Param["ParameterStream"] = $Stream;
   $Param = $Stream;
   $Result = xu_rpc_http_concise(
                                 array(
                                       'method' => "RestoreSerializedParameters",
                                       'args'   => $Param,
                                       'host'   => $System,
                                       'uri'    => RPC_URI,
                                       'port'   => RPC_PORT
                                       )
                                 );

   print $Result;
}

if (isset($_GET['Download']) && stristr($_GET['Download'], "Download settings")) {
   $Settings = GetAllSerializedNonDefaultParameters();
   $Date = date("Ymd-His");
   $FileName = ProdNameWithoutSpaces() . "-" . GetHostname() . "-" . $Date . ".txt"; 
   header("Content-Type: text/plain");
   header("Content-Disposition: attachment; filename=$FileName");
   print $Settings;
} else if (isset($_POST['Restore'])) {
   if ($_FILES['settingsfile']['name']== "") {
      ThrowException("No settings file uploaded. Did you correctly select the settings file?", true);

   } else if ($_FILES['settingsfile']['size']== 0) {
      ThrowException("Unable to upload settings file.", true);

   } else if (!is_uploaded_file($_FILES['settingsfile']['tmp_name'])) {
      ThrowException("Internal error", true);

   } else {
      include_once("includes/header.php");
      $Settings = file_get_contents($_FILES['settingsfile']['tmp_name']);

      RestoreSerializedParameters($Settings);
      echo "File ". $_FILES['settingsfile']['name'] ." uploaded successfully.<br>";
   }

} else {
   include_once("includes/header.php");
?> 
      <font class=pageheading>System Tools: Save / Restore</font><BR><BR>
      <table class=settings_table>
        <TR>
          <TH> 
            Save Settings
          </TH>
        </TR>
        <TR>
          <TD>Click here to download settings<br><br>
          <form method="get">
            <input type="Submit" name="Download" value="Download settings"></td>
          </form>
        </TR>
      </table>
      <br><br>
      <table class=settings_table>
        <TR>
          <TH> 
            Restore Settings
          </TH>
        </TR>
        <TR>
          <TD>Enter settings file to upload<br><br>
            <form method="POST" enctype="multipart/form-data">
              <input type="file" name="settingsfile" size="30"><br><br>
              <input type="Submit" name="Restore" value="Restore settings">
            </form>
          </td>
        </TR>
      </table>
<?    
   include(HTTP_ROOT_INCLUDES_DIR ."footer.php"); 
}

?>
<? 
//
// Copyright 2005 Orbital Data Corporation
//
?>
