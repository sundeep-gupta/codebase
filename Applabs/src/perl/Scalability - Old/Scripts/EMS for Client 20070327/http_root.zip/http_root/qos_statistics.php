<?
   /***********************************************************************
    * Include Section
    ***********************************************************************/
   include("includes/header.php");
   include("service_lib.php");
   $Auth->CheckRights(AUTH_LEVEL_VIEWER);


   $Action = (isset($HTTP_GET_VARS['action']) ? $HTTP_GET_VARS['action'] : '');
   if (value_not_null($Action)) {
      switch ($Action) {
         // Server Actions
         case 'reset':
            $resp = resetQosCounters();
            break;
         default:
            break;
      }
   }

   /***********************************************************************
    * Variable Section
    ***********************************************************************/
   $serviceStatArray = getStatistics();
   $serviceClassArray = getServiceClasses();
   $QueueName = GetParamAsStruct("AcceleratedTcpQueueName");
   $SysUpTime = GetSystemParam("UpTime");
   $lastResetTime = GetQosCounterResetTime($serviceStatArray);
   //var_dumper($serviceStatArray);
   //var_dumper($serviceClassArray);
   $SoftboostEnable = isSoftboost();
   $PartialBandwidth = GetParameter("Adapter.PassthroughTrafficAccount");
   $MinSendRate = (int)(GetParameter("Adapter.PassthroughMinAccelTxRate") / 1000);
   $LinkSendRate = (int)(GetParameter("SlowSendRate") / 1000);
   if ($PartialBandwidth)
      $ParentMinBw = $MinSendRate;
   else
      $ParentMinBw = $LinkSendRate;
   $ParentMaxBw = $ParentMinBw;
   $ParentShare = 100;
   $QueueBdwShare = GetParamAsStruct("QosAcceleratedBdwShare");

   getQosNameArrays($IcaPriorityName, $InternalQueueName);


   // table key <service, priority>, use MultiCounters
   function GetIcaStatsCounters($serviceStatRec, $IcaPriorityName, 
                     &$TotalIcaPrioritySendBytes, &$TotalIcaPrioritySendPackets,
                     &$IcaPrioritySendBytes, &$IcaPrioritySendPackets)
   {
      $TotalIcaPrioritySendBytes   = 0;
      $TotalIcaPrioritySendPackets = 0;
      for ($j=0; $j<count($IcaPriorityName); $j++) 
      {
         if ($j==0) {
            $IcaPrioritySendBytes[$j]   = $serviceStatRec['MultiCounters']['IcaP0SendBytes'];
            $IcaPrioritySendPackets[$j] = $serviceStatRec['MultiCounters']['IcaP0SendPackets'];
         } elseif ($j==1) {
            $IcaPrioritySendBytes[$j]   = $serviceStatRec['MultiCounters']['IcaP1SendBytes'];
            $IcaPrioritySendPackets[$j] = $serviceStatRec['MultiCounters']['IcaP1SendPackets'];
         } elseif ($j==2) {
            $IcaPrioritySendBytes[$j]   = $serviceStatRec['MultiCounters']['IcaP2SendBytes'];
            $IcaPrioritySendPackets[$j] = $serviceStatRec['MultiCounters']['IcaP2SendPackets'];
         } elseif ($j==3) {
            $IcaPrioritySendBytes[$j]   = $serviceStatRec['MultiCounters']['IcaP3SendBytes'];
            $IcaPrioritySendPackets[$j] = $serviceStatRec['MultiCounters']['IcaP3SendPackets'];
         }
         $TotalIcaPrioritySendBytes    += $IcaPrioritySendBytes[$j];
         $TotalIcaPrioritySendPackets  += $IcaPrioritySendPackets[$j];
      }
   }
  
   // table key <queue name>, use UniqueCounters
   function GetServiceQueueStatsCounters($serviceStatRec, $QueueName, 
                           &$ServiceQueueSendBytes, &$ServiceQueueSendPackets)
   {
      for ($i=0; $i<count($QueueName); $i++) {
         if ($i==0) {
            $ServiceQueueSendBytes[$i]   = $serviceStatRec['UniqueCounters']['ServiceQueueASendBytes'];
            $ServiceQueueSendPackets[$i] = $serviceStatRec['UniqueCounters']['ServiceQueueASendPackets'];
         } elseif ($i==1) {
            $ServiceQueueSendBytes[$i]   = $serviceStatRec['UniqueCounters']['ServiceQueueBSendBytes'];
            $ServiceQueueSendPackets[$i] = $serviceStatRec['UniqueCounters']['ServiceQueueBSendPackets'];
         } elseif ($i==2) {
            $ServiceQueueSendBytes[$i]   = $serviceStatRec['UniqueCounters']['ServiceQueueCSendBytes'];
            $ServiceQueueSendPackets[$i] = $serviceStatRec['UniqueCounters']['ServiceQueueCSendPackets'];
         } elseif ($i==3) {
            $ServiceQueueSendBytes[$i]   = $serviceStatRec['UniqueCounters']['ServiceQueueDSendBytes'];
            $ServiceQueueSendPackets[$i] = $serviceStatRec['UniqueCounters']['ServiceQueueDSendPackets'];
         } elseif ($i==4) {
            $ServiceQueueSendBytes[$i]   = $serviceStatRec['UniqueCounters']['ServiceQueueESendBytes'];
            $ServiceQueueSendPackets[$i] = $serviceStatRec['UniqueCounters']['ServiceQueueESendPackets'];
         }
      }
   }


   function GetQosCounterResetTime($serviceStatArray) 
   {
      foreach ($serviceStatArray as $serviceStatRec) {
         return $serviceStatRec['UniqueCounters']['QosElapsed'];
      }
   }

?>

<script type="text/javascript" src="./includes/library.js"></script>
<script language="javascript">
<!--
   function onResetCounter() {
     document.location = "./qos_statistics.php?&action=reset";
   }
//-->
</script>


         <BR><font class="pageheading">Monitoring: QoS Statistics</font><BR><BR>
         <BR><font class="pageheading">Accelerated TCP QoS Traffic Class Level Link Layer Statistics</font><BR><BR>
         <table class="dataTable"  width=650 cellspacing="0" cellpadding="0">
           <tr>
             <td>
              <table border="0" width="100%" cellspacing="0" cellpadding="0" rules="none">
               <tr>
                 <td valign="top">
                   <table name="statsTable" class="sortable" id="statsTable" width="100%" cellspacing="0" cellpadding="0" rules="none">
                    <tr>
                      <th class="headingContent" id="statsHeader">QoS Traffic Class Name</th>
                      <th class="headingContent" align="right" id="type_bytes_xfered" title="since last reset, include L2,3,4 hdrs">Total Sent Bytes</th>
                      <th class="headingContent" align="right" id="type_bytes_xfered">Sent Byte Ratio</th>
                      <th class="headingContent" align="right" id="type_bytes_xfered" title="since last reset, include L2,3,4 hdrs">Total Sent Packets</th>
                      <th class="headingContent" align="right" id="type_bytes_xfered">Sent Packet Ratio</th>
                      <th class="headingContent" align="right" id="type_bytes_xfered">Average Sent Packet Size (bytes)</th>
                    </tr>

         <?
               for ($i=0; $i<count($QueueName); $i++) {
                  $queueStats[$i]['UniqueCounters']['WANFlowControlSendBytes'] = 0;
                  $queueStats[$i]['UniqueCounters']['WANFlowControlSendPackets'] = 0;
               }

               $queueArray = GetParameters("IcaPriorityToServiceGroupQueueMapping");
               foreach ($serviceStatArray as $serviceStatRec) {
                  $curServiceID = getServiceID($serviceStatRec);
                  $curServiceQueue = getServiceQueueFromId($serviceClassArray, $curServiceID);
                  GetServiceQueueStatsCounters($serviceStatRec, $QueueName, $ServiceQueueSendBytes, $ServiceQueueSendPackets);
                  for ($i=0; $i<count($InternalQueueName); $i++) {
                     if ($curServiceQueue == "dynamic") {
                        for ($j=0; $j<count($QueueName); $j++) {
                           $queueStats[$j]['UniqueCounters']['WANFlowControlSendBytes']   += $ServiceQueueSendBytes[$j];
                           $queueStats[$j]['UniqueCounters']['WANFlowControlSendPackets'] += $ServiceQueueSendPackets[$j];
                        }
                     } else { // static
                        if ($curServiceQueue == $InternalQueueName[$i]) {
                           $queueStats[$i]['UniqueCounters']['WANFlowControlSendBytes']   += $ServiceQueueSendBytes[$i];
                           $queueStats[$i]['UniqueCounters']['WANFlowControlSendPackets'] += $ServiceQueueSendPackets[$i];
                        }
                     }
                  }
               }

               $queueStats['UniqueCounters']['TotalWANFlowControlSendBytes']   = 0;
               $queueStats['UniqueCounters']['TotalWANFlowControlSendPackets'] = 0;
               for ($i=0; $i<count($QueueName); $i++) {
                  $queueStats['UniqueCounters']['TotalWANFlowControlSendBytes']   += $queueStats[$i]['UniqueCounters']['WANFlowControlSendBytes'];
                  $queueStats['UniqueCounters']['TotalWANFlowControlSendPackets'] += $queueStats[$i]['UniqueCounters']['WANFlowControlSendPackets'];
                  // bps: bits per sec
                  $queueStats[$i]['UniqueCounters']['AverageSendRate'] = (8*$queueStats[$i]['UniqueCounters']['WANFlowControlSendBytes'])/$lastResetTime;
               }

               for ($i=0; $i<count($QueueName); $i++) {
                     $trClass = 'dataTableRow';
                     if (($i % 2) == 0)  {
                        $trID = '';
                        $tdClass = '"dataTableContentEvenRow"';
                     } else {
                        $trID = '';
                        $tdClass = '"dataTableContent"';
                     }
         ?>
                    <tr <?php echo $trID; ?>  class=<?php echo $trClass; ?> >
                      <td class=<?php echo $tdClass; ?>>
                        <?php echo $QueueName[$i]; ?>
                      </td>
                      <td class=<?php echo $tdClass; ?> align="right">
                        <?php echo serviceNumberFormat($queueStats[$i]['UniqueCounters']['WANFlowControlSendBytes']); ?>
                      </td>
                      <td class=<?php echo $tdClass; ?> align="right">
                        <?
                           $ratio = $queueStats['UniqueCounters']['TotalWANFlowControlSendBytes']?number_format(($queueStats[$i]['UniqueCounters']['WANFlowControlSendBytes']*100/$queueStats['UniqueCounters']['TotalWANFlowControlSendBytes']), 2):0;
                           echo $ratio, "%";
                        ?>
                      </td>
                      <td class=<?php echo $tdClass; ?> align="right">
                        <?php echo serviceNumberFormat($queueStats[$i]['UniqueCounters']['WANFlowControlSendPackets']); ?>
                      </td>
                      <td class=<?php echo $tdClass; ?> align="right">
                        <?
                           $ratio = $queueStats['UniqueCounters']['TotalWANFlowControlSendPackets']?number_format(($queueStats[$i]['UniqueCounters']['WANFlowControlSendPackets']*100/$queueStats['UniqueCounters']['TotalWANFlowControlSendPackets']), 2):0;
                           echo $ratio, "%";
                        ?>
                      </td>
                      <td class=<?php echo $tdClass;?> align="right">
                       <?php echo $queueStats[$i]['UniqueCounters']['WANFlowControlSendPackets']?number_format(($queueStats[$i]['UniqueCounters']['WANFlowControlSendBytes']/$queueStats[$i]['UniqueCounters']['WANFlowControlSendPackets']), 0):0; ?>
                      </td>
                    </tr>
         <?
               } // for $i

         ?>

                  </table>
                 </td>
               </tr>
              </table>
            </td>
           </tr>
         </table>



         <BR>
         <table class="dataTable"  width=650 cellspacing="0" cellpadding="0">
           <tr>
             <td>
              <table border="0" width="100%" cellspacing="0" cellpadding="0" rules="none">
               <tr>
                 <td valign="top">
                   <table name="statsTable" class="sortable" id="statsTable" width="100%" cellspacing="0" cellpadding="0" rules="none">
                    <tr>
                      <th class="headingContent" id="statsHeader">QoS Traffic Class Name</th>
                      <th class="headingContent" align="right" id="type_bytes_xfered" title="total sent bits / last reset time <?echo number_format($lastResetTime, 0)?> secs" >Average Send Rate (bps)</th>
                      <th class="headingContent" align="right" id="type_bytes_xfered">Configured Guaranteed Min Send Rate (bps)</th>
                      <th class="headingContent" align="right" id="type_bytes_xfered" title="average send rate / configured guaranteed min send rate">Average Bandwidth Utilization</th>
                      <th class="headingContent" align="right" id="type_bytes_xfered">Configured Guaranteed Min Send Rate Ratio</th>
                      <th class="headingContent" align="right" id="type_bytes_xfered" title="Borrow +, Lend -">Excessive Bandwidth Sharing (bps)</th>
                    </tr>

         <?
               $totalBorrowedBw = 0;
               $totalLendBwShare = 0;
               for ($i=0; $i<count($QueueName); $i++) {
                  $minBw = $QueueBdwShare[$i] * $ParentMinBw *10; // bps
                  $thruput = $queueStats[$i]['UniqueCounters']['AverageSendRate'];
                  if ($thruput > $minBw)
                     $totalBorrowedBw += $thruput - $minBw;
                  if ($thruput < $minBw)
                     $totalLendBwShare += $QueueBdwShare[$i];
               }

               for ($i=0; $i<count($QueueName); $i++) {
                  $trClass = 'dataTableRow';
                  if (($i % 2) == 0) {
                     $trID = '';
                     $tdClass = '"dataTableContentEvenRow"';
                  } else {
                     $trID = '';
                     $tdClass = '"dataTableContent"';
                  }
         ?>
                  <tr <?php echo $trID; ?>  class=<?php echo $trClass; ?> >
                      <td class=<?php echo $tdClass; ?>>
                        <?php echo $QueueName[$i]; ?>
                      </td>
                      <td class=<?php echo $tdClass; ?> align="right">
                        <?php echo number_format($queueStats[$i]['UniqueCounters']['AverageSendRate'], 0); ?>
                      </td>
                      <td class=<?php echo $tdClass; ?> align="right">
                        <?php echo number_format($QueueBdwShare[$i] * $ParentMinBw *10, 0); // *1000/100?>
                      </td>
                      <td class=<?php echo $tdClass; ?> align="right">
                        <?
                           $minBw = $QueueBdwShare[$i] * $ParentMinBw *10; // bps
                           if ($queueStats[$i]['UniqueCounters']['AverageSendRate']==0)
                              echo "0";
                           elseif ($minBw == 0) // $queueStats[$i]['UniqueCounters']['AverageSendRate']>0
                              echo ">1";
                           else {
                              $utilization = $minBw?($queueStats[$i]['UniqueCounters']['AverageSendRate'] / $minBw):1;
                              echo $minBw?number_format($utilization, 8):">1";
                           }
                        ?>
                      </td>
                      <td class=<?php echo $tdClass; ?> align="right">
                        <?php echo number_format($QueueBdwShare[$i], 0), "%"; ?>
                      </td>
                      <td class=<?php echo $tdClass; ?> align="right">
                        <?
                           $minBw = $QueueBdwShare[$i] * $ParentMinBw *10; // bps
                           $thruput = $queueStats[$i]['UniqueCounters']['AverageSendRate'];
                           if ($thruput > $minBw)
                              echo "+", number_format($thruput - $minBw, 0);
                           elseif ($thruput == $minBw)
                              echo "0";
                           else // <
                           {
                              if ($totalBorrowedBw>0) {
                                 $lent = ($QueueBdwShare[$i] / $totalLendBwShare) * $totalBorrowedBw;
                                 echo "-", number_format($lent, 0);
                              } 
                              else
                                 echo "0";
                           }
                        ?>
                      </td>
                  </tr>
         <?
               } // for $i

         ?>

                  </table>
                 </td>
               </tr>
              </table>
            </td>
           </tr>
         </table>





         <BR><font class="pageheading">Citrix ICA Traffic Presentation Layer Statistics</font><BR><BR>
         <table class="dataTable"  width=650 cellspacing="0" cellpadding="0">
           <tr>
             <td>
              <table border="0" width="100%" cellspacing="0" cellpadding="0" rules="none">
               <tr>
                 <td valign="top">
                   <table name="statsTable" class="sortable" id="statsTable" width="100%" cellspacing="0" cellpadding="0" rules="none">
                    <tr>
                      <th class="headingContent" id="statsHeader">Service Name</th>
                      <th >ICA Priority</th>
                      <th class="headingContent" align="right" id="type_bytes_xfered" title="since last reset, exclude L2,3,4 hdrs">Total Sent Bytes</th>
                      <th class="headingContent" align="right" id="type_bytes_xfered">Sent Byte Ratio</th>
                      <th class="headingContent" align="right" id="type_bytes_xfered" title="since last reset, exclude L2,3,4 hdrs">Total Sent Packets</th>
                      <th class="headingContent" align="right" id="type_bytes_xfered">Sent Packet Ratio</th>
                      <th class="headingContent" align="right" id="type_bytes_xfered">Average Sent Packet Size (bytes)</th>
                      <th class="headingContent" align="right" id="type_bytes_xfered" title="total sent bits / last reset time <?echo number_format($lastResetTime, 0)?> secs" >Average Send Rate (bps)</th>
                    </tr>
         <?

               $IcaTrafficClass = array();
               foreach ($serviceClassArray as $serviceClassRec) {
                  $ServiceQueue = getServiceQueue($serviceClassRec);
                  if ($ServiceQueue == "dynamic") {
                     $ServiceID = getServiceID($serviceClassRec);
                     $ServiceName = getServiceName($serviceClassRec);
                     $IcaRec = array('id' => $ServiceID, 'name' => $ServiceName);
                     array_push($IcaTrafficClass, $IcaRec);
                  }
               }

               foreach ($serviceStatArray as $serviceStatRec) {
                  $curServiceID = getServiceID($serviceStatRec);
                  $IsDynamic = false;
                  foreach ($IcaTrafficClass as $IcaRec) {
                     if ($IcaRec['id'] == $curServiceID) {
                        $IsDynamic = true;
                        break;
                     }
                  }
                  if ($IsDynamic == false)
                     continue;

                  GetIcaStatsCounters($serviceStatRec, $IcaPriorityName, $TotalIcaPrioritySendBytes, $TotalIcaPrioritySendPackets,
                                $IcaPrioritySendBytes, $IcaPrioritySendPackets);

                  for ($j=0; $j<count($IcaPriorityName); $j++) 
                  {
         ?>

                    <tr <?php echo $trID; ?>  class=<?php echo $trClass; ?> >
                      <td class=<?php echo $tdClass; ?>>
                        <?php echo getServiceName($serviceStatRec); ?>
                      </td>
                      <td class=<?php echo $tdClass; ?>>
                        <?php echo $IcaPriorityName[$j]; ?>
                      </td>
                      <td class=<?php echo $tdClass;?> align="right">
                       <?php echo serviceNumberFormat($IcaPrioritySendBytes[$j]); ?>
                      </td>
                      <td class=<?php echo $tdClass;?> align="right">
                       <?php echo $TotalIcaPrioritySendBytes?number_format(((100*$IcaPrioritySendBytes[$j])/$TotalIcaPrioritySendBytes), 2):0, "%"; ?>
                      </td>
                      <td class=<?php echo $tdClass;?> align="right">
                       <?php echo serviceNumberFormat($IcaPrioritySendPackets[$j]); ?>
                      </td>
                      <td class=<?php echo $tdClass;?> align="right">
                       <?php echo $TotalIcaPrioritySendPackets?number_format(((100*$IcaPrioritySendPackets[$j])/$TotalIcaPrioritySendPackets), 2):0, "%"; ?>
                      </td>
                      <td class=<?php echo $tdClass;?> align="right">
                       <?php echo $IcaPrioritySendPackets[$j]?number_format(($IcaPrioritySendBytes[$j]/$IcaPrioritySendPackets[$j]), 0):0; ?>
                      </td>
                      <td class=<?php echo $tdClass; ?> align="right">
                        <?php echo number_format(((8*$IcaPrioritySendBytes[$j])/$lastResetTime), 0); ?>
                      </td>
                    </tr>

         <?
                  } // $j
               } // foreach
         ?>

                  </table>
                 </td>
               </tr>
              </table>
            </td>
           </tr>
         </table>


         <BR><BR>
         <table class="settings_table"  width=645 cellspacing="0" cellpadding="0">
            <TR>
            <TH>
               Counter last reset: <?=FormatTimeStamp(time()-$lastResetTime)?>; &nbsp;&nbsp; Counter last retrieved: <?=FormatTimeStamp(time())?>; &nbsp;&nbsp; Data sampling interval: <?=number_format($lastResetTime)?> secs &nbsp;&nbsp;
            </TH>

            <TD>
               <FORM name="ResetCounter" action="./qos_statistics.php">
                  <INPUT type="button" name="qos_stat_reset" value="Reset Counters"
                     onClick="onResetCounter()"></INPUT>
               </FORM>
            </TD>
            </TR>
         </table>



<?  include(HTTP_ROOT_INCLUDES_DIR ."footer.php"); ?>
