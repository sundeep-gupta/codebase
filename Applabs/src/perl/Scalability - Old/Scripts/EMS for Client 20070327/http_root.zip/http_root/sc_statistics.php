<?
   /***********************************************************************
    * Include Section
    ***********************************************************************/
   include("includes/header.php");
   include("service_lib.php");
   $Auth->CheckRights(AUTH_LEVEL_VIEWER);

   /***********************************************************************
    * Parameter Section
    ***********************************************************************/
   $action = (isset($HTTP_GET_VARS['action']) ? $HTTP_GET_VARS['action'] : '');
   $serviceID = (isset($HTTP_GET_VARS['serviceID']) ? $HTTP_GET_VARS['serviceID'] : '1');
   $error = false;
   $processed = false;

   /***********************************************************************
    * Action Section
    ***********************************************************************/
    if (value_not_null($action)) {
      switch ($action) {

          // Server Actions
         case 'reset':
             $resp = resetMultiCounters($serviceID);
            //echo 'Response: ';
            //var_dumper($resp);
            break;
         default:
            break;
      }
   }

   /***********************************************************************
    * Variable Section
    ***********************************************************************/
   $serviceStatArray = getStatistics();
   //echo '<br>Stats';
   //var_dumper($serviceStatArray);


   /***********************************************************************
    * JavaScript Section
    ***********************************************************************/
?>
<script type="text/javascript" src="./includes/library.js"></script>
<script type="text/javascript" src="serviceScript.js"></script>

<script language="javascript">
<!--

   function onDetails(id) {
     document.location = "./sc_statistics.php?serviceID=" + id.value +
                         "&action=details";
   }

   function onReset(id) {
     document.location = "./sc_statistics.php?serviceID=" + id.value +
                         "&action=reset";
   }

   function onBack(id) {
      document.location = "./sc_statistics.php?serviceID=" + id.value;
   }

//-->
</script>


<?

   /***********************************************************************
    * Tab where we choose if we render as numbers or a graph
    ***********************************************************************/
   $SelectedTab = CreateTabs("SCStatistics",
              array("ShowAsStats" => "Service Class Statistics",
                    "ShowAsUtilizationGraph" => "Line Utilization Graph",
                    "ShowAsCompressiblityGraph" => "Compressibility Graph")
             );
   echo "<BR>";


   /***********************************************************************
    * Tab where we choose if we render as numbers or a graph
    ***********************************************************************/

   if($action=='details') {
      foreach ($serviceStatArray as $serviceStatRec) {
         if ($serviceID == getServiceID($serviceStatRec)) {
             $selServiceStatRec = $serviceStatRec;
            break;
         }
      }
      if (!isset($selServiceStatRec)) {
          // Should not happen - go back to service Rec
      }

?>
<font class="pageheading">Monitoring: Service Class Statistics: <?php echo getServiceName($selServiceStatRec); ?></font><BR><BR><BR>

<FORM name="service_class_stat_back">
<INPUT type="hidden" name="serviceID" value="<?=$serviceID ?>">
  <TABLE class=settings_table>
   <TR>
     <TH>Item:&nbsp;</TH>
     <TD align="center">Since System Reboot</TD>
    </TR>
   <TR>
     <TH>Total Accelerated Connections:&nbsp;</TH>
     <TD align="right"><?php echo serviceNumberFormat($serviceStatRec['MultiCounters']['TotalFlowControlConnections']); ?></TD>
    </TR>
   <TR>
     <TH>Total Accelerated Bytes Sent:&nbsp;</TH>
     <TD align="right"><?php echo serviceNumberFormat($serviceStatRec['MultiCounters']['WANFlowControlSendBytes']); ?></TD>
    </TR>
   <TR>
     <TH>Total Accelerated Bytes Received:&nbsp;</TH>
     <TD align="right"><?php echo serviceNumberFormat($serviceStatRec['MultiCounters']['WANFlowControlReceiveBytes']); ?></TD>
    </TR>
   <TR>
     <TH>Total Accelerated Packets Sent:&nbsp;</TH>
     <TD align="right"><?php echo serviceNumberFormat($serviceStatRec['MultiCounters']['WANFlowControlSendPackets']); ?></TD>
    </TR>
   <TR>
     <TH>Total Accelerated Packets Received:&nbsp;</TH>
     <TD align="right"><?php echo serviceNumberFormat($serviceStatRec['MultiCounters']['WANFlowControlReceivePackets']); ?></TD>
    </TR>
   <TR>
     <TH>Total Passthrough Bytes Sent:&nbsp;</TH>
     <TD align="right"><?php echo serviceNumberFormat($serviceStatRec['MultiCounters']['WANPassthroughSendBytes']); ?></TD>
    </TR>
   <TR>
     <TH>Total Passthrough Bytes Received:&nbsp;</TH>
     <TD align="right"><?php echo serviceNumberFormat($serviceStatRec['MultiCounters']['WANPassthroughReceiveBytes']); ?></TD>
    </TR>
   <TR>
     <TH>Total Passthrough Packets Sent:&nbsp;</TH>
     <TD align="right"><?php echo serviceNumberFormat($serviceStatRec['MultiCounters']['WANPassthroughSendPackets']); ?></TD>
    </TR>
   <TR>
     <TH>Total Passthrough Packets Received:&nbsp;</TH>
     <TD align="right"><?php echo serviceNumberFormat($serviceStatRec['MultiCounters']['WANPassthroughReceivePackets']); ?></TD>
    </TR>
   <TR>
     <TH>Duration:&nbsp;</TH>
     <TD align="right"><?php echo getSystemUptime($serviceStatRec); ?></TD>
   </TR>
   <TR>
     <TH>&nbsp;</TH>
     <TD align="center" >
      <INPUT type="button" name="sc_reset" style="width: 65px"
             value="   Reset    " onClick="onReset(document.service_class_stat_back.serviceID)"></INPUT>
      <INPUT type="button" name="sc_back" value="Back"
             onClick="onBack(document.service_class_stat_back.serviceID)"/>&nbsp;&nbsp

     </TD>
    </TR>
</TABLE>
</FORM>
<BR><BR>

<?
   } else {

      if ( $SelectedTab == "ShowAsStats" ){
?>
         <font class="pageheading">Monitoring: Service Class Statistics</font><BR><BR>

         <table class="dataTable"  width=650 cellspacing="0" cellpadding="0">
           <tr>
             <td>
              <table border="0" width="100%" cellspacing="0" cellpadding="0" rules="none">
               <tr>
                 <td valign="top">
                   <table name="statsTable" class="sortable" id="statsTable" width="100%" cellspacing="0" cellpadding="0" rules="none">
                    <tr>
                      <th class="headingContent" id="statsHeader">Service Class Name</th>
                      <th >Current Accelerated Connections</th>
                      <th class="headingContent" align="right" id="statsHeader">Total Accelerated Connections</th>
                      <th class="headingContent" align="right" id="type_bytes_xfered">Total Accelerated Bytes</th>
                      <th class="headingContent" align="right" id="type_bytes_xfered">Total Accelerated Packets</th>
                      <th class="headingContent" align="right" id="statsHeader">Action&nbsp;</th>
                    </tr>

         <?
               // Loop through statistics
               $i=0;
               foreach ($serviceStatArray as $serviceStatRec) {
                  $curServiceID = getServiceID($serviceStatRec);

                  if ($curServiceID == $serviceID) {
                     $selServiceStatRec = $serviceStatRec;
                     $selServiceID = $curServiceID;
                     $trID = 'id="defaultSelected"';
                     $trClass = 'dataTableRowSelected';
                     $actionFragment = '&action=modifyUI';
                     $tdClass = 'dataTableContentSelected';
                  } else {
                     $trClass = 'dataTableRow';
                     if (($i % 2) == 0)  {
                        $trID = '';
                        $actionFragment = '';
                        $tdClass = '"dataTableContentEvenRow"';
                     } else {
                        $trID = '';
                        $actionFragment = '';
                        $tdClass = '"dataTableContent"';
                     }
                  }
         ?>
                    <tr <?php echo $trID; ?>  class=<?php echo $trClass; ?>
                         onmouseover="rowOverEffect(this)"
                         onmouseout="rowOutEffect(this)"
                         onclick="document.location.href='./sc_statistics.php?serviceID=<?php echo $curServiceID . $actionFragment; ?>'">
                      <td class=<?php echo $tdClass; ?>>
                        <?php echo getServiceName($serviceStatRec); ?>
                      </td>
                      <td class=<?php echo $tdClass;?> align="right">
                       <?php echo serviceNumberFormat($serviceStatRec['CurrentFlowControlConnections']); ?>
                      </td>
                      <td class=<?php echo $tdClass;?> align="right">
                       <?php echo serviceNumberFormat($serviceStatRec['MultiCounters']['TotalFlowControlConnections']); ?>
                      </td>
                      <td class=<?php echo $tdClass;?> align="right">
                       <?php echo serviceNumberFormat($serviceStatRec['MultiCounters']['WANFlowControlSendBytes'] +
                                                      $serviceStatRec['MultiCounters']['WANFlowControlReceiveBytes']); ?>
                      </td>
                      <td class=<?php echo $tdClass;?> align="right">
                       <?php echo serviceNumberFormat($serviceStatRec['MultiCounters']['WANFlowControlSendPackets'] +
                                                      $serviceStatRec['MultiCounters']['WANFlowControlReceivePackets']); ?>
                      </td>
                      <td class=<?php echo $tdClass;?> align="right">
                       <?php if (isset($selServiceID) && $selServiceID == $curServiceID) { ?>
                       <img src="./images/icon_arrow_right.gif" border="0" alt="">&nbsp;
                       <?php } else { ?>
                       <a href="./sc_statistics.php?&serviceID=<?php echo $curServiceID?>"><img src="./images/icon-link.gif" border="0" alt="Info" title=" Info "></a>&nbsp;
                       <?php } ?>
                      </td>
                    </tr>

         <?
                   $i++;
               }
         ?>
                  </table>
                 </td>

         <?
               if(isset($selServiceStatRec)) {
         ?>

                 <td width="25%" valign="top">
                  <table border="1" width="100%" cellspacing="0" cellpadding="0" rules="none">
                    <tr class="infoBoxHeading">
                     <td class="infoBoxHeading">
                       <b><?php echo $selServiceStatRec['ClassName']; ?></b>
                     </td>
                    </tr>
                    <tr class="infoBoxHeading">
                     <td class="infoBoxHeading"><b>&nbsp</b></td>
                    </tr>
                    <tr class="infoBoxHeading">
                     <td class="infoBoxHeading"><b>&nbsp</b></td>
                    </tr>
                    <tr class="infoBoxHeading">
                     <td class="infoBoxHeading"><b>&nbsp</b></td>
                    </tr>
                  <!--</table>

                  <table border="0" width="100%" cellspacing="0" cellpadding="0">-->
                    <form name="service_class_stat">
                    <INPUT type="hidden" name="serviceID" value="<?=$selServiceID?>">

                    <tr>
                     <td align="center" class="infoBoxContent">
                       <INPUT type="button" name="sc_detail" style="width: 65px"
                              value="Details"
                            onClick="onDetails(document.service_class_stat.serviceID)"/>
                       <INPUT type="button" name="sc_reset" style="width: 65px"
                              value="   Reset    "
                            onClick="onReset(document.service_class_stat.serviceID)"></INPUT>
                     </td>
                    </tr>
                    </form>
                  </table>
                 </td>
               </tr>
              </table>
            </td>
           </tr>
         </table>
<?
   }
/***********************************************************************
 * Graph service class data as pie chart
 ***********************************************************************/
 }elseif ($SelectedTab == "ShowAsUtilizationGraph" ){

   echo "<font class='pageheading'>Monitoring: Service Class Statistics</font><BR><BR><BR>";

   $AcceleratedSCGraphname = GraphProtocolBytes_ByAcceleratedSC(true);
   $UnacceleratedSCGraphname = GraphProtocolBytes_ByUnacceleratedSC(true);
	
   if ( $AcceleratedSCGraphname == "" && 
        $UnacceleratedSCGraphname == ""){
      echo "<font color='red'>No compressed connections have flowed through the Appliance</font>";
      return;
   }

   echo "<IMG src='" . $AcceleratedSCGraphname . "?NoCache=" . time() . "' usemap=#$AcceleratedSCGraphname border=0>";

   echo "<br><br>";
   echo "<IMG src='" . $UnacceleratedSCGraphname . "?NoCache=" . time() . "' usemap=#$UnacceleratedSCGraphname border=0>";


 }/***********************************************************************
 * Graph service class compression as bar chart
 ***********************************************************************/
 else{
   echo "<font class='pageheading'>Monitoring: Service Class Statistics</font><BR><BR><BR>";

   $GraphName = GraphProtocolBytes_BySC_AsBarChart();
   if ( $GraphName == ""){
      echo "<font color='red'>No compressed connections have flowed through the Appliance</font>";
      return;
   }

   echo "<IMG src='" . $GraphName . "?NoCache=" . time() . "' usemap=#$GraphName border=0>";

 }

}
?>
<? include(HTTP_ROOT_INCLUDES_DIR . "footer.php"); ?>
