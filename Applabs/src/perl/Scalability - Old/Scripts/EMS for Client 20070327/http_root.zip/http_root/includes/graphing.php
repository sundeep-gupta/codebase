<?
   class SERVICE_CLASS
   {
      function SERVICE_CLASS($Classname, $LSent, $LRecv, $WSent, $WRecv){
         $this->Classname = trim($Classname, "\n\r ");
         $this->WANBytesSent = $WSent;
         $this->WANBytesRecv = $WRecv;
         $this->LANBytesSent = $LSent;
         $this->LANBytesRecv = $LRecv;

         $this->LANTotal = $this->LANBytesSent + $this->LANBytesRecv;
         $this->WANTotal = $this->WANBytesSent + $this->WANBytesRecv;
      }

      var $Classname;
      var $WANBytesSent;
      var $WANBytesRecv;
      var $LANBytesSent;
      var $LANBytesRecv;
      var $LANTotal;
      var $WANTotal;
   }


   function SCSorter($SC1, $SC2){
      if ($SC1->LANTotal == $SC2->LANTotal)
         return 0;
      else
         return (($SC1->LANTotal > $SC2->LANTotal) ? -1 : 1);
   }

   function GraphProtocolBytes($ServiceClassData, $ShowCompression=true, $GraphType="barchart", $GraphTitle="", $DisplayImagemap=true){
      $MAX_CLASSES_DISPLAYED  = 8;
      $data1y                 = array();
      $data2y                 = array();
      $servicenames           = array();
      $servicenames_alt       = array();
      $ShuffleYPos            = "";
      $ChartIsEmpty            = false;
      
      //
      // Remove any entries that have no transfered bytes
      //
      $NewServiceClassData = array();
      for ($count=0; $count < sizeof($ServiceClassData); $count++){
         $OneClass = $ServiceClassData[$count];
         if ( ($OneClass->WANBytesRecv + $OneClass->WANBytesSent) > 0){
            array_push($NewServiceClassData, $OneClass);
         }
      }
      $ServiceClassData = $NewServiceClassData;

      if ( sizeof( $ServiceClassData )==0 ){
         $ChartIsEmpty = true;
      }

      //
      // Now Add up all the bytes xfered, excluding the Unclassified class...
      //
      $TotalLANSent = 0; $TotalLANRecv = 0; $TotalWANSent = 0; $TotalWANRecv = 0;
      
      for ($c=0; $c < sizeof($ServiceClassData); $c++ ){
         if ($ServiceClassData[$c]->Classname != "UnclassifiedAccelerated"){
            $TotalLANSent += $ServiceClassData[$c]->LANBytesSent;
            $TotalLANRecv += $ServiceClassData[$c]->LANBytesRecv;
            $TotalWANSent += $ServiceClassData[$c]->WANBytesSent;
            $TotalWANRecv += $ServiceClassData[$c]->WANBytesRecv;
         }
      }
      
      //
      // ...and subtract the bytes from above from the UnclassifiedAccelerated class, since otherwise we double count
      //
      for ($c=0; $c < sizeof($ServiceClassData); $c++ ){
         $OneClass = & $ServiceClassData[$c];
         if ( ($OneClass->Classname == "UnclassifiedAccelerated") ){
            $OneClass->LANBytesSent -= $TotalLANSent;
            $OneClass->LANBytesRecv -= $TotalLANRecv;
            $OneClass->WANBytesSent -= $TotalWANSent;
            $OneClass->WANBytesRecv -= $TotalWANRecv;
            $OneClass->LANTotal     -= ($TotalLANSent + $TotalLANRecv);
            $OneClass->WANTotal     -= ($TotalWANSent + $TotalWANRecv);
         }
      }

      usort($ServiceClassData, "SCSorter");
      
      //
      // Only show a fixed number of classes. Smaller sets will get combined under "Other"
      //
      for ($count=0; $count < sizeof($ServiceClassData); $count++){
         $OneClass = &$ServiceClassData[$count];

         if (sizeof($ServiceClassData) > 4 && $GraphType=="barchart") { $ShuffleYPos = ($count%2)==0 ?" ":" \n";}

         if ($count < ($MAX_CLASSES_DISPLAYED-1)){
            array_push($data2y, $OneClass->LANBytesSent + $OneClass->LANBytesRecv);
            array_push($data1y, $OneClass->WANBytesSent + $OneClass->WANBytesRecv);
            array_push($servicenames,  $ShuffleYPos . $OneClass->Classname);
            array_push($servicenames_alt,  $OneClass->Classname . " - " .
                                           " Uncompressed: " . ToPrintableBytes($data2y[$count]) .
                                           " Compressed: "   . ToPrintableBytes($data1y[$count]) );
            
         }else{
            if (!isset($data1y[$MAX_CLASSES_DISPLAYED - 1])){
               array_push($data2y, $OneClass->LANBytesSent + $OneClass->LANBytesRecv);
               array_push($data1y, $OneClass->WANBytesSent + $OneClass->WANBytesRecv);
               array_push($servicenames, $ShuffleYPos . "Other");
               array_push($servicenames_alt, $ShuffleYPos . "Other");
            }else{
               $data2y[$MAX_CLASSES_DISPLAYED - 1]  += $OneClass->LANBytesSent + $OneClass->LANBytesRecv;
               $data1y[$MAX_CLASSES_DISPLAYED - 1]  += $OneClass->WANBytesSent + $OneClass->WANBytesRecv;
            }
         }
      }

      if ($ChartIsEmpty){         
         // Create the graph. These two calls are always required
         $graph  = new CanvasGraph(500,350,"auto");
         $graph->SetMargin(2,2,2,2);
         $graph->title->Set($GraphTitle);
         $graph->InitFrame();

         $t = new Text( "No data of this type observed.", 250, 150 );
         $t->SetFont( FF_FONT1,FS_BOLD);
         $t->Align( 'center','top');
         $t->ParagraphAlign( 'center');
         $t->SetBox("white","black","white");
         $t->Stroke( $graph->img);

      }
      //
      // Create the barchart of data
      //
      elseif ($GraphType == "barchart"){
         $graph = new Graph(600,300,"auto");
         $graph->SetScale("textlin");

         $b1plot = new BarPlot($data1y);
         $b1plot->SetFillColor(COLOR_PAYLOAD_BYTES);

         if ($ShowCompression){
            $b2plot = new BarPlot($data2y);
            $b2plot->SetFillColor(COLOR_PASS_BYTES);
            $b2plot->SetLegend("Before Compression");
            $b1plot->SetLegend("After Compression");
            echo $b1plot->SetCSIMTargets( array("#","#","#","#","#", "#","#","#", "#", "#"), 
                                      $servicenames_alt );
            echo $b2plot->SetCSIMTargets( array("#","#","#","#","#", "#","#","#", "#", "#"), 
                                      $servicenames_alt );

            $plot = new GroupBarPlot(array($b2plot, $b1plot));
         }else{
            $plot = new GroupBarPlot(array($b1plot));
         }

         $graph->Add($plot);
         $graph->title->Set($GraphTitle);
         $graph->xaxis->SetTickLabels($servicenames);

         $graph->title->SetFont(FF_FONT2,FS_BOLD);
         $graph->yaxis->title->SetFont(FF_FONT1,FS_BOLD);
         $graph->xaxis->title->SetFont(FF_FONT1,FS_BOLD);
         $graph->yaxis->SetLabelFormatCallback('FormatBytes');
         $graph->yaxis->SetTitleMargin(60);

         $graph->img->SetMargin(65,20,20,35);

         $graph->legend->SetLayout(LEGEND_HOR);
         $graph->legend->SetShadow(false);
         $graph->legend->Pos(0.70,0.20,"center","bottom");


      //
      // Create the piechart of data
      //
      }elseif ($GraphType == "piechart")
      {
         $graph  = new PieGraph (500,350);
         $graph->SetShadow(false);

         $graph->title-> Set( $GraphTitle );
         $graph->title->SetFont(FF_FONT2, FS_BOLD);

         $p1 = new PiePlot( $data1y);
         $p1->SetLegends($servicenames);
         $p1->SetCenter(0.32,0.52);
         $p1->SetTheme("sand");
         $p1->SetSize( 120 );
         $p1->SetColor( "black");
         $graph->legend->SetShadow(false);
         $graph->legend->Pos(.01, .1, "right", "top");
         
         //
         // Set the floatover text for each slice
         //
         if ($DisplayImagemap){
            echo $p1->SetCSIMTargets( array("#","#","#","#","#", "#","#","#", "#", "#"), 
                                      $servicenames_alt );
         }

         $graph->Add( $p1);
      }else{
         ThrowException("Invalid chart type!", true);
      }

      // Display the graph
      $ImageName  = str_replace(" ", "_", $GraphTitle) . ".png";
      $graph->Stroke("temp/" . $ImageName);
      
      if ($DisplayImagemap){
         echo $graph->GetHTMLImageMap("temp/" . $ImageName);
      }

      return "temp/" . $ImageName;
   }
   
   function GraphProtocolBytes_ByAcceleratedSC($DisplayImagemap=true){
      $serviceStatArray = getStatistics();
      $ServiceClassAccelerated = array();
      foreach ($serviceStatArray as $XMLStat){
         $ServiceClass = new SERVICE_CLASS($XMLStat["ClassName"],
                                           $XMLStat["UniqueCounters"]["LANFlowControlSendBytes"],
                                           $XMLStat["UniqueCounters"]["LANFlowControlReceiveBytes"],
                                           $XMLStat["UniqueCounters"]["WANFlowControlSendBytes"],
                                           $XMLStat["UniqueCounters"]["WANFlowControlReceiveBytes"] );

         array_push($ServiceClassAccelerated, $ServiceClass);
      }
      return GraphProtocolBytes($ServiceClassAccelerated, false, "piechart", "Accelerated Line Usage by Service Class",$DisplayImagemap);
   }

   function GraphProtocolBytes_ByUnacceleratedSC($DisplayImagemap=true){
      $serviceStatArray = getStatistics();
      $ServiceClassNonAccelerated = array();
      foreach ($serviceStatArray as $XMLStat){
         $ServiceClass = new SERVICE_CLASS($XMLStat["ClassName"],
                                           0,
                                           0,
                                           $XMLStat["UniqueCounters"]["WANPassthroughSendBytes"],
                                           $XMLStat["UniqueCounters"]["WANPassthroughReceiveBytes"] );

         array_push($ServiceClassNonAccelerated, $ServiceClass);
      }
      return GraphProtocolBytes($ServiceClassNonAccelerated, false, "piechart", "Non-Accelerated Line Usage by Service Class",$DisplayImagemap);
   }
   
   function GraphProtocolBytes_BySC_AsBarChart($DisplayImagemap=true){
      $serviceStatArray = getStatistics();
      $ServiceClassAccelerated = array();
      foreach ($serviceStatArray as $XMLStat){
         $ServiceClass = new SERVICE_CLASS($XMLStat["ClassName"],
                                           $XMLStat["UniqueCounters"]["LANFlowControlSendBytes"],
                                           $XMLStat["UniqueCounters"]["LANFlowControlReceiveBytes"],
                                           $XMLStat["UniqueCounters"]["WANFlowControlSendBytes"],
                                           $XMLStat["UniqueCounters"]["WANFlowControlReceiveBytes"] );
         array_push($ServiceClassAccelerated, $ServiceClass);
      }

      return GraphProtocolBytes($ServiceClassAccelerated, true, "barchart", "Compression By Service Class",$DisplayImagemap);
   }

   function GraphCompressionBytes($title, $chartname, $legend, $data){
      // Create the graph. These two calls are always required
      $graph = new Graph(450, 350,"auto");
      $graph->SetScale("textlin");

      // Adjust the margin a bit to make more room for titles
      $graph->img->SetMargin(20,20,40,60);
      $graph->SetMarginColor('white');

      // Create a bar pot
      $bplot = new BarPlot($data);

      // Adjust fill color
      $bplot->SetFillColor('orange');

      // Setup values
      $bplot->value->Show();
      $bplot->value->SetFormatCallback('FormatThroughput');
      $bplot->value->SetFont(FF_FONT2,FS_BOLD);
      $bplot->SetFillColor( array(COLOR_PASS_BYTES, COLOR_PAYLOAD_BYTES, COLOR_PAYLOAD_BYTES) );

      // Make the bar a little bit wider
      $bplot->SetWidth(0.3);

      $graph->Add($bplot);

      // Setup the titles
      $graph->title->SetFont(FF_FONT2,FS_BOLD);
      $graph->title->Set($title);
      $graph->yaxis->Hide();
      $graph->xaxis->SetTickLabels( $legend );
      $graph->xaxis->SetLabelAlign("center", "top", "center");
      $graph->xaxis->SetFont(FF_FONT2,FS_BOLD);

      // Display the graph
      $graph->Stroke("temp/" . $chartname . "_graph.png");
      echo "   <IMG src='./temp/" . $chartname . "_graph.png?NoCache=" . time() . "'>";
      
      return $chartname;
   }

   //
   // Graph uncompressed bytes vs compressed bytes
   //
   function GraphCompressedUncompressed($XMLData, $CombineSendRecv){
      $CClear  = $XMLData["CompressionClearTextBytes"]["Rate"];
      $CCipher = $XMLData["CompressionCipherTextBytes"]["Rate"];
      $DClear  = $XMLData["DecompressionClearTextBytes"]["Rate"];
      $DCipher = $XMLData["DecompressionCipherTextBytes"]["Rate"];

      if (!$CombineSendRecv){
         $Output = GraphPerfCounters("Line Usage Before and After Compression (Bytes Sent)", array($CClear, $CCipher),
                            array("Uncompressed Bytes Sent","Compressed Bytes Sent"),
                            array(COLOR_PASS_BYTES, COLOR_PAYLOAD_BYTES), 8);
         echo "<img src='$AccelReadGN?NoCache=" . time() . "' name=$AccelReadGN>";
         echo $Output . "<BR><BR>";

         $Output = GraphPerfCounters("Line Usage Before and After Compression (Bytes Received)", array($DClear, $DCipher),
                            array("Uncompressed Bytes Received","Compressed Bytes Received"),
                            array(COLOR_PASS_BYTES, COLOR_PAYLOAD_BYTES), 8);
         echo $Output . "<BR><BR>";
      }else{
         for ($i=0; $i<sizeof($CClear); $i++){
            $ClearTotal  = $CClear[i]  + $DClear[i];
            $CipherTotal = $CCipher[i] + $DCipher[i];
         }

         $Output = GraphPerfCounters("Line Usage Before and After Compression", array($ClearTotal, $CipherTotal),
                            array("Uncompressed Bytes Sent","Compressed Bytes Sent"),
                            array(COLOR_PASS_BYTES, COLOR_PAYLOAD_BYTES), 8);
         echo "<img src='$AccelReadGN?NoCache=" . time() . "' name=$AccelReadGN>";
         echo $Output . "<BR><BR>";
      }

   }

   //
   // A chart graph little match vs big match vs disk matcher vs raw compression
   //
   function DrawCompressionBreakdownChart($GraphTimescale) {
      $Counters = OrbitalGet("SYSTEM",
            array(
                  "CompressionBigMatcherBytes",
                  "CompressionDiskMatchBytes",
                  "CompressionLZSBytes",
                  "CompressionZLIBBytes",
                  "CompressionRAWBytes",
                  "DecompressionBigMatcherBytes",
    	            "DecompressionDiskMatchBytes",
 	               "DecompressionLZSBytes",
                  "DecompressionZLIBBytes",
                  "DecompressionRAWBytes",
                  "UnixTime"
               ));

      // Now 'stack' the data...
      $DSK = GetCounterByTimescale($Counters["CompressionDiskMatchBytes"], $GraphTimescale);
      $DSK = AddArrays($DSK, GetCounterByTimescale($Counters["DecompressionDiskMatchBytes"], $GraphTimescale) );
      
      $BMB = AddArrays($DSK, GetCounterByTimescale($Counters["CompressionBigMatcherBytes"], $GraphTimescale) );
      $BMB = AddArrays($BMB, GetCounterByTimescale($Counters["DecompressionBigMatcherBytes"], $GraphTimescale) );

      $ZLB = AddArrays($BMB, GetCounterByTimescale($Counters["CompressionZLIBBytes"], $GraphTimescale) );
      $ZLB = AddArrays($ZLB, GetCounterByTimescale($Counters["DecompressionZLIBBytes"], $GraphTimescale) );   

      $LZS = AddArrays($ZLB, GetCounterByTimescale($Counters["CompressionLZSBytes"], $GraphTimescale) );
      $LZS = AddArrays($LZS, GetCounterByTimescale($Counters["DecompressionLZSBytes"], $GraphTimescale) );
    
      $RAW = AddArrays($LZS, GetCounterByTimescale($Counters["CompressionRAWBytes"], $GraphTimescale) );
      $RAW = AddArrays($RAW, GetCounterByTimescale($Counters["DecompressionRAWBytes"], $GraphTimescale) );

	   $GraphName = GraphPerfCounters("Compression Decompression Breakdown",
			    array($RAW, $LZS, $ZLB, $BMB, $DSK),
			    array("", "", "", ""),
			    array("red", "green", "green:0.5", "blue:0.5","blue:1.5"),8,0,$Counters["UnixTime"], NO_MAX_LINE, $GraphTimescale);

      return $GraphName;
   }/*DrawCompressionBreakdownChart()*/


   //
   // Draw the compression network diagram
   //
   function ShowCompressionFlowDiagram($SendUncompStr, $RecvUncompStr, $SendCompStr, $RecvCompStr, $Bidirectional=true)
   {
      include_once (HTTP_ROOT_DIR . "jpgraph/jpgraph_canvas.php");

      // Setup a basic canvas we can work
      $g = new CanvasGraph (600,220, 'auto');
      $g->SetMargin( 12,11,6 ,11);

      if ($Bidirectional){
         $g->SetBackgroundImage("images/BidirectionalFlowDiagram.png", BGIMG_COPY);
      }else{
         $g->SetBackgroundImage("images/UnidirectionalFlowDiagram.png", BGIMG_COPY);
      }

      $g->InitFrame();

      if ($Bidirectional){
         $TxtObj = new Text( $SendUncompStr, 160, 75);
         $TxtObj->SetFont( FF_FONT2, FS_BOLD,12);
         $TxtObj->Align( 'center','top');
         $TxtObj->Stroke( $g->img);

         $TxtObj = new Text( $RecvUncompStr, 160, 170);
         $TxtObj->SetFont( FF_FONT2, FS_BOLD,12);
         $TxtObj->Align( 'center','top');
         $TxtObj->Stroke( $g->img);

         $TxtObj  = new Text( $SendCompStr, 430, 75);
         $TxtObj->SetFont( FF_FONT2, FS_BOLD,12);
         $TxtObj->Align( 'center','top');
         $TxtObj->Stroke( $g->img);

         $TxtObj  = new Text( $RecvCompStr, 430, 170);
         $TxtObj->SetFont( FF_FONT2, FS_BOLD,12);
         $TxtObj->Align( 'center','top');
         $TxtObj->Stroke( $g->img);
      }else{
         $TxtObj = new Text( $SendUncompStr, 165, 95);
         $TxtObj->SetFont( FF_FONT2, FS_BOLD,12);
         $TxtObj->Align( 'center','top');
         $TxtObj->Stroke( $g->img);

         $TxtObj  = new Text( $SendCompStr, 425, 95);
         $TxtObj->SetFont( FF_FONT2, FS_BOLD,12);
         $TxtObj->Align( 'center','top');
         $TxtObj->Stroke( $g->img);
   /*
         $TxtObj = new Text( $SendCompStr, 430, 95);
         $TxtObj->SetFont( FF_FONT2, FS_BOLD,12);
         $TxtObj->Align( 'center','top');
         $TxtObj->Stroke( $g->img);
         */
      }


      $LANStr ="LAN Traffic (Uncompressed)";
      $TxtObj  = new Text( $LANStr, 160, 15);
      $TxtObj->SetFont( FF_FONT2, FS_BOLD,12);
      $TxtObj->Align( 'center','top');
      $TxtObj->Stroke( $g->img);

      $WANStr ="WAN Traffic (Compressed)";
      $TxtObj  = new Text( $WANStr, 430, 15);
      $TxtObj->SetFont( FF_FONT2, FS_BOLD,12);
      $TxtObj->Align( 'center','top');
      $TxtObj->Stroke( $g->img);

      $InfoStr ="Red denotes uncompressed LAN traffic. B";
      $TxtObj  = new Text( $WANStr, 430, 15);
      $TxtObj->SetFont( FF_FONT2, FS_BOLD,12);
      $TxtObj->Align( 'center','top');
      $TxtObj->Stroke( $g->img);


      // Now render the graph
      $g->Stroke("./temp/compression_network_diagram.png");
      return "<IMG src='./temp/compression_network_diagram.png?NoCache=" . time() . "'>";
   }



   function DrawCompressionBarChart($data, $chartname, $title, $maxy){
		$graph = new Graph(300, 200);

      //
      // Create a blank chart because we have no data
      //
      if ($maxy==0){         
         // Create the graph. These two calls are always required
         $graph  = new CanvasGraph(500,350,"auto");
         $graph->SetMargin(2,2,2,2);
         $graph->title->Set($chartname);
         $graph->InitFrame();

         $t = new Text( "No connections have been compressed.", 250, 150 );
         $t->SetFont( FF_FONT1,FS_BOLD);
         $t->Align( 'center','top');
         $t->ParagraphAlign( 'center');
         $t->SetBox("white","black","white");
         $t->Stroke( $graph->img);

      }else{

		   $graph->SetScale("textint", 1, $maxy);

		   $graph->img->SetMargin(20,20,40,40);
		   $graph->SetMarginColor('white');

		   $bplot = new BarPlot($data);
		   $bplot->SetFillColor('orange');

		   $bplot->value->Show();
		   $bplot->value->SetFormatCallback('FormatBytes');
		   $bplot->value->SetFont(FF_FONT1,FS_BOLD);
		   $bplot->SetFillColor( array(COLOR_PASS_BYTES, COLOR_PAYLOAD_BYTES,
                                     COLOR_PASS_BYTES, COLOR_PAYLOAD_BYTES) );

		   $bplot->SetWidth(0.3);
		   $graph->Add($bplot);

		   $graph->title->SetFont(FF_FONT2,FS_BOLD);
		   $graph->title->Set($title);
		   $graph->yaxis->Hide();
		   $graph->xaxis->SetTickLabels( array("Uncompressed", "Compressed") );
         $graph->xaxis->SetLabelAlign("center", "top", "center");
		   $graph->xaxis->SetFont(FF_FONT2,FS_BOLD);
      }

		// Display the graph
		$graph->Stroke("temp/" . $chartname . "_graph.png");
		return "temp/" . $chartname . "_graph.png";
	}
	
	function DrawCompressionBarChart_Send(){
      $CompressionStats = OrbitalGet("SYSTEM",
                                             array("CompressionClearTextBytes",
                                                   "CompressionCipherTextBytes",
                                                   "DecompressionClearTextBytes",
                                                   "DecompressionCipherTextBytes"
                                                   ));
      $UncompressedSent = $CompressionStats["CompressionClearTextBytes"]["Total"];
      $CompressedSent   = $CompressionStats["CompressionCipherTextBytes"]["Total"];
      $UncompressedRecv = $CompressionStats["DecompressionClearTextBytes"]["Total"];
      $CompressedRecv   = $CompressionStats["DecompressionCipherTextBytes"]["Total"];

      $GraphMaxY = max($UncompressedSent, $CompressedSent, $UncompressedRecv, $CompressedRecv);
      return DrawCompressionBarChart( array($UncompressedSent, $CompressedSent), "compression_send_graph", "Bytes Sent", $GraphMaxY);
	}
	
	function DrawCompressionBarChart_Recv(){
      $CompressionStats = OrbitalGet("SYSTEM",
                                             array("CompressionClearTextBytes",
                                                   "CompressionCipherTextBytes",
                                                   "DecompressionClearTextBytes",
                                                   "DecompressionCipherTextBytes"
                                                   ));
      $UncompressedSent = $CompressionStats["CompressionClearTextBytes"]["Total"];
      $CompressedSent   = $CompressionStats["CompressionCipherTextBytes"]["Total"];
      $UncompressedRecv = $CompressionStats["DecompressionClearTextBytes"]["Total"];
      $CompressedRecv   = $CompressionStats["DecompressionCipherTextBytes"]["Total"];

      $GraphMaxY = max($UncompressedSent, $CompressedSent, $UncompressedRecv, $CompressedRecv);
	   return DrawCompressionBarChart( array($UncompressedRecv, $CompressedRecv), "compression_recv_graph", "Bytes Received", $GraphMaxY);
	}

?>
