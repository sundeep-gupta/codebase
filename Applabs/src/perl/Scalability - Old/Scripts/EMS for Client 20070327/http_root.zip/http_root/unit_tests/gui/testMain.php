<?php
  //$gtk =& new PHPUnit_GUI_Gtk;
  //$gtk->main();
    require_once '../../PHPUnit/GUI/SetupDecorator.php';
    require_once '../../PHPUnit/GUI/Gtk.php';

    $gui = new PHPUnit_GUI_SetupDecorator(new PHPUnit_GUI_Gtk());
    $gui->getSuitesFromDir('..','.*\.php$',array('index.php','sql.php'));
    $gui->show();
?>
