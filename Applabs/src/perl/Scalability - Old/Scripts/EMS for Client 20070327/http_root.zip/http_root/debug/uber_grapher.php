<?
   include_once ("../html_helper.php");
   include_once ("../includes/orbital_lib.php");

   define('TEMP_DIR', ORBITAL_ROOT . "/http_root/temp/");  

   include_once (HTTP_ROOT_DIR . "jpgraph/jpgraph.php");
   include_once (HTTP_ROOT_DIR . "jpgraph/jpgraph_line.php");
   include_once (HTTP_ROOT_DIR . "xmlrpcutils/utils.php");

   function necho($str){
      echo $str . "<BR>\n";
   }

   function array_remove($myarray, $itemnum){
      $newarray = array();
      for ($i=0; $i < sizeof($myarray); $i++){
         if ($i != $itemnum){
            array_push($newarray, $myarray[$i]);
         }
      }
      return $newarray;
   }

   function GetPerfCounterNames($MachineName){
      $Result = xu_rpc_http_concise(
                     array(
                        'method' => "GetPerfCounterNames",                     
                        'args'      => array(),
                        'host'      => $MachineName,
                        'uri'       => RPC_URI,
                        'port'      => RPC_PORT
                     )
      );
      if ($Result == null)  { ThrowException("RPC call failed. Host " . $MachineName . " appears to not have WANScaler running on it.", true); }
      if (IsFault($Result)) { var_dumper($Result); ThrowException("Fault was returned. Aborting.", true); }
      return $Result;
   }

   function SaveUberGrapherConfig($filename, $config){
      $serializedData = serialize($config);
      $fp = fopen(TEMP_DIR . $filename, "w");
      fwrite($fp, $serializedData);
      fclose($fp);
   }

   function LoadUberGrapherConfig($filename){
      if (is_file(TEMP_DIR . $filename)){
         $serializedData    = implode("", @file(TEMP_DIR . $filename));
         $object  = unserialize($serializedData);      
         return $object;
      }else{
         return new UBER_GRAPHER_CONFIG();
      }
   }


   function SaveGraphPage($filename, $onePage){
      $serializedData = serialize($onePage);
      $fp = fopen($filename, "w");
      fwrite($fp, $serializedData);
      fclose($fp);
   }

   function LoadGraphPage($filename){
      if (is_file($filename)){
         $serializedData    = implode("", @file($filename));
         $object  = unserialize($serializedData);      
         return $object;
      }else{
         return new ONE_PAGE();
      }
   }


   function GetRemoteObjects($MachineName, $ClassName, $CounterName, $InstanceNum){
      $Param["Class"]     = $ClassName;
      $Param["Attribute"] = $CounterName;
      if ($InstanceNum != null) $Param["Instance"] = (int)$InstanceNum;

      $Result = xu_rpc_http_concise(
                     array(
                        'method' => "Get",
                        'args'      => $Param,
                        'host'      => $MachineName,
                        'uri'       => RPC_URI,
                        'port'      => RPC_PORT
                     )
      );
      if ($Result == null)  { ThrowException("RPC call failed. Host " . $MachineName . " appears to not have WANScaler running on it.", true); }
      if (IsFault($Result)) { var_dumper($Result); var_dumper($Param); ThrowException("Fault was returned. Aborting.", true); }
      return $Result;
   }

   class ONE_COUNTER{
      var $MachineName  ;
      var $ClassName;
      var $CounterName;
      var $InstanceNum;
      var $Data;
      var $Color;
      var $Scale;
      
      function ONE_COUNTER() {
         $this->InstanceNum = null;
         $this->Color       = "red";
      }
      
      function Display(){
         necho( "CounterName: " . $this->CounterName );
         necho( "ClassName:   " . $this->ClassName );
         necho( "InstanceNum: " . $this->InstanceNum );
         necho( "MachineName: " . $this->MachineName );
         necho( "Color:       " . $this->Color );
         necho( "Scale:       " . $this->Scale );
         
         if ( sizeof($this->Data) > 0){
            echo( "Data: " );
            foreach ($this->Data as $Elem){
               echo $Elem . " ";
            }
            necho("");
         }
      }
   }

   class ONE_GRAPH{
      var $GraphName;
      var $GraphID;
      var $Counters;
      
      function ONE_GRAPH($GraphName, $GraphID){
         $this->Counters  = array();
         $this->GraphName = $GraphName;
         $this->GraphID   = $GraphID;
      }

      function Display(){
         necho( "--------------------------------");
         necho( "--------------------------------");
         necho( "GraphName: " . $this->GraphName );
         necho( "GraphID:   " . $this->GraphID   );
         
         foreach ($this->Counters as $Counter){
            necho( ":::::");
            $Counter->Display();
         }         
      }

      function AddCounter($Graph){
         array_push($this->Counters, $Graph);
      }
   }
   
   class ONE_PAGE{
      var $Graphs;
      
      function ONE_PAGE(){
         $this->Graphs = array();
      }

      function AddGraph($oneGraph){
         array_push($this->Graphs, $oneGraph);
      }

   }
   
   class UBER_GRAPHER_CONFIG{
      var $GraphConfigDir;
      var $GraphConfigFile;
      function UBER_GRAPHER_CONFIG(){
         $this->GraphConfigDir  = TEMP_DIR;
         $this->GraphConfigFile = "FirstGraph.GraphSpec";
      }
   }
   
   function QueryForCounterData(&$OneGraph){
      $size = sizeof( $OneGraph->Counters );
      for ($i=0; $i<$size; $i++){
         $Data = GetRemoteObjects( $OneGraph->Counters[$i]->MachineName, $OneGraph->Counters[$i]->ClassName, 
                           $OneGraph->Counters[$i]->CounterName, $OneGraph->Counters[$i]->InstanceNum );
         $OneGraph->Counters[$i]->Data = $Data[$OneGraph->Counters[$i]->CounterName]["Rate"];
      }
   }

   function GraphData($OneGraph){
      if (sizeof($OneGraph->Counters) == 0) { return ""; }

      $GRAPH_WIDTH  = 600;
      $GRAPH_HEIGHT = 300;

      $Graph = &new Graph($GRAPH_WIDTH, $GRAPH_HEIGHT, "auto");
      $GraphDataSize = sizeof($OneGraph->Counters[0]->Data);
      $Graph->SetScale("linlin", 0, 0, 0, $GraphDataSize );
      $Graph->img->SetMargin(65,20,20,40);

      $Graph->title->SetFont(FF_FONT2, FS_BOLD);
      $Graph->title->Set($OneGraph->GraphName);

      $Graph->yaxis->title->Set("");
      $Graph->yaxis->title->SetFont(FF_FONT2, FS_BOLD);
      $Graph->yaxis->SetTitleMargin(60);
      $Graph->yaxis->SetLabelFormatCallback('BandwidthAxisFormatter');
      $Graph->legend->SetPos(.52, .07);

      $Graph->xaxis->SetTextLabelInterval(2);

      // Iterate through each of the plot datasets
      for ($c=0; $c < sizeof($OneGraph->Counters); $c++)
      {
         //
         // First scale the data (if nothing else multiplying by 8 {MBs -> Mbs} )
         for ($i=0; $i<$GraphDataSize; $i++){
            $OneGraph->Counters[$c]->Data[$i] = $OneGraph->Counters[$c]->Data[$i] * 
                                                $OneGraph->Counters[$c]->Scale * 8;
         }
      
         $Plot = &new LinePlot( array_reverse($OneGraph->Counters[$c]->Data) );
         $Plot->SetColor( $OneGraph->Counters[$c]->Color );
         $Plot->SetLegend($OneGraph->Counters[$c]->CounterName);
         $Plot->SetWeight(2);
         $Graph->Add($Plot);

         // For some reason now we have to kill the Plot object
         unset($Plot);
      }

      // Display the graph
      $ImageName      = str_replace(" ", "", $OneGraph->GraphName);
      $OutputFilename = TEMP_DIR . $ImageName . ".png";
      $Graph->Stroke($OutputFilename);

      return "<img name=$ImageName src='../temp/$ImageName" . ".png?NoCache=" . time() . " width='600' 'height='300' name=$ImageName>";   
   }


   //
   // Do the initial loading of configs
   //
   $UberConfig = LoadUberGrapherConfig("UberGraph.Config");
   $OnePage = LoadGraphPage($UberConfig->GraphConfigDir . $UberConfig->GraphConfigFile);
   $PERF_COUNTERS = GetPerfCounterNames("localhost");
   $CounterChanged = false;

   //
   // Do an add
   //
   if (isset($_GET["AddGraph"])){
      $GraphName  = str_replace(" ", "", $_GET["GraphName"]);
      $OneGraph = new ONE_GRAPH($GraphName, 1);
      $OnePage->AddGraph($OneGraph);
      $CounterChanged = true;
   }
   else if (isset($_GET["AddGraphCounter"])){
      $GraphName  = $_GET["GraphName"];
      $Added      = false;
      
      $OneCounter = new ONE_COUNTER();
      $ClassCounter = $_GET["ClassCounter"];
      $Class                   = substr($ClassCounter, 0, strpos($ClassCounter, ".") );
      $Counter                 = substr($ClassCounter, strpos($ClassCounter, ".")+1, 
                                             strlen($ClassCounter)-strpos($ClassCounter, ".") );
      $OneCounter->MachineName = $_GET["System"];
      $OneCounter->ClassName   = $Class;
      $OneCounter->CounterName = $Counter;
      $OneCounter->InstanceNum = $_GET["Instance"];
      $OneCounter->Color       = $_GET["Color"];
      $OneCounter->Scale       = $_GET["Scale"];

      for ($gn=0; $gn<sizeof($OnePage->Graphs); $gn++){         
         if ( $OnePage->Graphs[$gn]->GraphName == $GraphName){
         
            $OnePage->Graphs[$gn]->AddCounter($OneCounter);
            break;
         }
      }
            
      $CounterChanged = true;
   }
   //
   // Delete a graph counter
   //
   else if (isset($_GET["DeleteGraphCounter"])){
   
      $GraphName = $_GET["GraphName"];
      $Entry     = (int)$_GET["Entry"];
   
      for ($gn=0; $gn<sizeof($OnePage->Graphs); $gn++){
         if ($OnePage->Graphs[$gn]->GraphName == $GraphName){
            $OnePage->Graphs[$gn]->Counters = array_remove($OnePage->Graphs[$gn]->Counters, $Entry);
            break;
         }
      }

      $CounterChanged = true;
   }
   //
   // Update a graph counter
   //
   else if (isset($_GET["UpdateGraphCounter"])){
   
      $GraphName = $_GET["GraphName"];
      $Entry     = (int)$_GET["Entry"];
   
      for ($gn=0; $gn<sizeof($OnePage->Graphs); $gn++){
         if ($OnePage->Graphs[$gn]->GraphName == $GraphName){
            $OneCounter = &$OnePage->Graphs[$gn]->Counters[$Entry];
            
            $ClassCounter = $_GET["ClassCounter"];
            $Class                   = substr($ClassCounter, 0, strpos($ClassCounter, ".") );
            $Counter                 = substr($ClassCounter, strpos($ClassCounter, ".")+1, 
                                                   strlen($ClassCounter)-strpos($ClassCounter, ".") );            
            $OneCounter->MachineName = $_GET["Machine"];
            $OneCounter->ClassName   = $Class;
            $OneCounter->CounterName = $Counter;
            $OneCounter->InstanceNum = $_GET["Instance"];
            $OneCounter->Color       = $_GET["Color"];
            $OneCounter->Scale       = $_GET["Scale"];
            $CounterChanged = true;
            break;
         }
      }

   }
   
   //
   // Delete a graph
   //
   else if (isset($_GET["DeleteGraph"])){
   
      $GraphName = $_GET["GraphName"];
   
      for ($gn=0; $gn<sizeof($OnePage->Graphs); $gn++){
         if ($OnePage->Graphs[$gn]->GraphName == $GraphName){
            $OnePage->Graphs = array_remove($OnePage->Graphs, $gn);
            $CounterChanged = true;
            break;
         }
      }

      $CounterChanged = true;
   } else if (isset($_GET["SetUberConfig"])){
      $UberConfig->GraphConfigDir = $_GET["ConfigDir"]; 
      $UberConfig->GraphConfigFile = $_GET["ConfigFile"];
      SaveUberGrapherConfig("UberGraph.Config", $UberConfig);
      echo HTML::InsertRedirect();
      exit;
   }

   if ($CounterChanged){
      SaveGraphPage($UberConfig->GraphConfigDir . $UberConfig->GraphConfigFile, $OnePage);
      echo HTML::InsertRedirect();
      exit;
   }   


?>
   <TITLE>WANScaler Uber Grapher</TITLE>
      <META http-equiv="Pragma" content="no-cache">
      <META http-equiv="Cache-control" content="no-cache">
      <link rel=stylesheet type="text/css" href="../css/orbital.css">
   </HEAD>

   <BODY>
   <TABLE>
      <TR><TD>
         <FORM name=SetUberConfig>
            ConfigDir:<INPUT type="text" name="ConfigDir" value="<?echo $UberConfig->GraphConfigDir?>" size=40>
            ConfigFile:<INPUT type="text" name="ConfigFile" value="<?echo $UberConfig->GraphConfigFile?>" size=25>
            <INPUT type="Submit" name="SetUberConfig" value="Update">
         </FORM>
      </TD></TR>
   </TABLE>
   
   <TABLE>
      <TR><TD>
         <FORM name=AddGraph>
            GraphName:<INPUT type="text" name="GraphName" value="" size=20>            
            <INPUT type="Submit" name="AddGraph" value="Add">
         </FORM>
      </TD></TR>
   </TABLE>

   <SCRIPT>
      function VerifyAddGraphEntries(Me){
         if (Me.form.GraphName.value == ""){
            alert("You must first create a graph (see the above box)");
            return false;
         }
      
         if (Me.form.System.value == ""){
            alert("You need to enter a an IP/machine name for the system box");
            return false;
         }
      
         if (Me.form.ClassCounter.value.substring(0, 6)  != "SYSTEM"){
            if (Me.form.Instance.value == ""){
               alert("You need to enter an instance number for all Classes other then SYSTEM");
               return false;
            }
         }
         return true;
         //Me.form.submit();
      }
   </SCRIPT>
   <TABLE>
      <TR><TD>
         <FORM name=AddGraphCounter>
            GraphName:<SELECT Name="GraphName" size="0">
            <?
               foreach ($OnePage->Graphs as $OneGraph){
                  $OneGraph->Display();
                  echo "<option value='" . $OneGraph->GraphName . "'>" . $OneGraph->GraphName . "</option>";
               }
            ?>
            </SELECT>
         
         
            <? if (isset($_GET["System"])) { $System = $_GET["System"];}else {$System = "";} ?>
            
            System:<INPUT type="text" name="System" value="<?=$System?>" size=10>
            <SELECT Name="ClassCounter">
            <? if (isset($_GET["Class"])) { $Class = $_GET["Class"];}else {$Class = "ADAPTER";} 
               foreach ($PERF_COUNTERS as $PerfCounterClassname=>$PerfCountersByClass){
                  foreach ($PerfCountersByClass as $PerfCounterName){
                     echo "<option value='" . $PerfCounterClassname . "." . $PerfCounterName . "'";
                     echo ">" . $PerfCounterClassname . "." . $PerfCounterName . "</option>";
                  }
               }
            ?>
            </SELECT>
            
            Inst#:<INPUT type="text" name="Instance" value="" size=2>
            
            <SELECT Name="Color" size="0">
               <option value="red" SELECTED>red</option>
               <option value="green">green</option>
               <option value="black">black</option>
               <option value="blue">blue</option>
               <option value="black">green</option>
               <option value="orange">orange</option>
               <option value="yellow">yellow</option>
               <option value="gray">gray</option>
            </SELECT>
            
            Scale:<INPUT type="text" name="Scale" value="1" size=2>
            
            <INPUT type="submit" name="AddGraphCounter" value="Add" onClick="return VerifyAddGraphEntries(this)">
         </FORM>
      </TD></TR>
   </TABLE>
   <BR>

<?
      //
      // Display Graph auto refresh toggle
      //
      $GraphRefreshRate = GetParameter("UI.Graph.RefreshRate");
      $AutoRefresh      = GetParameter("UI.Graph.AutoRefresh");

      if (isset($_GET["ToggleAutoRefresh"]))
      {
         $AutoRefresh = !$AutoRefresh;
         SetParameter("UI.Graph.AutoRefresh", $AutoRefresh);
      }
?>

   <script type="text/javascript">
      function refreshGraphImages() {
         
         document.images["redrawimage"].src = "uber_grapher.php?variable="+Math.random();
         setTimeout('refreshGraphImages()', <?=($GraphRefreshRate*1000)?>);
      <?
         foreach ($OnePage->Graphs as $OneGraph){
            $GraphName = $OneGraph->GraphName;
            echo( "if (document.images['$GraphName'] != null){" );
            echo( "document.images['$GraphName'].src    = '../temp/$GraphName.png?variable='+Math.random() ");
            echo( "}" );
         }
      ?>   

      }

      <?if ($AutoRefresh){?>
          setTimeout('refreshGraphImages()', <?=($GraphRefreshRate*1000)?>);
      <?}?>
   </script>
   <IMG src='' name=redrawimage width=0 height=0>
<?

   foreach ($OnePage->Graphs as $OneGraph){
      $i         = 0;
      $GraphName = $OneGraph->GraphName;

      echo("<TABLE><TR><TH colspan=7 align=center>" . $OneGraph->GraphName .
           "&nbsp;<A href='uber_grapher.php?GraphName=$GraphName&DeleteGraph'>Del</A>" .
           "</TH></TR>");
      echo("<TR><TD>System</TD><TD>Class/Counter</TD><TD>Inst#</TD><TD>Color</TD><TD>Scale</TD><TD></TD><TD></TD></TR>");

      foreach ($OneGraph->Counters as $OneCounter){
         echo("<FORM>");
         echo("<TR>");
            echo("<TD><INPUT size=15 type=text name=Machine value=" . $OneCounter->MachineName . "></TD>");
            
            $CurClassCounterName = $OneCounter->ClassName . "." . $OneCounter->CounterName;
            echo("<TD><SELECT name=ClassCounter>");
               foreach ($PERF_COUNTERS as $PerfCounterClassname=>$PerfCountersByClass){
                  foreach ($PerfCountersByClass as $PerfCounterName){
                     echo "<option value='" . $PerfCounterClassname . "." . $PerfCounterName . "'";
                     if ($CurClassCounterName == ($PerfCounterClassname . "." . $PerfCounterName)){ echo(" SELECTED ");}
                     echo ">" . $PerfCounterClassname . "." . $PerfCounterName . "</option>";
                  }
               }
            echo("</SELECT></TD>");
            echo("<TD><INPUT size=2 type=text name=Instance value=" . $OneCounter->InstanceNum . "></TD>");
            echo("<TD><INPUT size=6 type=text name=Color value=" . $OneCounter->Color       . "></TD>");
            echo("<TD><INPUT size=3 type=text name=Scale value=" . $OneCounter->Scale       . "></TD>");
            echo("<INPUT type=hidden name=Entry value=$i>");
            echo("<INPUT type=hidden name=GraphName value=$GraphName>");
            echo("<TD><INPUT type=Submit name=UpdateGraphCounter value=Update></TD>");
            echo("<TD><INPUT type=Submit name=DeleteGraphCounter value=Del></TD>");
         echo("</TR>");
         echo("</FORM>");
         $i++;
      }
      
      necho("</TABLE>");
   }
 
   echo "<div align='left'>";
   echo "Auto-refresh <B>" . ($AutoRefresh?"ON":"OFF") . "</B>: <A href='?ToggleAutoRefresh'>Toggle</A>";
   echo "</div>";
 
    //
    // Fetch the data for each graph and display it
    //
   foreach ($OnePage->Graphs as $OneGraph){
      QueryForCounterData($OneGraph);
      //$OneGraph->Display();
      necho( GraphData($OneGraph) );
   }
   
?>
