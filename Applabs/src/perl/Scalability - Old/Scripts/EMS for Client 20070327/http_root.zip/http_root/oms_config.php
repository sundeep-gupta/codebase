<?
   define('PAGE_IS_HA_CLUSTER_INDEPENDANT', true);
   include("includes/header.php");
   $Auth->CheckRights(AUTH_LEVEL_ADMIN);


   if ( isset($_GET["ConfigureOmsSettings"]) )
   {
      SetParameterText("OMS.Controller.Hostname", $_GET["OmsIP"] );
      SetParameterText("OMS.Controller.Port",     $_GET["OmsPort"] );
   }

   $OmsIP    = GetParameter("OMS.Controller.Hostname");
   $OmsPort  = GetParameter("OMS.Controller.Port");
   $OmsConnectionStatus = GetSystemParam("OMSIsConnected");

?>


   <font class="pageheading">Configure Settings: WANScaler Controller</font><BR><BR>

   <form name="OrbitalEdgeMode">
      <table class="settings_table">
        <tr>
          <th>
            WANScaler Controller IP Address:
          </th>
          <td>
            <input name="OmsIP" type="text" value="<?=$OmsIP?>">
          </td>
        <tr>
        </tr>
          <th>
            WANScaler Controller Port:
          </th>
          <td>
            <input name="OmsPort" type="text" value="<?=$OmsPort?>">
          </td>
        </tr>

        <tr>
          <th>
          </th>
          <td>
            <input name="ConfigureOmsSettings" type="submit" value="Update">
          </td>
        </tr>
      </table>
   </form>

   <br/><br/>
   <table class="settings_table">
     <tr>
       <th>
         Connection Status:
       </th>
       <td>
         <b><?= $OmsConnectionStatus ? "Connected" : "Not Connected" ?></b>
       </td>
     <tr>

   </table>

<? include(HTTP_ROOT_INCLUDES_DIR ."footer.php"); ?>
