<?php

require_once '../PHPUnit/TestCase.php';
require_once '../service_lib.php';

/**
 * Test of PHP unit code
 *
 */
  class ServiceClassTest extends PHPUnit_TestCase {

	function ServiceClassTest($name) {
		$this->PHPUnit_TestCase($name);
	}

	function setUp() {
	}

	function testCreate() {
		$this->setComment("Testing creating one service Class");
		$resp = createServiceClass(7770, "test");
		$this->assertTrue(isset($resp['Status']) && $resp['Status'] == "OK");
	}

	function testMultipleCreates() {
	    $this->setComment("Testing multiple creates");
		$resp = createServiceClass(7771, "test");
		$this->assertTrue(isset($resp['Status']) && $resp['Status'] == "OK");
		$resp = createServiceClass(7772, "test");
		$this->assertTrue(isset($resp['Status']) && $resp['Status'] == "OK");
		$resp = createServiceClass(7773, "test");
		$this->assertTrue(isset($resp['Status']) && $resp['Status'] == "OK");
		$resp = createServiceClass(7774, "test");
		$this->assertTrue(isset($resp['Status']) && $resp['Status'] == "OK");
		$resp = createServiceClass(7775, "test");
		$this->assertTrue(isset($resp['Status']) && $resp['Status'] == "OK");
	}

	function lookup($serviceClassArray, $id) {
	   foreach ($serviceClassArray as $s) {
	       if ($s['ClassID'] == $id) return true;
	   }
	   return false;
	}

	function testGetAllClasses() {
	    $this->setComment("Testing getting service classes");
		$sa = getServiceClasses(); 
		$this->assertTrue(isset($sa) && $this->lookup($sa, 7771) && 
		                  $this->lookup($sa, 7772) && $this->lookup($sa, 7773) &&
		                  $this->lookup($sa, 7774) && $this->lookup($sa, 7775) && 
		                  $this->lookup($sa, 7770));
	}

	function testCreateRule1() {
	    $this->setComment("Testing creating a rule with a range");
		$resp = createServiceRule(7770, "192.168.0.1", "192.168.0.2", "40", "50");
		$this->assertTrue(isset($resp['Status']) && $resp['Status'] == "OK");
	}

	function testCreateRule2() {
	    $this->setComment("Testing creating a rule with just one port");
		$resp = createServiceRule(7770, "192.168.0.2", "192.168.0.3", "40", "");
		$this->assertTrue(isset($resp['Status']) && $resp['Status'] == "OK");
	}

	function testDeleteRule1() {
	    $this->setComment("Testing deleting rule");
		$resp = deleteServiceRule(7770, 0);
		//var_dumper($resp);
		$this->assertTrue(isset($resp['Status']) && $resp['Status'] == "OK");
	}

	function testMultipleDeletes() {
		$this->setComment("Testing deleting multiple service classes");
		$resp = deleteServiceClass(7771);
		$this->assertTrue(isset($resp['Status']) && $resp['Status'] == "OK");
		$resp = deleteServiceClass(7772);
		$this->assertTrue(isset($resp['Status']) && $resp['Status'] == "OK");
		$resp = deleteServiceClass(7773);
		$this->assertTrue(isset($resp['Status']) && $resp['Status'] == "OK");
		$resp = deleteServiceClass(7774);
		$this->assertTrue(isset($resp['Status']) && $resp['Status'] == "OK");
		$resp = deleteServiceClass(7775);
		$this->assertTrue(isset($resp['Status']) && $resp['Status'] == "OK");
	}

	function testDelete1() {
		$this->setComment("Testing deleting one service classes");
		$resp = deleteServiceClass(7770);
		$this->assertTrue(isset($resp['Status']) && $resp['Status'] == "OK");
	}
}
?>
