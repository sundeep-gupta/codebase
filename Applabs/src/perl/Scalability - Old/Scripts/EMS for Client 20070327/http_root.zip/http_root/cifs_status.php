<?
   include("includes/header.php");
   $Auth->CheckRights(AUTH_LEVEL_VIEWER);


   function SortIt($a,$b) {
      if ($a["IdleTime"] == $b["IdleTime"]) return 0;
      return $a["IdleTime"] > $b["IdleTime"] ? 1 : -1;
   }

   function CifsRow($h,$n) {
      echo "<TR> <TH align=center> ",
      	$h,
      	" </th> <td align=center> ",
      	$n,
      	" </td> </tr>";
   }


      $SelectedTab = CreateTabs("CifsStatus", 
                 array("ShowGraphs" => "Acceleration Graphs", 
                       "ShowConnections" => "Accelerated Connections")
                );


      $GraphRefreshRate = GetParameter("UI.Graph.RefreshRate");
      $AutoRefresh      = GetParameter("UI.Graph.AutoRefresh");

      if (isset($_GET["ToggleAutoRefresh"]))
      {
         $AutoRefresh = !$AutoRefresh;
         SetParameter("UI.Graph.AutoRefresh", $AutoRefresh);
      }
 ?>
      <BR>
      <div align="center">
         Auto-refresh <B><?=$AutoRefresh?"ON":"OFF"?></B>: <A href="./cifs_status.php?ToggleAutoRefresh">Toggle</A>
      </div>
      <BR>

<?    /////////////////////////////////////////////////////////////////
      // Display the graphs page
      //////////////////////////////////////////////////////////////////               
      if ( $SelectedTab == "ShowGraphs"){    

      $S = OrbitalGet("SYSTEM",
   		   array("CifsUnacceleratedConnections",
   			   "CifsUnhandledOperations",
   			   "CifsProtocolErrors",
   			   "CifsLockBreaks",
   			   "CifsWriteIoErrors",
   			   "CifsWriteBehindBytes",
   			   "CifsDiscardedReadBytes",
   			   "CifsReadAheadBytes",
   			   "CifsActiveCount",
   			   "CifsPassthroughCount",
   			   "CifsUnacceleratedReqs",
   			   "CifsAcceleratedReqs"
   			   ));

      $RA = $S["CifsReadAheadBytes"]["Rate"];
      $DI = $S["CifsDiscardedReadBytes"]["Rate"];
      $WB = $S["CifsWriteBehindBytes"]["Rate"];
      $UR = $S["CifsUnacceleratedReqs"]["Rate"];
      $AR = $S["CifsAcceleratedReqs"]["Rate"];


      echo "<br><br>";
      echo "<font class=pageheading>CIFS Status: Throughput Graphs</font><BR><BR>";

      //
      // Calculate and graph the percent improvement in throughput
      //
      $elems = sizeof($UR);
      for ($i=0; $i<$elems; $i++){

         if ($AR[$i] != 0 && $UR[$i] != 0){
            $PercentImprovement[$i] = (($UR[$i]-$AR[$i]) / $AR[$i]) * 100;
         }else{
            $PercentImprovement[$i] = 0;
         }
      }

      $SavedRegGN = GraphPerfCounters("CIFS Optimization (Saved Requests)",
                        array($PercentImprovement),      /* array of Counters */
                        array(""),              /* array of Labels   */
                        array(COLOR_PAYLOAD_BYTES),     /* array of Colors   */
                        1,                      /* Multiply all YAxis value by this */
                        0,                      /* 0 - YAxis autoscales, and other value sets the Yaxis max */
                        -1,                     /* Start time for time scale */
                        0,                      /* Draw a horizontal line here (used to indicate SlowSendRate) */
                        RESOLUTION_ONE_MINUTE,  /* Graph scale resolution */
                        YAXIS_FORMAT_PERCENT);  /* Yaxis units */
      echo "<img src='$SavedRegGN?NoCache=" . time() . "' name=$SavedRegGN>";
      echo "<br><br><br>";

      //
      // Graph the read traffic throughput
      //
      $AccelReadGN = GraphPerfCounters("CIFS Accelerated READ Traffic",
                     array($RA),
                     array("Read"),
                     array("dodgerblue4"), 8, 0);
      echo "<img src='$AccelReadGN?NoCache=" . time() . "' name=$AccelReadGN>";
      echo "<br><br><br>";

      //
      // Graph the write traffic throughput
      //
      $AccelWriteGN = GraphPerfCounters("CIFS Accelerated WRITE Traffic",
                     array($WB),
                     array("Write"),
                     array("dodgerblue4"), 8, 0);
    
      echo "<img src='$AccelWriteGN?NoCache=" . time() . "' name=$AccelWriteGN>";
      
      GenerateInplaceUpdateJavascript($AutoRefresh, $GraphRefreshRate);
   }
   /////////////////////////////////////////////////////////////////
   // Display the connections page
   //////////////////////////////////////////////////////////////////               
   elseif  ( $SelectedTab == "ShowConnections"){

      if ($AutoRefresh){
         echo HTML::InsertRedirect("", $GraphRefreshRate);
      }
?>

      <br><br>
      <font class=pageheading>CIFS Status: Accelerated Connections</font><BR><BR>

   <?
      $S = OrbitalGet("SYSTEM",
   		   array("CifsUnacceleratedConnections",
   			   "CifsUnhandledOperations",
   			   "CifsProtocolErrors",
   			   "CifsLockBreaks",
   			   "CifsWriteIoErrors",
   			   "CifsWriteBehindBytes",
   			   "CifsDiscardedReadBytes",
   			   "CifsReadAheadBytes",
   			   "CifsActiveCount",
   			   "CifsPassthroughCount",
   			   "CifsUnacceleratedReqs",
   			   "CifsAcceleratedReqs"
   			   ));
      echo "<TABLE class=settings_table>";
      CifsRow("Currently Active Accelerated Connections:",$S["CifsActiveCount"]);
      CifsRow("Currently Active Non-accelerated Connections:",$S["CifsPassthroughCount"]);
      if ($S["CifsUnacceleratedConnections"] != 0) CifsRow("Historically Non-accelerated Connections",$S["CifsUnacceleratedConnections"]);
      if ($S["CifsWriteIoErrors"] != 0) CifsRow("Historical write accelerated operations reporting errors",$S["CifsWriteIoErrors"]);
      if ($S["CifsUnhandledOperations"] != 0) CifsRow("Historical unhandled protocol operations",$S["CifsUnhandledOperations"]);
      if ($S["CifsProtocolErrors"] != 0) CifsRow("Historical protocol errors detected",$S["CifsProtocolErrors"]);
      if ($S["CifsLockBreaks"] != 0) CifsRow("Lock Breaks",$S["CifsLockBreaks"]);
      echo "</TABLE>";

      $CifsInstances = GetInstances("CIFS");
      $Conns = OrbitalGet("CIFS",array("ConnectionInstanceNumber","TotalReadAheadBytes","TotalWriteBehindBytes","Passthrough"),
                  $CifsInstances["Instances"]);
      $CifsConnections = array();
      foreach($Conns as $OneCon) {
         array_push($CifsConnections,$OneCon["ConnectionInstanceNumber"]);
      }
      $Attributes = array("ClientLogicalAddress", "ClientPhysicalAddress",
                           "ServerLogicalAddress", "ServerPhysicalAddress",
                           "Duration", "InstanceNumber", "BytesTransferred", "IdleTime", "Accelerated", "Agent", "FilterInstanceNumber");
      $Cifs = OrbitalGet("CONNECTION",$Attributes,$CifsConnections);
      //
      // Now, graft the Totals onto the specific instances
      //
      $i = 0;
      foreach($Conns as $OneCon) {
         $Cifs[$i]["TotalReadAheadBytes"] = $OneCon["TotalReadAheadBytes"];
         $Cifs[$i]["TotalWriteBehindBytes"] = $OneCon["TotalWriteBehindBytes"];
         $Cifs[$i]["CifsPassthrough"] = $OneCon["Passthrough"];
         $i = $i + 1;
      }

      //
      // Now sort into the two bins, pipelined and unpipelined connections
      //
      $Pipe = array();
      $Unpipe = array();
      foreach($Cifs as $OneCon) {
         if ($OneCon["CifsPassthrough"] == 1) {
            array_push($Unpipe,$OneCon);
         } else {
            array_push($Pipe,$OneCon);
         }

      }

      //
      // List the unaccelerated connections (or at least the first ten)
      //
      usort($Unpipe,"SortIt");
      ?>
         <BR><BR>
         <TABLE class=settings_table2 width=100%>
         <tr> <th colspan=7><?=sizeof($Unpipe)?> Non-accelerated CIFs Connections </th></tr>
         <tr>
            <th>Details</th>
            <th>Client</th>
            <th></th>
            <th>Server</th>
            <th>Duration</th>
            <th>Idle</th>
           <TH>Remote Unit</TH>
        </tr>
      <?
      for ($i = 0; $i < 10 && $i < sizeof($Unpipe); $i = $i + 1) {
         $OneConnection = $Unpipe[$i];
         $ClientAddress = FormatIPAddressPort($OneConnection["ClientLogicalAddress"], false);
         $ServerAddress = FormatIPAddressPort($OneConnection["ServerLogicalAddress"]);
         $BytesTransferred = $OneConnection["BytesTransferred"];
         if ($OneConnection["Agent"]["Accelerated"]) {
            $Agent = FormatAgent($OneConnection["Agent"]);
         } else {
            $Agent = "<i>None</i>";
         }
         $Duration      = $OneConnection["Duration"];
         $InstanceNumber = $OneConnection["InstanceNumber"];
         $IdleTime = $OneConnection["IdleTime"];
         ?>
          <TR>
            <TD align=center><a href="./connection_info.php?InstanceNumber=<?=$InstanceNumber?>">
               <img src="./images/icon-info.gif" border="0" alt="Click Here For Detailed Connection Information"> </a></TD>
            <TD><?=$ClientAddress?></TD>
            <TD align="center"><=></TD>
            <TD><?=$ServerAddress?></TD>
            <TD align="center"><?=(int)$Duration?>&nbsp;secs</TD>
            <TD align="center"><?=(int)$IdleTime?>&nbsp;secs</TD>
            <TD align="center"><?=$Agent?></TD>
          </TR>

   <? }  ?>
      </table>

      <BR><BR>
      <TABLE  class=settings_table2 width=100%>
         <TR><TH colspan=9><?=sizeof($Pipe)?> Accelerated CIFS Connection</TH></TR>
         <TR>
            <TH>Details</TH>
            <TH>Client</TH>
            <TH></TH>
            <TH>Server</TH>
            <TH>Duration</TH>
            <TH>Idle</TH>
            <TH>Read</TH>
            <TH>Write</TH>
            <TH>Remote Unit</TH>
         </TR>
   <?

      usort($Pipe,"SortIt");
      foreach ($Pipe as $OneConnection)
      {
            $ClientAddress = FormatIPAddressPort($OneConnection["ClientLogicalAddress"], false);
            $ServerAddress = FormatIPAddressPort($OneConnection["ServerLogicalAddress"]);
            $BytesTransferred = $OneConnection["BytesTransferred"];
            if ($OneConnection["Agent"]["Accelerated"]) {
               $Agent = FormatAgent($OneConnection["Agent"]);
            } else {
               $Agent = "<i>None</i>";
            }
            $Duration      = $OneConnection["Duration"];
            $InstanceNumber = $OneConnection["InstanceNumber"];
	        $IdleTime = $OneConnection["IdleTime"];
      ?>
            <TR>
               <TD align=center><a href="./connection_info.php?InstanceNumber=<?=$InstanceNumber?>">
                  <img src="./images/icon-info.gif" border="0" alt="Click Here For Detailed Connection Information"> </a></TD>
               <TD><?=$ClientAddress?></TD>
               <TD align="center"><=></TD>
               <TD><?=$ServerAddress?></TD>
               <TD align="center"><?=(int)$Duration?>&nbsp;secs</TD>
               <TD align="center"><?=(int)$IdleTime?>&nbsp;secs</TD>
               <TD align="center"><?=FormatBytes($OneConnection["TotalReadAheadBytes"])?></TD>
               <TD align="center"><?=FormatBytes($OneConnection["TotalWriteBehindBytes"])?></TD>
               <TD align="center"><?=$Agent?></TD>
            </TR>
      <?
      }


   }
   /////////////////////////////////////////////////////////////////
   // Last tab block...should only get here if you've screwed something up
   //////////////////////////////////////////////////////////////////               
   else{
      ThrowException("An error occured. Somehow you escaped the tab blocks!", true);
   }

?>

<? include(HTTP_ROOT_INCLUDES_DIR . "footer.php"); ?>
