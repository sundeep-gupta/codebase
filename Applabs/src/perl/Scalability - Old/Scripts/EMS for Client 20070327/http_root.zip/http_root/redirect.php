<?
   include("includes/header.php");
?>


<? include(HTTP_ROOT_INCLUDES_DIR ."footer.php"); ?>
