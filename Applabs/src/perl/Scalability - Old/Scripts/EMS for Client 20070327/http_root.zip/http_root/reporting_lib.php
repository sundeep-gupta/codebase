<?php
define('FPDF_FONTPATH','font/');
include_once('includes/fpdf/fpdf.php');

class ORBITAL_REPORT extends FPDF
{
   var $AutoFillAlternator = true;

   //Page header
   function Header()
   {
      $this->SetFillColor(0,82,155);
      //$this->SetFillColor(200,220,255);
      //$this->Rect(0, 0,  170, 10, "F");

      $this->Image('images/citrix_logo_large.png', 5, -3, 40);
      //$this->SetTextColor(255,255,255);
      $this->SetFont('Arial','B',20);
      $this->Text(110, 12, 'WAN Optimization Report');
   }

   function AddTableHeader($Value){
      $this->SetFont('Arial','',14);
      $this->SetLeftMargin(15);
      $this->SetDrawColor(0,0,0);
      $this->SetLineWidth(1);
      
      $this->SetFillColor(0, 0, 0);
      $this->SetTextColor(0);
      $this->SetFont('Arial','B');
      $this->SetFontSize(16);
      $this->Cell(180, 7, $Value, 'B', 1, 'C', 0);
      
      $AutoFillAlternator = true;
   }


   function AddTableRow($Name, $Value){
 
      $this->SetFont('Arial','',14);
      $this->SetLeftMargin(15);

      $this->SetFillColor(224, 230, 232);
      $this->SetTextColor(0);
      $this->SetDrawColor(128,0,0);
      $this->SetLineWidth(.3);
      $this->SetFont('Arial','');
      $this->Cell(100, 7, $Name, 0, 0, 'L', $this->AutoFillAlternator);
      $this->Cell(80, 7, $Value, 0, 0, 'R', $this->AutoFillAlternator);
      $this->Ln();
      
      $this->AutoFillAlternator = !$this->AutoFillAlternator;
   }


   //Page footer
   function Footer()
   {
      //Position at 1.5 cm from bottom
      $this->SetY(-15);
      //Arial italic 8
      $this->SetFont('Arial','I',8);
      //Page number
      $this->Cell(0,10,'Page '.$this->PageNo().'/{nb}',0,0,'C');
   }
}


?>
