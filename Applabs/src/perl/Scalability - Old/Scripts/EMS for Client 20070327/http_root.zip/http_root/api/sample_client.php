<?php
/**
 * This file contains an example SOAP client that calls methods on the example
 * SOAP server in this same directory.
 *
 * PHP versions 4 and 5
 *
 * LICENSE: This source file is subject to version 2.02 of the PHP license,
 * that is bundled with this package in the file LICENSE, and is available at
 * through the world-wide-web at http://www.php.net/license/2_02.txt.  If you
 * did not receive a copy of the PHP license and are unable to obtain it
 * through the world-wide-web, please send a note to license@php.net so we can
 * mail you a copy immediately.
 *
 * @category   Web Services
 * @package    SOAP
 * @author     Shane Caraveo <Shane@Caraveo.com>   Port to PEAR and more
 * @copyright  2003-2005 The PHP Group
 * @license    http://www.php.net/license/2_02.txt  PHP License 2.02
 * @link       http://pear.php.net/package/SOAP
 */

require 'SOAP/Client.php';

/**
 * This client runs against the example server in SOAP/example/server.php.  It
 * does not use WSDL to run these requests, but that can be changed easily by
 * simply adding '?wsdl' to the end of the url.
 */
$soapclient = new SOAP_Client('http://localhost/api/server.php');
// This namespace is the same as declared in server.php.
$options = array('namespace' => 'urn:SOAP_WANScaler_Server',
                 'trace' => 0);


//
// Query for a display a list of connections
//
$ret = $soapclient->call('getConnections',
                         $params = array('start' => 0, 'count' => 5000),
                         $options);
echo "<p>";

echo "Displaying the connection list:<br>";

//
// Check to see if an error was thrown
//
if (PEAR::isError($ret)) {
   echo 'Error: ' . $ret->getMessage() . "<br>\n";
   return;
}

foreach ($ret->CONNECTION as $Connection){
   echo $Connection->SrcIP;
   echo ":";
   echo $Connection->SrcPort;
   echo "<br>";
}
echo "</p>";
echo "<br>\n";

//
// This call demonstrates calling a function that takes a string as an arg and returns a string
//
$ret = $soapclient->call('echoStringSimple',
                         $params = array('inputStringSimple' => 'this is a test string'),
                         $options);
print_r($ret);
echo "<br>\n";

