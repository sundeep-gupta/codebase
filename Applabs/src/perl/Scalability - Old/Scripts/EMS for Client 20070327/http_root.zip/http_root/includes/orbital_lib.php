<?php

   error_reporting (E_ERROR | E_WARNING | E_PARSE | E_NOTICE);


   /************************************************************************
    *  Global includes go here
   ************************************************************************/
   include_once ("configure.php");
   include_once (HTTP_ROOT_DIR . "xmlrpcutils/utils.php");
   include_once (HTTP_ROOT_DIR . "jpgraph/jpgraph.php");
   include_once (HTTP_ROOT_DIR . "jpgraph/jpgraph_line.php");
   include_once (HTTP_ROOT_DIR . "jpgraph/jpgraph_pie.php");
   include_once (HTTP_ROOT_DIR . "jpgraph/jpgraph_bar.php");
   include_once (HTTP_ROOT_DIR . "jpgraph/jpgraph_canvas.php");
   include_once (HTTP_ROOT_DIR . "html_helper.php");
   include_once (HTTP_ROOT_DIR . "includes/graphing.php");


   /************************************************************************
    *  WebUI logon/authentication code
   ************************************************************************/
   define('AUTH_LEVEL_ANONYMOUS', 3);
   define('AUTH_LEVEL_VIEWER', 2);
   define('AUTH_LEVEL_ADMIN', 1);
   define('AUTH_LEVEL_UNKNOWN', -1);
   define('AUTH_SUPER_USER', "SuperUser");
   define('AUTH_OLD_ADMIN_PASSWORD1', "fec735026372d0b1af114bc215ac11c38a074c1c");
   define('AUTH_OLD_ADMIN_PASSWORD2', "02a143647e3efe482e3e149bfa987f1098cde9a2");

   class OD_AUTH
   {
      var $UserLevel;
      var $UserAccounts = array();

      function OD_AUTH()
      {
         // start a session and don't let it stop automatically:
         session_set_cookie_params(0);
         @session_start();
         setcookie("PHPSESSID", session_id());

         //
         // If running on windows don't require a login
         //
         if ( RUNNING_WINDOWS ){
            $_SESSION["UserLevel"] = AUTH_LEVEL_ADMIN;
            $_SESSION['user']     = "admin";
            defined('NO_LOGIN_REQUIRED');
         }else{
            $this->UserLevel = AUTH_LEVEL_UNKNOWN;
            if (isset($_SESSION["UserLevel"]))  { $this->UserLevel = $_SESSION["UserLevel"];}
         }
      }

      function Logout() {

         // to do a logout, all session-variables will be deleted,
         // a variable 'logout' is added:
         $_SESSION = array('logout' => true);
         ShowStatusMessage("You were successfully logged out.");
         exit;
      }


      //
      // Validate whether the user is logged in and has the rights to this page.
      //
      function CheckLogin($ForceRelogin = false)
      {
         if (defined('NO_LOGIN_REQUIRED')) return;

         $baselink = "http://" . $_SERVER['HTTP_HOST'] . $_SERVER['PHP_SELF'];

         // check if the current loading of the page is the first loading
         // after a logout:
         if (isset($_SESSION['logout']) && $_SESSION['logout'] != '') {
             unset($_SESSION['logout']);
             //
             // initialize a relogin on Firefox
             // (request login with username "relogin"):
             //
             // CAUTION: After that, relative hyperlinks like
             //  <a href="{$_SERVER['PHP_SELF']}">Link</a>
             // will maybe translated into an absolute hyperlink like
             //  http://relogin:relogin@...
             // which will lead to an error-message in Firefox.
             //
             // So you always have to use absolute hyperlinks like $baselink.
             //
             if (! preg_match("/MSIE/", $_SERVER['HTTP_USER_AGENT'])) {
                 $link = preg_replace("/^http:\/\/(.*)$/",
                             "http://relogin:relogin@$1", $baselink);
                 header("Location: $link");
                 exit;
             }
         }

         // check if a new realm needs to be generated because
         // it's the first loading of the page (or the first loading
         // after a logout):
         //
         // Remark: The realm is generated with some random signs,
         // because Internet Explorer will forget the username if the
         // realm changes. Unfortunately Firefox doesn't do so.
         if (! isset($_SESSION['realm']) ) {
             $_SESSION['realm'] = "WANScaler Realm";
             if (preg_match("/MSIE/", $_SERVER['HTTP_USER_AGENT'])  || $ForceRelogin) {
                $_SESSION['realm'] .= " (" . rand(0, 10000) . ")";
             }
         }

         // check if a user has already logged in before:
         if (isset($_SESSION['user'])) {
             unset($_SESSION['login']);
             return true;
         }

         // check if a user just entered a username and password:
         //
         // is_authorized() has to return 'true' if and only if
         // the username and the password given are correct.
         if (isset($_SESSION['login'])) {
             if ( isset($_SERVER['PHP_AUTH_USER']) && isset($_SERVER['PHP_AUTH_PW']) ){

                  $Result = CallRPCMethod("LoginUser", array("Username"=>$_SERVER['PHP_AUTH_USER'],
                                          "Password"=>$_SERVER['PHP_AUTH_PW']));

                  if ($Result["Valid"] == true){
                     $this->UserLevel       = $Result["Type"];
                     $_SESSION["UserLevel"] = $Result["Type"];
                     $_SESSION['user'] = $_SERVER['PHP_AUTH_USER'];
                     unset($_SESSION['login']);
                     return;
                  }

             }
         }


         //
         // They are trying to use the old password, prompt them that it's changed
         //
         if (isset($_SERVER['PHP_AUTH_PW']) && 
             (
              (sha1($_SERVER['PHP_AUTH_PW']) == AUTH_OLD_ADMIN_PASSWORD1) ||
              (sha1($_SERVER['PHP_AUTH_PW']) == AUTH_OLD_ADMIN_PASSWORD2)
              )
             ){
            $Message = "<H1>You are using the old default admin password. The default password changed in this release. Please consult your documentation for the new password.</H1>";
         }else{
            $Message = "<H1>You need to log in before you can access this page.</H1>";
         }

         // let the browser ask for a username and a password:
         $_SESSION['login'] = true;
         header("WWW-Authenticate: Basic realm=\"{$_SESSION['realm']}\"");
         header("HTTP/1.0 401 Unauthorized");
         echo "<CENTER>" . $Message . "</CENTER>";
         exit;

      }//CheckLogin()

      function CheckRights($PageLevel, $ExitOnFailure = true)
      {
         if (defined('NO_LOGIN_REQUIRED')) return false;

         if ($this->UserLevel > $PageLevel)
         {
            if ($ExitOnFailure)
            {
               echo "<CENTER><H2>You do not have the proper rights to look at this page!</H2></CENTER>";
               echo "<CENTER>(You are currently logged in as: " . $_SERVER['PHP_AUTH_USER'] . ")</CENTER>";
               exit();
            }
            {
               return false;
            }
         }

         return true;
      }

      //
      // If the user creates an account called SuperUser, this account will be
      // able to see certain normally hidden UI features.
      //
      function IsSuperUser(){
         return ( isset($_SERVER['PHP_AUTH_USER']) &&  AUTH_SUPER_USER == $_SERVER['PHP_AUTH_USER']);
      }
   }


   /************************************************************************
    *  Branding functions
   ************************************************************************/
   function ProdName(){
      if ( (!isset($_SESSION)) || (!isset($_SESSION["OD_PRODNAME"])) ){
         $_SESSION["OD_PRODNAME"] = GetParameter("UI.Branding.ProductName");
      }
      return $_SESSION["OD_PRODNAME"];
   }

   function ProdNameWithoutSpaces(){
      return str_replace(" ", "", ProdName());
   }

   function ProdLogo(){
      if ( (!isset($_SESSION)) || (!isset($_SESSION["OD_PRODUCT_LOGO"])) ){
         $_SESSION["OD_PRODUCT_LOGO"] = GetParameter("UI.Branding.ProductLogo");
      }
      return $_SESSION["OD_PRODUCT_LOGO"];
   }

   /************************************************************************
    *  XMLRPC/OrbitalCore communication helpers
   ************************************************************************/
   function IsFault($Result)
   {
      if ( ( is_array($Result) ) &&
           (array_key_exists("Fault", $Result)) )
      {
         return true;
      }elseif ( is_array($Result) ){
         foreach ($Result as $Item){
            return IsFault($Item);
         }
      }
      else
      {
         return false;
      }
   }

   //
   // Check if a return value is a fault, if so display the error and stop running
   //
   function TestForFault($Result, $Message = "", $abortOnFailure = true)
   {
      if ( IsFault($Result) )
      {
         ThrowException($Message, true);
      }
   }

   function CallRPCMethod($MethodName, $Params=array())
   {
      $Result = xu_rpc_http_concise(
                     array(
                        'method' => $MethodName,
                        'args'   => $Params,
                        'host'      => RPC_SERVER,
                        'uri'    => RPC_URI,
                        'port'      => RPC_PORT
                     )
      );
      return $Result;
   }

   //
   // Wrappers the basic "Get" rpc call.
   //
   function OrbitalGet($Class, $Attributes = "", $InstanceNumber = -1, $NumItemsToReturn = -1, $Server=RPC_SERVER, $Timeout=0)
   {
      $Param["Class"] = $Class;
      if ($Attributes != "") $Param["Attribute"] = $Attributes;
      if ($NumItemsToReturn != -1){ $Param["Count"] = $NumItemsToReturn; }
      if ( ($InstanceNumber != -1) ||
           (is_array($InstanceNumber) && (sizeof($$InstanceNumber) > 0))  ){
         $Param["Instance"] = $InstanceNumber;
      }

      $Result = xu_rpc_http_concise(
                  array(
                     'method' => "Get",
                     'args'      => array($Param),
                     'host'      => $Server,
                     'uri'    => RPC_URI,
                     'port'      => RPC_PORT,
                     'timeout'   => $Timeout
                  ) );
      return $Result;
   }


   //
   // Wrappers the basic "Set" rpc call.
   //
   function OrbitalSet($ODClass, $Attributes = "", $InstanceNumber = -1)
   {
      $Param["Class"] = $ODClass;
      if ($Attributes != "") $Param["Attribute"] = $Attributes;
      if ($InstanceNumber != -1) $Param["Instance"] = $InstanceNumber;

      $Result = xu_rpc_http_concise(
                  array(
                     'method' => "Set",
                     'args'      => array($Param),
                     'host'      => RPC_SERVER,
                     'uri'    => RPC_URI,
                     'port'      => RPC_PORT
                  ) );
      if (IsFault($Result)){
         ThrowException("Error in OrbitalSet", false);
         var_dumper($Result);
      }

      return $Result;
   }

   //
   // Get Instance Numbers for some object type.
   //
   function GetInstances($ODClass)
   {
      $Param["Class"] = $ODClass;
      $Result = xu_rpc_http_concise(
                  array(
                     'method' => "GetInstances",
                     'args'      => array($Param),
                     'host'      => RPC_SERVER,
                     'uri'        => RPC_URI,
                     'port'      => RPC_PORT
                  ) );
      return $Result;
   }

   //
   // To Be Removed - This is legacy code
   //
   function IsServerRunning()
   {
      $result = xu_rpc_http_concise(
                     array(
                        'method' => "HelloWorld",
                        'host'      => RPC_SERVER,
                        'uri'    => RPC_URI,
                        'port'      => RPC_PORT
                     )
      );

      return isset($result);
   }

   function GetSystemParam($ParamName, $System=RPC_SERVER)
   {
      $Param["Class"] = "SYSTEM";
      $Param["Attribute"] = $ParamName;

      $Result = xu_rpc_http_concise(
                     array(
                        'method' => "Get",
                        'args'      => $Param,
                        'host'      => $System,
                        'uri'    => RPC_URI,
                        'port'      => RPC_PORT
                     )
      );
      TestForFault($Result[$ParamName], "Parameter " . $ParamName . " not found!");

      return $Result[$ParamName];
   }

   function SetSystemParam($ParamName, $ParamValue, $System=RPC_SERVER)
   {
      $Param["Class"]                  = "SYSTEM";
      $Param["Attribute"][$ParamName]  = $ParamValue;

      $Result = xu_rpc_http_concise(
                     array(
                        'method' => "Set",
                        'args'      => $Param,
                        'host'      => $System,
                        'uri'    => RPC_URI,
                        'port'      => RPC_PORT
                     )
      );
      TestForFault($Result, "Parameter " . $ParamName . " not found!");

      return $Result[$ParamName];
   }

   function GetParameterObject($ParamName, $System=RPC_SERVER)
   {
      $Param["Class"] = "PARAMETER";
      $Param["Attribute"] = $ParamName;

      $Result = xu_rpc_http_concise(
                     array(
                        'method' => "Get",
                        'args'      => $Param,
                        'host'      => $System,
                        'uri'    => RPC_URI,
                        'port'      => RPC_PORT
                     )
      );

      TestForFault($Result[$ParamName], "Parameter " . $ParamName . " not found!");
      return $Result[$ParamName];
   }

   //
   // GetParameter() - Get one parameter
   // returned: The parameter value
   //
   function GetParameterText($ParamName, $System=RPC_SERVER)
   {
      $Object = GetParameterObject($ParamName, $System);
      return $Object["Text"];
   }
   //
   // GetParameter() - Get One parameter as an XML Object
   //
   function GetParameter($Param, $System=RPC_SERVER)
   {
      $Object = GetParameterObject($Param, $System);
      return $Object["XML"];
   }

   function GetParameters($Params, $System=RPC_SERVER){
      $Param["Class"] = "PARAMETER";
      $Param["Attribute"] = $Params;

      $Result = xu_rpc_http_concise(
                     array(
                        'method' => "Get",
                        'args'      => $Param,
                        'host'      => $System,
                        'uri'    => RPC_URI,
                        'port'      => RPC_PORT
                     )
      );
      return $Result;
   }

   function GetParameterDefaultText($Param, $System=RPC_SERVER)
   {
      $Object = GetParameterObject($Param, $System);
      return $Object["DefaultText"];
   }
   function GetParameterDefault($Param, $System=RPC_SERVER)
   {
      $Object = GetParameterObject($Param, $System);
      return $Object["Default"];
   }
   function GetParameterType($Param, $System=RPC_SERVER) {
      $Object = GetParameterObject($Param, $System);
      return $Object["TypeName"];
   }
   function SetParameterAsXML($Param,$Value)
   {
      $Params["Name"] = $Param;
      $Params["Value"] = $Value;
      $Result = xu_rpc_http_concise(
                     array(
                        'method' => "SetParameterAsXML",
                        'args'   => $Params,
                        'host'      => RPC_SERVER,
                        'uri'    => RPC_URI,
                        'port'      => RPC_PORT
                     )
      );
      TestForFault($Result, "Parameter " . $Param . " not found!");
      return $Result;
   }

   //
   // SetParameter()
   //
   function SetParameter($ParamName, $ParamValue)
   {
      $Param["Class"] = "PARAMETER";
      $Param["Attribute"] = $ParamName;
      $Param["Value"] = $ParamValue;
      $Result = xu_rpc_http_concise(
                     array(
                        'method' => "Set",
                        'args'      => $Param,
                        'host'      => RPC_SERVER,
                        'uri'    => RPC_URI,
                        'port'      => RPC_PORT
                     )
      );

      TestForFault($Result, "Parameter " . $ParamName . " not found!");
      return $Result;
   }
   function SetParameterText($ParamName, $ParamValue)
   {
      $Param["Class"] = "PARAMETERTEXT";
      $Param["Attribute"] = $ParamName;
      $Param["Value"] = (string)$ParamValue;
      $Result = xu_rpc_http_concise(
                     array(
                        'method' => "Set",
                        'args'      => $Param,
                        'host'      => RPC_SERVER,
                        'uri'    => RPC_URI,
                        'port'      => RPC_PORT
                     )
      );

      TestForFault($Result, "Parameter " . $ParamName . " not found!");
      return $Result;
   }

   //
   // GetAllParameters() - Get more then one parameter
   // returned: An array of parameter values
   //
   function GetAllParameters()
   {
      $Param["Class"] = "PARAMETER";

      $Result = xu_rpc_http_concise(
                     array(
                        'method' => "Get",
                        'args'      => $Param,
                        'host'      => RPC_SERVER,
                        'uri'    => RPC_URI,
                        'port'      => RPC_PORT
                     ) );
      return $Result;
   }


   //
   // SetParameter()
   //
   function SendCommand($Command, $ParamValue)
   {
      $Params[0] = $Command . " " . $ParamValue;
      $Result = xu_rpc_http_concise(
                     array(
                        'method' => "Command",
                        'args'      => $Params,
                        'host'      => RPC_SERVER,
                        'uri'    => RPC_URI,
                        'port'      => RPC_PORT
                     )
      );

      TestForFault($Result, true);
      return $Result;
   }

   function GetParamAsStruct($ParamName)
   {
      $UserAccounts = xu_rpc_http_concise(
                     array(
                        'method' => "GetParameterAsXML",
                        'args'      => $ParamName,
                        'host'      => RPC_SERVER,
                        'uri'    => RPC_URI,
                        'port'      => RPC_PORT
                     )
      );
      return $UserAccounts;
   }

   function SetParamAsStruct($ParamName, $Value)
   {
      $Param["Name"] = $ParamName;
      $Param["Value"] = $Value;

      $Result = xu_rpc_http_concise(
                     array(
                        'method' => "SetParameterAsXML",
                        'args'      => $Param,
                        'host'      => RPC_SERVER,
                        'uri'    => RPC_URI,
                        'port'      => RPC_PORT
                     )
      );
   }

   /************************************************************************
    *  Text formatting code
   ************************************************************************/
   //
   // Turns a value in seconds into a more readible time i.e.:
   // 12 Days, 5 Hours,
   function ToPrintableTime($Seconds)
   {
      $Seconds = (int)$Seconds;
      $Days  = (int) ($Seconds / (60*60*24));
      $Seconds = $Seconds - ($Days * 60*60*24);

      $Hours = (int) ($Seconds / (60*60));
      $Seconds = $Seconds - ($Hours * 60*60);

      $Minutes = (int) ($Seconds / 60);
      $Seconds = $Seconds - ($Minutes * 60);

      return "$Days days, $Hours hours, $Minutes min, $Seconds sec";
   }


   // Turns a value in seconds into a more readible time i.e.:
   // 12 Days, 5 Hours,
   function ToCompactPrintableTime($Seconds)
   {
      $Seconds = (int)$Seconds;
      $Days  = (int) ($Seconds / (60*60*24));
      $Seconds = $Seconds - ($Days * 60*60*24);

      $Hours = (int) ($Seconds / (60*60));
      $Seconds = $Seconds - ($Hours * 60*60);

      $Minutes = (int) ($Seconds / 60);
      $Seconds = $Seconds - ($Minutes * 60);

      return "$Days:$Hours:$Minutes:$Seconds";
   }


   // Turns a value in seconds into a more readible time i.e.:
   // 12 Days, 5 Hours,
   function ToPrintableBytes($Bytes)
   {
      if ($Bytes > (1000*1000*1000) )
      {
         return (int)($Bytes/(1000*1000*1000)) . "G";
      }
      else if ($Bytes > (1000*1000) )
      {
         return (int)($Bytes/(1000*1000) ) . "M";
      }
      else if ($Bytes > (1000) )
      {
         return (int)($Bytes/(1000) ) . "K";
      }

      return $Bytes;
   }


   function FormatIPAddress($IP) {
      if (array_key_exists("DNSName",$IP)) {
         return $IP["DNSName"]."(".$IP["Dotted"].")";
      } else {
         return $IP["Dotted"];
      }
   }

   function FormatIPAddressPort($Addr, $UseTextNames=true) {
      if (array_key_exists("PortName",$Addr) && $UseTextNames) {
         return FormatIPAddress($Addr)  . ":<BR>" . $Addr["PortName"] ."(" .$Addr["Port"].")";
      } else {
         return FormatIPAddress($Addr)  . ":" . $Addr["Port"];
      }
   }

   function FormatTCPAddress($Address) {
      $Physical = $Address["Physical"];
      $Logical = $Address["Logical"];
      $StrLogical = FormatIPAddressPort($Logical);
      $StrPhysical = FormatIPAddressPort($Physical);
      if ($StrLogical == $StrPhysical) {
         return $StrLogical;
      } else {
         return "Logical: " . $StrLogical . " Physical:" . $StrPhysical;
      }
   }
   function FormatAgent($Agent) {
      if (array_key_exists("IP",$Agent) && $Agent["Accelerated"]) {
         return "<a href='http://" . $Agent["IP"]["Dotted"] . "'>" .
                    FormatIPAddress($Agent["IP"]) .
                " </a>" .
         "&nbsp;<img src='./images/icon-link.gif' border='0' alt='Click Here For Detailed System Information'>";
      } else {
         return $Agent["Printable"];
      }
   }

   function FormatAddressWithAgent($Logical,$Agent) {
      $StrLogical = FormatIPAddressPort($Logical);
      if (!$Agent["Accelerated"]) {
         return $StrLogical;
      } else {
         return $StrLogical . " <b><i>(WANScaler Partner)</b></i> " . FormatAgent($Agent);
      }
   }

   //
   // Returns the tcp address in the form of:
   //      foobar.com:http  or
   //      1.2.3.4:80
   function FormatTCPAddressCompact($Value)
   {
      $Result = "";

      if (array_key_exists("DNSName",$Value))
      {
         $Result .= $Value["DNSName"];
      } else {
         $Result .= $Value["Dotted"];
      }

      $Result .= ":";

      if (array_key_exists("PortName",$Value))
      {
         $Result .= $Value["PortName"];
      } else {
         $Result .= $Value["Port"];
      }

      return $Result;
   }

   function FormatTimeStamp($timestamp) {
      $thatdate = getdate($timestamp);
      return strftime("%b %d, %Y %H:%M:%S", $timestamp);
   }

   function FormatDate($Date) {
      return FormatTimeStamp($Date->timestamp);
   }

   function FormatThroughput($Throughput)
   {
      if ($Throughput >= (1000*1000*1000) )
      {
         $Throughput = $Throughput / (1000*1000*1000);
         $Throughput = number_format($Throughput, 1) . " Gbps";
      }
      else if ($Throughput >= (1000*1000) )
      {
         $Throughput = $Throughput / (1000*1000);
         $Throughput = number_format($Throughput, 1) . " Mbps";
      }
      else if ($Throughput >= 1000)
      {
         $Throughput = $Throughput/1000;
         $Throughput = number_format($Throughput, 1) . " Kbps";
      }else{
         $Throughput = number_format($Throughput, 1) . " bps";
      }
      return $Throughput;

   }

   function FormatBytes($Value){
      $Value = (float)$Value;
      if ($Value >= 1000*1000*1000){
         $Suffix = "G";
         $Value = $Value / (1000 * 1000 * 1000);
      }else if ($Value >= 1000*1000){
         $Suffix = "M";
         $Value = $Value / (1000 * 1000);
      }else if ($Value >= 1000){
         $Suffix = "K";
         $Value = $Value / (1000);
      }else {
         return "" . $Value;
      }

      return sprintf("%3.1f%s", $Value, $Suffix);
   }

   //
   // Do compression graphs
   //
   function FormatRatio($Num,$Denom) {
      if ($Denom == 0) {
         $Ratio = 0;
      } else {
         $Ratio = $Num/$Denom;
      }
      if ($Ratio >= 10) {
         return sprintf("%d to 1",(int)($Ratio+.5));
      } else if ($Ratio != 0) {
         return sprintf("%0.1f to 1",$Ratio);
      } else {
         return "N/A";
      }
   }

   /************************************************************************
    *  Networking related code
   ************************************************************************/
   //
   // Gets the local host name
   //
   function GetHostname()
   {
      if (function_exists('posix_uname')) {
         $Result = posix_uname();
         $Hostname = $Result["nodename"];
      } else {
         $Hostname = getenv("COMPUTERNAME");
      }

      // Trunc if too long
      if (strlen($Hostname) > 15){
         $Hostname = substr($Hostname, 0, 14) . "...";
      }
      return $Hostname;
   }

   //
   // Attempts to ping a host and returns true or false if it was successful
   //
   function PingHost($Host)
   {
      if (RUNNING_WINDOWS){ return true;}
   
      $Results = `ping -c 1 $Host -W 1`;

      if (substr_count($Results, "1 received") == 0)
      {
         return false;
      }
      else
      {
         return true;
      }
   }
   
   //
   // Checks to see if the host hosts the IP passed to the function
   //
   function HostHasIP($Host)
   {
      //
      // We don't have a way 
      //
      if (RUNNING_WINDOWS ){
         return true;
      }
         
      // For now, don't attempt to actually test the address...just return true...fixme later
      //
      $Results = `ip addr | grep "$Host"`;

      if (strlen($Results) == 0)
      {
         return false;
      }
      else
      {
         return true;
      }
   }


   /************************************************************************
    *  Misc unclassified helper functions
   ************************************************************************/

   //
   // Functions used to keep a page refresh from getting/posting values again
   //
   function UpdateHttpRefreshSig()
   {
      if (isset($_GET) && sizeof($_GET) )
      {
         $Params = "";
         foreach ($_GET as $Item=>$Value)
         {
            $Params .= $Item . "=" . $Value;
         }
         if (isset($_SESSION['CurrentPageParamHash'])){
            $_SESSION['LastPageParamHash'] = $_SESSION['CurrentPageParamHash'];
         }
         $_SESSION['CurrentPageParamHash'] = md5($Params);
      }
   }

   //
   // Was this page a refresh?
   //
   function IsPageARefresh()
   {
      if ( (isset($_SESSION['LastPageParamHash'])) &&
           (isset($_SESSION['LastPageParamHash'])) &&
           (sizeof($_GET) > 0) &&
           ($_SESSION['CurrentPageParamHash'] == $_SESSION['LastPageParamHash']) )
      {
         return true;
      }
      return false;
   }

   function RestartOrbital()
   {
      if (IsServerRunning()){
         SendCommand("reboot", "");
      }else{
         exec("/sbin/reboot");
      }
   }

   function ThrowException($ErrorMsg, $Fatal = false)
   {
      echo "<BR><BR><FONT color=\"red\" size=\"+2\"><CENTER>$ErrorMsg</CENTER></FONT>";

      if ($Fatal) exit();
   }

   function ShowStatusMessage($Msg)
   {
      echo "<BR><BR><FONT color=\"blue\" size=\"+2\"><CENTER>$Msg</CENTER></FONT>";
   }

   //
   // And operation was performed that requires a reboot to be completed
   //
   function DisplayRebootRequired(){
      $RebootRequired = GetSystemParam("UnitRequiresReboot");

      if ($RebootRequired){
         echo "<DIV class=giant_error>\n";
         echo "<TABLE width=100%>\n";
         echo "   <TR><TD>\n";
         echo "      Unit requires restart<BR>\n";
         echo "      Please restart when convenient<BR>\n";
         echo "   </TD></TR>\n";
         echo "</TABLE>\n";
         echo "</DIV>\n";
         echo "<BR>";
      }
   }


   //
   // If we are in passthrough, a large warning is displayed
   //
   function DisplayPassthroughState(){
      $System = OrbitalGet('SYSTEM', array(
         'Passthrough', 'PassthroughReason', 'GroupInfo'));
      $IsPassthrough     = $System["Passthrough"];
      $PassthroughReason = $System["PassthroughReason"];
      $GroupModeInfo     = $System["GroupInfo"];
      if (! $IsPassthrough && $GroupModeInfo["GroupPassThroughFlag"]) {
         $IsPassthrough = true;
         $PassthroughReason = "Group Member Failure Or Misconfiguration";
      }

      if ($IsPassthrough){
         echo "<DIV class=giant_error>\n";
         echo "<TABLE width=100%>\n";
         echo "   <TR><TD>\n";
         echo "      All " . ProdName() . " Traffic Is Currently Unaccelerated Due To:<BR>\n";
         echo "(" . $PassthroughReason . ")";
         echo "   </TD></TR>\n";
         echo "</TABLE>\n";
         echo "</DIV>\n";
         echo "<BR>";
      }
   }

   function GetMaxSendRate(){
      return min( GetSystemParam("RuledSendRate"), GetParameter("SlowSendRate") );
   }

   function GetMaxRecvRate(){
      return min( GetSystemParam("RuledRecvRate"), GetParameter("SlowRecvRate") );;
   }

   function GetLimit($Limit) {
      $Result = OrbitalGet("LIMIT",array($Limit));
      return $Result[$Limit];
   }

   function DisplayLicenseExpirationCountdown(){
      $Result    = OrbitalGet("LIMIT", array("EXPIRATIONDATE") );
      $TimeLeft  = ($Result["EXPIRATIONDATE"]->timestamp - time()) / (60*60*24);
      $DaysLeft  = (int)$TimeLeft;
      $HoursLeft = (int) (($TimeLeft - $DaysLeft) * 24);

      if ( ($TimeLeft < 0) || ($DaysLeft > 30) ) { return; }

      echo "<DIV class=giant_warning>\n";
      echo "<TABLE width=100%>\n";
      echo "   <TR><TD>\n";
      echo "      Warning: License Expires In ";
      if ($DaysLeft  > 0) { echo "$DaysLeft Days "; }
      if ($HoursLeft > 0) { echo "$HoursLeft Hours"; }
      echo "   </TD></TR>\n";
      echo "</TABLE>\n";
      echo "</DIV>\n";
      echo "<BR>";
   }



   //
   // Rename the key of one of the array items.
   //
   function array_key_rename(&$TheArray, $OldName, $NewName){
      $Temp = $TheArray[$OldName];
      unset($TheArray[$OldName]);
      $TheArray[$NewName] = $Temp;
   }



   //
   // Return VECTOR <string> of TrafficAdapter
   //
   function GetTrafficAdapter()
   {
      $Param["Class"] = "SYSTEM";
      $Param["Attribute"] = "TrafficAdapter";
      $Adapters = xu_rpc_http_concise(
                                    array(
                                       'method' => "Get",
                                       'args'      => array($Param),
                                       'host'      => RPC_SERVER,
                                       'uri'    => RPC_URI,
                                       'port'      => RPC_PORT
      ));

      $Results =   $Adapters["TrafficAdapter"];

      return $Results;
   }


   //
   // Return VECTOR <string> of NonTrafficAdapter
   //
   function GetNonTrafficAdapter()
   {
      $Param["Class"] = "SYSTEM";
      $Param["Attribute"] = "NonTrafficAdapter";
      $Adapters = xu_rpc_http_concise(
                                    array(
                                       'method' => "Get",
                                       'args'      => array($Param),
                                       'host'      => RPC_SERVER,
                                       'uri'    => RPC_URI,
                                       'port'      => RPC_PORT
      ));

      $Results =   $Adapters["NonTrafficAdapter"];

      return $Results;
   }

   //
   // This page brings together most usual statics in one place
   //
   function AdapterInfo($A,$InstanceNumber) {

      $SplitRate = GetParameter("UI.UseSplitRates");
//      $Result["Send Rate Setting"] = FormatThroughput($A["RuledSendRate"]);
//      $Result["Send Rate Constrained"] = FormatThroughput($A["EffectiveSendRate"]);
      if ($SplitRate) {
         $Result["Recv Rate Setting"] = FormatThroughput($A["RuledRecvRate"]);
//       $Result["Recv Rate Constrained"] = FormatThroughput($A["EffectiveRecvRate"]);
      }
      $Result["MAC Address"] = $A["MacAddress"];
      if (sizeof($A["HostedAddresses"]) == 1) {
         $Result["IP Address"] = FormatIPAddress($A["HostedAddresses"][0]["Address"]);
         $Result["Subnet Mask"] = FormatIPAddress($A["HostedAddresses"][0]["Mask"]);
      } else {
         foreach($A["HostedAddresses"] as $ix => $Value) {
            $Result["IP Address [" . $ix . "]"] = FormatIPAddress($Value["Address"]);
            $Result["Subnet Mask [" . $ix . "]"] = FormatIPAddress($Value["Mask"]);
         }
      }
      $Result["Description"] = $A["Description"];
      if ($A["Partner"] != $InstanceNumber) {
         $Result["Bridged Adapter"] = "<a href=\"./adapter_info.php?InstanceNumber=" . $A["Partner"]. "\"> More Info <img src=\"./images/icon-info.gif\" border=\"0\" alt=\"Click Here For Detailed Adapter Information\"> </a>";
      }
      $Result["NIC Media Type"] = $A["MediaType"];
      switch ($A["WireSpeed"]) {
         case 10000000: $Result["NIC Speed"] = "10 Mb/Sec"; break;
         case 100000000: $Result["NIC Speed"] = "100 Mb/Sec"; break;
         case 1000000000: $Result["NIC Speed"] = "1000 Mb/Sec"; break;
         default: $Result["NIC Speed"] = $A["WireSpeed"];
      }
                if ($A["AutoNegotiation"] != "") $Result["AutoNegotiation"] = $A["AutoNegotiation"];
                if ($A["Duplex"] != "") $Result["Duplex"] = $A["Duplex"];
                if ($A["LinkStatus"] != "") $Result["LinkStatus"] = $A["LinkStatus"];
      if ($A["TotalFECPacketsReceived"] != 0 || $A["TotalFECPacketsSent"] != 0) {
         //
         // FEC Is present. do it
         //
         $Result["Bytes Dynamically Corrected"] = $A["TotalFECBytesCorrected"];
         $Result["Dynamic Correction Packets Sent"] = $A["TotalFECPacketsSent"];
         $Result["Dynamic Correction Packets Received"] = $A["TotalFECPacketsReceived"];
      }

      foreach($A["Connections"] as $instance) {
         $Result["Connection [" . $instance["DisplayName"] . "]"] = "<a href=\"./connection_info.php?InstanceNumber=" . $instance["InstanceNumber"] . "\"> More Info <img src=\"./images/icon-info.gif\" border=\"0\" alt=\"Click Here For Detailed Connection Information\"> </a>";
      }
      foreach($A["Flows"] as $instance) {
         $Result["Flow [" . $instance["DisplayName"] . "]"] = "<a href=\"./flow_info.php?InstanceNumber=" . $instance["InstanceNumber"] . "\"> More Info <img src=\"./images/icon-info.gif\" border=\"0\" alt=\"Click Here For Detailed Flow Information\"> </a>";
      }
      return $Result;
   }



   //
   // Dump a hierachial structure in a more readable format
   //
   function var_dumper($in, $return = 0)
   {
      $type = gettype($in);
      ob_start();
      var_dump($in);
      $in = ob_get_contents();
      ob_end_clean();

      if($type == 'array')
      {

         // Split into an array
         $in = explode("\n", $in);
         // Do the br'in
         $x = 0;
         foreach($in as $value)
         {
            if($x%2 == 0)
            {
               $in[$x] .= "\n";
            }$x++;
         }

         // Put it back together
         $ins = NULL;
         foreach($in as $value) {
         $ins .= $value; }
         if($return == 1)
         {
            return '<tt>' . $ins . '</tt>';
         }
         else
         { echo '<tt>' . $ins . '</tt>'; }
      }
      else
      {
         if($return == 1)
         {
            return '<tt>' . $in . '</tt>';
         }
         else
         {
            echo '<tt>' . $in . '</tt>';
         }
      }
   } //var_dumper()

   function NumberOfOutstandingAlerts($System=RPC_SERVER) {
      return GetSystemParam("AlertCount", $System);
   }

   ////////////////////////////////////////////////////////
   //
   // The following functions are used for graphing system/connection/... thoughput
   //
   ////////////////////////////////////////////////////////

   function BandwidthAxisFormatter($AxisVal)
   {
      if ($AxisVal >= (1000*1000*1000) )
      {
         $AxisVal = $AxisVal / (1000*1000*1000);
         $AxisVal = $AxisVal . " Gbps";
      }
      else if ($AxisVal >= (1000*1000) )
      {
         $AxisVal = $AxisVal / (1000*1000);
         $AxisVal = $AxisVal . " Mbps";
      }
      else if ($AxisVal >= 1000)
      {
         $AxisVal = $AxisVal/1000;
         $AxisVal = $AxisVal . " Kbps";
      }
      return $AxisVal;
   }

   function PercentAxisFormatter($AxisVal){
      return $AxisVal . "%";
   }

   // Graph data colors
   define('COLOR_WIRE_BYTES', "dodgerblue4:1.5");
   define('COLOR_PAYLOAD_BYTES', "dodgerblue4");
   define('COLOR_PASS_BYTES', "red");
   define('COLOR_BAD_BITS', "green");

   //
   // Combines two arrays. NOTE: arrays must be the same or the result will be truncated
   // to the size of the smaller array.
   //
   function AddArrays($Array1, $Array2){
      for ($Count=0; $Count < min( sizeof($Array1), sizeof($Array2)); $Count++){
         $Array1[$Count] = $Array1[$Count] + $Array2[$Count];
      }
      return $Array1;
   }
   function SubtractArrays($Array1, $Array2){
      for ($Count=0; $Count < min( sizeof($Array1), sizeof($Array2)); $Count++){
         $Array1[$Count] = $Array1[$Count] - $Array2[$Count];
      }
      return $Array1;
   }
   function MultiplyArrays($Array1, $Array2){
      for ($Count=0; $Count < min( sizeof($Array1), sizeof($Array2)); $Count++){
         $Array1[$Count] = $Array1[$Count] * $Array2[$Count];
      }
      return $Array1;
   }
   function DivideArrays($Array1, $Array2){
      for ($Count=0; $Count < min( sizeof($Array1), sizeof($Array2)); $Count++){
         $Denom = $Array2[$Count];
         if ($Denom == 0) $Denom = 1;
         $Array1[$Count] = $Array1[$Count] / $Denom;
      }
      return $Array1;
   }
   function MinArrays($Array1, $Array2){
      for ($Count=0; $Count < min( sizeof($Array1), sizeof($Array2)); $Count++){
         $Array1[$Count] = min($Array1[$Count],$Array2[$Count]);
      }
      return $Array1;
   }
   function MaxArrays($Array1, $Array2){
      for ($Count=0; $Count < min( sizeof($Array1), sizeof($Array2)); $Count++){
         $Array1[$Count] = max($Array1[$Count],$Array2[$Count]);
      }
      return $Array1;
   }


   function DisplayArrow($LinkPage, $Direction, $LinkRecord){
      if ($Direction == "back"){
         return "<A href='$LinkPage?RecordNumber=$LinkRecord'><img src='./images/left-arrow.png' border=0></A>";
      }else{
         return "<A href='$LinkPage?RecordNumber=$LinkRecord'><img src='./images/right-arrow.png' border=0></A>";
      }
   }

   DEFINE('RESOLUTION_ONE_MINUTE', "LastMinute");
   DEFINE('RESOLUTION_ONE_HOUR',   "LastHour");
   DEFINE('RESOLUTION_ONE_DAY',    "LastDay");

   DEFINE('YAXIS_FORMAT_NO_LABEL',  1);
   DEFINE('YAXIS_FORMAT_BPS',       2);
   DEFINE('YAXIS_FORMAT_PERCENT',   3);

   DEFINE('BITS_IN_BYTE',           8);
   DEFINE('GRAPH_SCALE_NONE',       0);
   DEFINE('GRAPH_START_TIME_NOW',  -1); 
   DEFINE('NO_MAX_LINE',            0);


   function GraphPerfCounters($Title, $Counters, $Labels, $Colors,
                              $DataMult = 1, $Scale = 0, $StartTime = -1, $MaxLine=0,
                              $TimeResolution=RESOLUTION_ONE_MINUTE, $YAxisFormat = YAXIS_FORMAT_BPS,
                              $LineStyles = NULL)
   {
      $GRAPH_WIDTH  = 600;
      $GRAPH_HEIGHT = 300;
      $XAxisLabels = array();
      $LabelNum = 0;
      $MaxYVal  = 0;

      for ($c=0; $c < sizeof($Counters); $c++)
      {
         $ReversedCounter = array();
         if ($DataMult != 0)
         {
            $Counter = &$Counters[$c];
            for ($i=0; $i < (PERF_GRAPH_DATAPOINTS - sizeof($Counter)); $i++)
            {
               $ReversedCounter[$i] = 0;
            }
            for ($i=0; $i < sizeof($Counter); $i++)
            {
               $Value = $Counter[sizeof($Counter) - $i - 1] * $DataMult;
               $MaxYVal = max($Value, $MaxYVal);
               array_push($ReversedCounter, $Value);
            }
         }
         $Counters[$c] = $ReversedCounter;

      }

      if ($TimeResolution == RESOLUTION_ONE_DAY) {
         $TimeAxisMulti  = 12*24;
         $TimeAxisLabel  = "Time (hours)";
         $TimeAxisFormat = "%H:%M:";
         if ($StartTime == -1) { $StartTime = time() - 60 * $TimeAxisMulti * 5;}
      }
      else if ($TimeResolution == RESOLUTION_ONE_HOUR){
         $TimeAxisMulti = 60;
         $TimeAxisLabel = "Time (minutes)";
         $TimeAxisFormat = ":%M:";
         if ($StartTime == -1) { $StartTime = time() - 60 * $TimeAxisMulti;}
      }
      else {
         $TimeAxisMulti = 1;
         $TimeAxisLabel = "Time (seconds)";
         $TimeAxisFormat = ":%S";
         if ($StartTime == -1) { $StartTime = time() - 60 * $TimeAxisMulti;}
      }


      for ($c=0; $c<sizeof($ReversedCounter); $c++)
      {
         if ($StartTime == 0){  array_push($XAxisLabels, $c-sizeof($ReversedCounter)); }
         if ($StartTime != 0)
         {
            if ($c==0) {array_push($XAxisLabels, strftime ("%H:%M:%S", $StartTime + $c * $TimeAxisMulti)); }
            else {array_push($XAxisLabels, strftime ($TimeAxisFormat,  $StartTime + $c * $TimeAxisMulti)); }
         }
      }

      // Create the graph. These two calls are always required
      $Graph = &new Graph($GRAPH_WIDTH, $GRAPH_HEIGHT, "auto");

      if ($Scale==0) { $Scale = $MaxYVal * 1.1; }

      $Graph->SetScale("linlin", 0, $Scale, 0, sizeof($Counters[0])-1);
      $Graph->img->SetMargin(65,20,20,40);

      $Graph->title->SetFont(FF_FONT2, FS_BOLD);
      $Graph->title->Set($Title);

      $Graph->xaxis->title->Set($TimeAxisLabel);
      $Graph->xaxis->title->SetFont(FF_FONT2, FS_BOLD);
      $Graph->xaxis->SetTickLabels($XAxisLabels);

      $Graph->yaxis->title->Set("");
      $Graph->yaxis->title->SetFont(FF_FONT2, FS_BOLD);
      $Graph->yaxis->SetTitleMargin(60);
      $Graph->legend->SetPos(.65, .10);

      $Graph->SetFrame(true, "black", 1);
      $Graph->SetMarginColor("#cccccc");

      //
      // Set the Y-Axis labeling
      //
      switch ($YAxisFormat){
      case YAXIS_FORMAT_BPS:
         $Graph->yaxis->SetLabelFormatCallback('BandwidthAxisFormatter');
         break;
      case YAXIS_FORMAT_PERCENT:
         $Graph->yaxis->SetLabelFormatCallback('PercentAxisFormatter');
         break;
      case YAXIS_FORMAT_NO_LABEL:
         // Don't set the label callback
         break;
      }


      $Graph->xaxis->SetTextLabelInterval(2);

      #
      # Draw a line across the plot. Most commonly used to indicate the max bandwidth
      #
      if ($MaxLine){
         $band = new PlotBand(HORIZONTAL, BAND_SOLID, $MaxLine * .99, $MaxLine * 1, 'black');
         $band->ShowFrame(false);
         $band->SetOrder(DEPTH_FRONT);
         $Graph->AddBand($band);
      }

      // Iterate through each of the plot datasets
      $StyleSizes = $LineStyles != NULL ? sizeof($LineStyles) : 0;
      for ($c=0; $c < sizeof($Counters); $c++)
      {
         $Plot = &new LinePlot( $Counters[$c] );
         $Plot->SetColor($Colors[$c]);
         if ($c < $StyleSizes && $LineStyles[$c]) {
            $Plot->SetWeight(2);
         } else {
         $Plot->SetFillColor($Colors[$c]);
         }
         $Graph->Add($Plot);

         // For some reason now we have to kill the Plot object
         unset($Plot);
      }

      // Display the graph
      $ImageName      = str_replace(" ", "", $Title);
      $OutputFilename = OD_TEMP_DIR . $ImageName . ".png";
      $Graph->Stroke($OutputFilename);

      AddGraphToInplaceUpdateList($OutputFilename);

      return $OutputFilename;
   } // GraphPerfCounters()

   function AddThroughputLegend($PrevRecord=-1, $NextRecord=-1, $PrevPage="log_record.php", $NextPage="log_record.php"){
      $Output = "<TABLE class=no_bg_color width=600 height=50><TR>";
         $Output .= "<TD width=43>";
         if ($PrevRecord > 0){
            $Output .= "<A href='./$PrevPage?RecordNumber=$PrevRecord'><IMG border=0 src='./images/left-arrow.png'></A>";
         }
         $Output .= "</TD>";
         $Output .= "<TD><IMG src='./images/graph_legend.png'></TD>";
         $Output .= "<TD width=43>";
         if ($NextRecord > 0){
            $Output .= "<A href='./$NextPage?RecordNumber=$NextRecord'><IMG border=0 src='./images/right-arrow.png'></A>";
         }
      $Output .= "</TR></TABLE>";
      return $Output;
   }

   //
   // This block handle the dynamic creation of the javascript for doing
   // in place refreshing of the graphing objects
   //
   $GraphObjectsForThisPage = array();
   
   function AddGraphToInplaceUpdateList($GraphName){
      global $GraphObjectsForThisPage;
      array_push( $GraphObjectsForThisPage, $GraphName );
   }
   
   function GenerateInplaceUpdateJavascript($RefreshOn, $RefreshInterval){
      if (!$RefreshOn){return;}
      
      global $GraphObjectsForThisPage;
      $ScriptName = $_SERVER["SCRIPT_NAME"];
      $RefreshInterval = ($RefreshInterval*1000);
      
      echo "<img src='.' height='1' width='1' name='redrawimage'>";
      echo "<script type='text/javascript'>\n";
      echo "    function refreshGraphImages() {\n";
      //echo "alert('taco');";
      echo "       document.images['redrawimage'].src = '$ScriptName?variable='+Math.random();\n";
      echo "       setTimeout('refreshGraphImages()', $RefreshInterval);\n";
      
      foreach ($GraphObjectsForThisPage as $GraphName){
      echo "       document.images['$GraphName'].src    = '$GraphName?variable='+Math.random();\n";
      }
      echo "    }\n";
      echo "   setTimeout('refreshGraphImages()', $RefreshInterval);\n";
      echo "</script>\n";
   }

   function GetCounterByTimescale($Counter, $Timescale){      
	   if ($Timescale == "LastDay" && isset($Counter["LastDay"]) ){
		   return $Counter["LastDay"]["Rate"];
	   } elseif ($Timescale == "LastHour"  && isset($Counter["LastHour"]) ){
		   return $Counter["LastHour"]["Rate"];
	   } else{
		   return $Counter["Rate"];
      }
   }

   //
   // Generate all the main performance graphs
   //
   class PERF_GRAPHER{
      var $ShowSlowSide     = true;
      var $ShowFastSide     = false;
      var $Autoscale        = true;
      var $StartTime        = -1;
      var $CombineSendRecv  = true;
      var $IsResizeable     = false;
      var $DisplayLegend    = true;
      var $Data             = "SYSTEM";
      var $InstanceNumber   = -1;
      var $PrevRecord       = -1;
      var $NextRecord       = -1;
      var $MaxSendRate      = 0;
      var $GraphAckProgress = false;
      var $GraphTimescale   = "LastMinute"; // or "LastHour" or "LastDay"

      function PERF_GRAPHER(){
         $Response = GetParameters(array("UI.Graph.ShowWANGraph",
                                         "UI.Graph.ShowLANGraph",
                                         "UI.Graph.CombineSndRecvGraph",
                                         "UI.Graph.AutoScale"));

         $this->ShowSlowSide    = $Response["UI.Graph.ShowWANGraph"]["XML"];
         $this->ShowFastSide    = $Response["UI.Graph.ShowLANGraph"]["XML"];
         $this->CombineSendRecv = $Response["UI.Graph.CombineSndRecvGraph"]["XML"];
         $this->Autoscale       = $Response["UI.Graph.AutoScale"]["XML"];
      }

      function LoadData($Data, $InstanceNum=-1){
         $this->Data = $Data;
         $this->InstanceNumber = $InstanceNum;
      }

      //
      // $Data can be either equal to a set of perf counters to graph, or
      // a type such as SYSTEM, ADAPTER, etc
      //
      function Render()
{
	$Output = "";
	if (is_string($this->Data)){
		
		$PerfCounterList = array(  "SlowBytesTransmitted",
			"SlowBytesReceived",
			"FastBytesTransmitted",
			"FastBytesReceived",
			
			"PassthroughBytes",
			"PassthroughBytesSent",
			"PassthroughBytesReceived",
			"StatusLogRecord");
		if (!$this->GraphAckProgress){
			array_push($PerfCounterList, "SlowPayloadReceivedGood");
			array_push($PerfCounterList, "SlowPayloadTransmittedGood");
			array_push($PerfCounterList, "FastPayloadTransmittedGood");
			array_push($PerfCounterList, "FastPayloadReceivedGood");
		}else{
			array_push($PerfCounterList, "SlowProgressReceived");
			array_push($PerfCounterList, "SlowProgressTransmitted");
			array_push($PerfCounterList, "FastProgressTransmitted");
			array_push($PerfCounterList, "FastProgressReceived");
		}
		
		$Result = OrbitalGet( $this->Data, $PerfCounterList, (int)$this->InstanceNumber );
		
		if ($this->GraphAckProgress){
			array_key_rename($Result, "SlowProgressReceived",       "SlowPayloadReceivedGood");
			array_key_rename($Result, "SlowProgressTransmitted",    "SlowPayloadTransmittedGood");
			array_key_rename($Result, "FastProgressTransmitted",    "FastPayloadTransmittedGood");
			array_key_rename($Result, "FastProgressReceived",       "FastPayloadReceivedGood");
		}
		
		if (isset( $Result["StatusLogRecord"])) { $this->PrevRecord = $Result["StatusLogRecord"]; }
	}else{
		
		$Result = $this->Data;
	}
	
	$Output .= "<TABLE class=no_bg_color>\n";
	$Output .=  "<TR><TD>\n";
	if ($this->DisplayLegend) { $Output .= AddThroughputLegend($this->PrevRecord, $this->NextRecord); }
	$Output .= "</TD></TR>\n";
	$Output .= "<TR><TD>\n";
	
	if (IsFault($Result)){
		ThrowException("Couldn't find graph data!", true);
	}
	
	$this->MaxSendRate = GetMaxSendRate();
	$Scale = $this->Autoscale ? 0 : ($this->MaxSendRate) * 1.25;
	
	// Autoscale cause problems with the max rate bar, don't show it if we are doing autoscaling
	if ($this->Autoscale) { $MaxRateBar = 0;} else {$MaxRateBar = $this->MaxSendRate;}

   if      ($this->GraphTimescale == "LastDay")   { $GraphTitleScaleText = " (Last Day)";}
   elseif  ($this->GraphTimescale == "LastHour")  { $GraphTitleScaleText = " (Last Hour)";}
   elseif  ($this->GraphTimescale == "LastMinute"){ $GraphTitleScaleText = " (Last Minute)";}
   else                                           { ThrowException("Invalid timescale pass in!");}	
	
	// Display the passthrough traffic. In some cases it gets broken out, if so combine it
	if (isset($Result["PassthroughBytes"]) && !IsFault($Result["PassthroughBytes"])){
		$PassBytes = GetCounterByTimescale($Result["PassthroughBytes"], $this->GraphTimescale);
	}else{
		$PBT = GetCounterByTimescale($Result["PassthroughBytesSent"], $this->GraphTimescale);
		$PBR = GetCounterByTimescale($Result["PassthroughBytesReceived"], $this->GraphTimescale);
		$PassBytes = AddArrays($PBT, $PBR); //array();
	}
		
	if ($this->ShowSlowSide){
			$SBT = GetCounterByTimescale($Result["SlowBytesTransmitted"], $this->GraphTimescale);
			$SPT = GetCounterByTimescale($Result["SlowPayloadTransmittedGood"], $this->GraphTimescale);
			$SBR = GetCounterByTimescale($Result["SlowBytesReceived"], $this->GraphTimescale);
			$SPR = GetCounterByTimescale($Result["SlowPayloadReceivedGood"], $this->GraphTimescale);

            if ($this->CombineSendRecv){
               $SB = AddArrays($SBT, $SBR);
               $SP = AddArrays($SPT, $SPR);
               if ($PassBytes != NULL){
                  $SB = AddArrays($PassBytes, $SB);
                  $SP = AddArrays($PassBytes, $SP);
               }

               $WanName = GraphPerfCounters("WAN Traffic" . $GraphTitleScaleText, array($SB, $SP, $PassBytes),
                                  array("WAN Wire Bytes", "WAN Payload Bytes", "Non-WANScaler Traffic"),
                                  array(COLOR_WIRE_BYTES, COLOR_PAYLOAD_BYTES, COLOR_PASS_BYTES),
                                  8, $Scale, $this->StartTime, $MaxRateBar, $this->GraphTimescale);
               $Output .= "<img src='$WanName?NoCache=" . time() . "' width=600 height=300 name=$WanName>";
               $Output .= "<BR><BR>\n";
            }else
            {
				$WanTransName = GraphPerfCounters("WAN Bytes Transmitted" . $GraphTitleScaleText, array($SBT, $SPT),
                                  array("WAN Bytes Transmitted", "WAN Payload Transmitted Good"),
				                      array(COLOR_WIRE_BYTES, COLOR_PAYLOAD_BYTES),
				                      8, $Scale, $this->StartTime, $MaxRateBar, $this->GraphTimescale);
                                  $Output .= "<img src='$WanTransName?NoCache=" . time() . "' width=600 height=300 name=$WanTransName>";
                                  $Output .=  "<BR><BR>\n";
               
               $WanRecvName = GraphPerfCounters("WAN Bytes Received" . $GraphTitleScaleText, array($SBR, $SPR),
                                  array("WAN Bytes Received","WAN Payload Received Good"),
                                  array(COLOR_WIRE_BYTES, COLOR_PAYLOAD_BYTES), 8,
                                  $Scale, $this->StartTime, $MaxRateBar, $this->GraphTimescale);
               $Output .= "<img src='$WanRecvName?NoCache=" . time() . "' width=600 height=300 name=$WanRecvName>";
               $Output .= "<BR><BR>\n";
            }
         }

         if ($this->ShowFastSide){
            $FBT = GetCounterByTimescale($Result["FastBytesTransmitted"], $this->GraphTimescale);
            $FPT = GetCounterByTimescale($Result["FastPayloadTransmittedGood"], $this->GraphTimescale);
            $FBR = GetCounterByTimescale($Result["FastBytesReceived"], $this->GraphTimescale);
            $FPR = GetCounterByTimescale($Result["FastPayloadReceivedGood"], $this->GraphTimescale);

            if ($this->CombineSendRecv){
               $FB = AddArrays($FBT, $FBR);
               $FP = AddArrays($FPT, $FPR);
               if ($PassBytes != NULL){
                  $FB = AddArrays($PassBytes, $FB);
                  $FP = AddArrays($PassBytes, $FP);
               }
               $LanName = GraphPerfCounters("LAN Traffic" . $GraphTitleScaleText, array($FB, $FP, $PassBytes),
                                   array("LAN Wire Bytes", "LAN Payload Bytes", "Non-WANScaler Traffic"),
                                   array(COLOR_WIRE_BYTES, COLOR_PAYLOAD_BYTES, COLOR_PASS_BYTES),
                                   8, $Scale, $this->StartTime, false, $this->GraphTimescale);
               $Output .= "<img src='$LanName?NoCache=" . time() . "' width=600 height=300 name=$LanName>";

            }else
            {
               $LanTransName = GraphPerfCounters("LAN Bytes Transmitted" . $GraphTitleScaleText, array($FBT, $FPT),
                                   array("LAN Bytes Transmitted", "LAN Payload Transmitted Good"),
                                   array(COLOR_WIRE_BYTES, COLOR_PAYLOAD_BYTES,), 8,
                                   $Scale, $this->StartTime, false, $this->GraphTimescale);
               $Output .= "<img src='$LanTransName?NoCache=" . time() . "' width=600 height=300 name=$LanTransName>";
               $Output .= "<BR><BR>\n";

               $LanRecvName = GraphPerfCounters("LAN Bytes Received" . $GraphTitleScaleText, array($FBR, $FPR),
                                   array("LAN Bytes Received", "LAN Payload Received Good"),
                                   array(COLOR_WIRE_BYTES, COLOR_PAYLOAD_BYTES,), 8,
                                   $Scale, $this->StartTime, false, $this->GraphTimescale);
               $Output .= "<img src='$LanRecvName?NoCache=" . time() . "' width=600 height=300 name=$LanRecvName>";
               $Output .= "<BR><BR>\n";
            }
         }

         if (!$this->CombineSendRecv){
            if ($PassBytes){
               $PassName = GraphPerfCounters("Non-Accelerated Traffic" . $GraphTitleScaleText, array($PassBytes),
                                  array(""),
                                  array(COLOR_PASS_BYTES), 8, $Scale, $this->StartTime, false, $this->GraphTimescale);
               $Output .= "<img src='$PassName?NoCache=" . time() . "' width=600 height=300 name=$PassName>";
               $Output .= "<BR><BR>\n";
            }
         }
         $Output .= "</TR></TD>\n";
         $Output .= "</TABLE>\n";

         return $Output;
      }/* Render() */

      function SetShowSlowSide($Val)     {$this->ShowSlowSide     = $Val;}
      function SetShowFastSide($Val)     {$this->ShowFastSide     = $Val;}
      function SetCombineSendRecv($Val)  {$this->CombineSendRecv  = $Val;}
      function SetStartTime($Val)        {$this->StartTime        = $Val;}
      function SetIsResizable($Val)      {$this->IsResizable      = $Val;}
      function SetDisplayLegend($Val)    {$this->DisplayLegend    = $Val;}
      function SetAutoscale($Val)        {$this->Autoscale        = $Val;}
      function SetNextRecord($Val)       {$this->NextRecord       = $Val;}
      function SetPrevRecord($Val)       {$this->PrevRecord       = $Val;}
      function SetGraphAckProgress($Val) {$this->GraphAckProgress = $Val;}
      function SetGraphTimescale($Val)   {$this->GraphTimescale   = $Val;}
   }/*PERF_GRAPHER*/


   function GraphPerfCountersLinkedHelper($Link,$Text,$LeftRight) {
      if ($Link == 0) {
         echo "<td> <img src=\"./images/no-arrow.png\" border=0> </a> </td>";
      } else {
         echo "<td> <b> <big> <a href=\"./log_record.php?RecordNumber=" .
            $Link .
            "\"> ".
            " <img src=\"./images/" . $LeftRight . "-arrow.png\" border=\"0\" alt=\"Click Here For More Information\"> </a> " .
            " </big> </b> </td>";
      }
   }

   function GraphPerfCountersLinked($Title, $Counters, $Labels, $Colors, $DataMult, $Scale,$PrevLink,$NextLink,$StartTime,$ShowNavButtons=true,$LineStyles = NULL)
   {
      if ($ShowNavButtons){
         echo "<table align=center class=no_bg_color> <tr>";
         GraphPerfCountersLinkedHelper($PrevLink,"Previous","left");
         echo "<td>";
      }
      $GraphName = GraphPerfCounters($Title, $Counters, $Labels, $Colors, $DataMult, $Scale,$StartTime,0,RESOLUTION_ONE_MINUTE,YAXIS_FORMAT_BPS,$LineStyles);
      echo "<img src='$GraphName?NoCache=" . time() . "' name=$GraphName>\n";
      
      if ($ShowNavButtons){
         echo "</td>";
         GraphPerfCountersLinkedHelper($NextLink,"Next","right");
         echo "</tr></table>\n";
      }
   }

   function MakeHelpFunction($Name,$Title,$Text) {
      return
      "<script>\n".
         "function $Name(){\n" .
         "var helpwindow = window.open(\"\",\"\",\"width=400,height=400,resizable=yes\");\n" .
         "helpwindow.document.writeln('<html><head><title>Help for $Title</title></head>'\n" .
         "+'<body bgcolor=white onLoad=\"self.focus()\">'\n + " .
         "'" . addslashes($Text) . "' +" .
         "'</body></html>')\n" .
         "}\n".
     "</script>";
   }

   function MakeHelpTag($Name,$Text="Help") {
      return "<a href='javascript:$Name()'>" . $Text . "</a> </td>";
   }

   function MakeHelp($Name,$Title,$Text,$Link="Help") {
      return
         MakeHelpFunction($Name,$Title,$Text) .
         MakeHelpTag($Name,$Link);
   }

   function isServerMatchVMIP()
   {
      $rel = false;
      if (isset($_SERVER['HTTP_REFERER'])){
         $Param["Class"] = "SYSTEM";
         $Param["Attribute"] = "HaParameters";
         $HaParameters = xu_rpc_http_concise(
                                             array(
                                                   'method' => "Get",
                                                   'args' => array($Param),
                                                   'host' => RPC_SERVER,
                                                   'uri'  => RPC_URI,
                                                   'port' => RPC_PORT
                                                   ));


         $HaVmip =  $HaParameters["HaParameters"]["Vmip"]["Dotted"];
         $http_host =  $_SERVER['HTTP_HOST'];
         if(strcmp($HaVmip, $http_host) == 0)
            $rel = true;
         else
            $rel = false;
      }
      return $rel;
   }

   function isSoftboost()
   {
      $SoftboostStatus = GetParameter("UI.Softboost");
      return $SoftboostStatus;
   }

   function value_not_null($value) {
      if (is_array($value)) {
         if (sizeof($value) > 0) {
            return true;
         } else {
            return false;
         }
      } else {
         if ( (is_string($value) || is_int($value)) && ($value != '') && ($value != 'NULL') && (strlen(trim($value)) > 0)) {
            return true;
         } else {
            return false;
         }
      }
   }
   function FormatCompressionRow($Title,$Value) {
      echo "<TR><TH> " . $Title . " </th><td> " . $Value . " </td></tr>";
   }
   function DoCompressionGraphs($S,$StartTime=-1) {
      if (GetLimit("Compression")) {
         echo "<br><TABLE class=settings_table>";
         FormatCompressionRow("Compressed connections",$S["CompressConnectionCount"]);
         FormatCompressionRow("Cumulative Transmitted Application Bytes",$S["CompressionClearTextBytes"]["Total"]);
         FormatCompressionRow("Cumulative Transmitted Compressed Bytes",$S["CompressionCipherTextBytes"]["Total"]);
         FormatCompressionRow("Cumulative Transmit Compression Ratio",FormatRatio($S["CompressionClearTextBytes"]["Total"],$S["CompressionCipherTextBytes"]["Total"]));
         FormatCompressionRow("Cumulative Received Application Bytes",$S["DecompressionClearTextBytes"]["Total"]);
         FormatCompressionRow("Cumulative Received Compressed Bytes",$S["DecompressionCipherTextBytes"]["Total"]);
         FormatCompressionRow("Cumulative Receive Compression Ratio",FormatRatio($S["DecompressionClearTextBytes"]["Total"],$S["DecompressionCipherTextBytes"]["Total"]));
         echo "</TABLE><br>";
         if ($S["CompressConnectionCount"] != 0) {
            echo "<br><br>";
            GraphCompressedUncompressed($S, false);
            echo "<BR><BR>";
         }
      }
   }
   
   //
   // Code for creating tabs within the UI and managing state
   //
   function CreateTabs($Tabname, $Headers){
      if (sizeof($Headers)==0  || sizeof($Headers) > 5) ThrowException("CreateTabs: must have more then 0 or less then 5 tabs!", true);
      
      $InternalTabnames = array("tab1", "tab2", "tab3", "tab4", "tab5");
      
      $SelectedTabID = 0;
      $TabPublicNames = array_keys($Headers);
      
      if ( isset($_GET["ChangeTab"])) {
         $SelectedTabID = array_search( $_GET["ChangeTab"], $InternalTabnames );
      }
      else if ( isset($_SESSION["LastSelectedTab" . $Tabname])){
         $SelectedTabID = array_search( $_SESSION["LastSelectedTab" . $Tabname], $InternalTabnames );
      }
               
      $SelectedTab           = $InternalTabnames[$SelectedTabID];
      $SelectedTabPublicName = $TabPublicNames[$SelectedTabID];
      echo "
         <body id='$SelectedTab'>
         <ul id='tabnav'>";
      $TabNum = 0;
      foreach ($Headers as $HeaderName=>$HeaderDesc)
      {
         $InternalTabname = $InternalTabnames[$TabNum];
         echo
            "<li class='$InternalTabname'><a href='?ChangeTab=$InternalTabname'>$HeaderDesc</a></li>";
         $TabNum ++;
      }
      echo "</ul>";
      
      if ( !isset( $_SESSION["LastSelectedTab" . $Tabname] ) ){ $_SESSION["LastSelectedTab"] = array(); }
      $_SESSION["LastSelectedTab" . $Tabname] = $SelectedTab;
      
      return $SelectedTabPublicName;
   }
   
   
//
// Copyright 2002-2006 Citrix Systems, Inc.
//
?>
