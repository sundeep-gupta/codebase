<?
//
// Standalone .php file that monitors systems
//

   error_reporting (E_ERROR | E_WARNING | E_PARSE | E_NOTICE);
   include_once ("includes/configure.php");
   include_once (HTTP_ROOT_DIR . "xmlrpcutils/utils.php");
   include_once (HTTP_ROOT_DIR . "includes/orbital_lib.php");
   include_once (HTTP_ROOT_DIR . "html_helper.php");

   function DisplayAlerts($System) {
      $Count = GetSystemParam("AlertCount", $System);
      if ($Count == 0) {
         return "&nbsp;&nbsp;&nbsp;";
      } else {
         return "<a href='//".$System."/alerts.php'> <font size=+1 color=red> " .$Count . "</font></a>";
      }
   }

   function FormatCompressionRatio($Clear,$Rewind,$Denom) {
      $TrueBytes = $Clear - $Rewind;
      if ($Denom == 0) {
         return " ";
      } else if ($TrueBytes < 0) {
         return "<font color=red> " . FormatRatio($TrueBytes,$Denom) . " </font>";
      } else {
         return FormatRatio($TrueBytes,$Denom);
      }
   }

   function RecentCompressionRatio($Info) {
      $Clear = array_sum($Info["CompressionClearTextBytes"]["Rate"]);
      $Rewind = array_sum($Info["CompressionRewindTextBytes"]["Rate"]);
      $Denom  = array_sum($Info["CompressionCipherTextBytes"]["Rate"]);
      return FormatCompressionRatio($Clear,$Rewind,$Denom);
   }



   $MonitorFile = HTTP_ROOT_DIR . "/temp/monitor_data";

   if (file_exists($MonitorFile)) {
      $d = file_get_contents($MonitorFile);
      $StoredData = unserialize($d);
   	  $Systems = $StoredData["Systems"];
   	  if (isset($StoredData["RefreshInterval"])) {
   	     $RefreshInterval = $StoredData["RefreshInterval"];
   	  } else {
   	     $RefreshInterval = 10;
   	  }
   } else {
      $Systems = array();
      $RefreshInterval = 10;
   }

   if (isset($_GET["Add"])) {
      array_push($Systems,$_GET["Add"]);
      HTML::InsertRedirect();
   }

   if (isset($_GET["Reset"])) {
      $Systems = array();
      HTML::InsertRedirect();
   }

   if (isset($_GET["Delete"])) {
      $ix = (int)$_GET["Delete"];
      unset($Systems[$ix]);
      $Systems=array_values($Systems);
      HTML::InsertRedirect();
   }

   if (isset($_GET["MoveUp"])) {
      $ix = (int)$_GET["MoveUp"];
      $Temp = $Systems[$ix-1];
      $Systems[$ix-1] = $Systems[$ix];
      $Systems[$ix] = $Temp;
      HTML::InsertRedirect();
   }

   if (isset($_GET["MoveDown"])) {
      $ix = (int)$_GET["MoveDown"];
      $Temp = $Systems[$ix+1];
      $Systems[$ix+1] = $Systems[$ix];
      $Systems[$ix] = $Temp;
      HTML::InsertRedirect();
   }

   if (isset($_GET["RefreshInterval"])) {
      $RefreshInterval = (int)$_GET["RefreshInterval"];
      HTML::InsertRedirect();
   }

   $f = fopen($MonitorFile,"wb");
   if ($f) {
       $StoredData["Systems"] = $Systems;
       $StoredData["RefreshInterval"] = $RefreshInterval;
	   fwrite($f,serialize($StoredData));
	   fclose($f);
   } else {
      echo " <BR> ** Unable to write to '" . $MonitorFile . "', are the permissions on the directory correct? <br>";
   }

   function MakeHeader() {
      ?>
      	<TABLE>
      	<TR>
      	<TH> Delete </td>
      	<TH> Up     </td>
      	<TH> Down   </td>
      	<TH> System </TD>
      	<TH> Name   </td>
      	<TH> Version</td>
      	<TH> Alerts </td>
      	<TH> Uptime </td>
      	<TH> C Ratio</td>
         <TH> C Ratio[1M]</td>
         <TH> # Conns</TH>
         <TH> Cores </TH>
         <TH> Packets </TH>
      	<TH> Debug  </td>
      	<TH> Console </td>
      	</TR>
      <?
   }

   function MakeFooter() {
      echo " </TABLE>";
   }

   function Table($Systems,$index) {
      $System = $Systems[$index];
      $Info = OrbitalGet("SYSTEM",
         array("UpTime", "HostName","VersionCompact","CompressionClearTextBytes","CompressionCipherTextBytes","CompressionRewindTextBytes", "NumCoreFiles", "AvailablePackets"),
         -1, -1, $System,5);

      $Info["HostName"] = str_replace(".citrix.com","",$Info["HostName"]);


      $Param["Class"] = "NORB_CONNECTION";
      $Param["InstanceCount"] = 0;
      $Param["FirstInstance"] = 0;
      $Instances = xu_rpc_http_concise(
                     array(
                        'method' => "GetInstances",
                        'args'      => $Param,
                        'host'      => $System,
                        'uri'    => RPC_URI,
                        'port'      => RPC_PORT
                     ));
      $NumUnaccelConnections = $Instances["Count"];


      $Param["Class"] = "CONNECTION";
      $Param["InstanceCount"] = 0;
      $Param["FirstInstance"] = 0;
      $Instances = xu_rpc_http_concise(
                     array(
                        'method' => "GetInstances",
                        'args'      => $Param,
                        'host'      => $System,
                        'uri'    => RPC_URI,
                        'port'      => RPC_PORT
                     ));
      $NumAccelConnections = $Instances["Count"];

      ?>
       <TR>
       <TD>
          <form>
            <input type=submit value=Delete>
            <input type=hidden name=Delete value=<?=$index?> >
          </form>
       </td>
       <td>
          <? if ($index != 0) { ?>
			  <form>
				<input type=submit value="&uarr;">
				<input type=hidden name=MoveUp value=<?=$index?> >
			  </form>
          <? } ?>
       </td>
       <td>
          <? if ($index != sizeof($Systems)-1) { ?>
			  <form>
				<input type=submit value="&darr;">
				<input type=hidden name=MoveDown value=<?=$index?> >
			  </form>
          <? } ?>
       </td>
       <TD align=center> <a href='//<?=$System?>' > <?=$System?> </a></TD>
      <?
         if (!isset($Info["VersionCompact"])) {
            ?>
            <td colspan=9 align=center> <font color=red size=+1> Down </font> </td>
            <td align=center> <a href='//<?=$System?>/index_debug.php'> <img src="./images/icon-link.gif" border=0 alt="Info" title="Visit Debug Page"> </a></td>
            <td align=center> <a href='//<?=$System?>/console.php'> <img src="./images/icon-link.gif" border=0 alt="Info" title="Visit Console Page"> </a></td>
            <?
         } else {
			  ?>
			   <TD> <?=$Info["HostName"]?> </td>
			   <TD> <?=$Info["VersionCompact"]?> </td>
			   <TD align=center> <?=DisplayAlerts($System)?> </td>
            <td> <?=ToCompactPrintableTime($Info["UpTime"])?> </td>
			   <td align=center> <?=FormatCompressionRatio($Info["CompressionClearTextBytes"]["Total"],
								   $Info["CompressionRewindTextBytes"]["Total"],
								   $Info["CompressionCipherTextBytes"]["Total"])?>
				</td>
			   <td align=center> <?=RecentCompressionRatio($Info)?> </td>
            <td align=center> A:<?=$NumAccelConnections?>  U:<?=$NumUnaccelConnections?> </td>
            <td align=center>
               <? if (is_array($Info["NumCoreFiles"]))  echo "?";
                  else if ( $Info["NumCoreFiles"] == 0) echo "0";
                  else    echo "<font size=+1 color=red><A href='http://$System/debug.php'>" . $Info["NumCoreFiles"] . "</A></font>";
               ?> </td>

            <TD> <?=$Info["AvailablePackets"]?> </td>
            <td align=center> <a href='//<?=$System?>/index_debug.php'> <img src="./images/icon-link.gif" border=0 alt="Info" title="Visit Debug Page"> </a></td>
            <td align=center> <a href='//<?=$System?>/console.php'> <img src="./images/icon-link.gif" border=0 alt="Info" title="Visit Console Page"> </a></td>
			  <?
        }
      echo "</tr>";
   }
?>
<HTML>
<HEAD>
<TITLE>WANScaler System Monitor: <?=GetHostname()?></TITLE>
<META http-equiv="Pragma" content="no-cache">
<META http-equiv="Cache-control" content="no-cache">
<META http-equiv="Refresh" content="<?=$RefreshInterval?>; url=system_monitor.php">
<link rel=stylesheet type="text/css" href="./css/orbital.css">
<script type="text/javascript" src="includes/library.js"></script>
<script language="javascript" src="includes/form_validate.js"></script>
</HEAD>

<BODY bgcolor="#cccccc">
<H1 align=center> System status at <?=date("F j, Y, g:i a")?> </h1>
<?
   MakeHeader();
   for ($i = 0; $i < sizeof($Systems); $i = $i + 1) {
      Table($Systems,$i);
   }
   MakeFooter();
?>
   <br>
   <table> <tr>
   <form>
	  <input type=submit value="Add IP Entry">
	  <input type=text name=Add size=20>
   </form>
   <form>
	  <input type=submit name="Reset" value="Delete All IP Entries">
   </form>
   </tr> </table>
   <br>
   <form>
	  <input type=submit value="Set Refresh Interval">
	  <input type=text name=RefreshInterval value=<?=$RefreshInterval?> >
   </form>
</BODY>

