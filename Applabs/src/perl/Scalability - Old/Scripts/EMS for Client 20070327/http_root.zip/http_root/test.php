<?
   include ("includes/orbital_lib.php");   
?>

<HTML>
<HEAD>
<META http-equiv="Refresh" content="5;">
<link rel=stylesheet type="text/css" href="./css/orbital.css">
</HEAD>
</HTML>

<br><br>
<? 
$Data     	   = OrbitalGet("SYSTEM", array("SlowProgressTransmitted", "UnacceleratedConnections") );
$Bidirectional = true;

var_dump( $Data["AcceleratedConnections"]["Rate"] );


$SelectedTab = CreateTabs("CifsStatus", 
	array("LastDay" => "Last Day", 
		   "LastHour" => "Last Hour",
         "LastMinute" => "Last Minute")
	);

if ( $SelectedTab == "LastMinute"){    

   $LastMinOutGN = GraphPerfCounters("Last Minute " . ($Bidirectional ? "(Outbound)":""), array($Data["SlowProgressTransmitted"]["Rate"], $Data["SlowProgressTransmitted"]["Rate"]),
                                      array("Uncompressed Bytes Sent","Compressed Bytes Sent"),
                                      array(COLOR_PASS_BYTES, COLOR_PAYLOAD_BYTES), BITS_IN_BYTE, GRAPH_SCALE_NONE, GRAPH_START_TIME_NOW, NO_MAX_LINE, RESOLUTION_ONE_MINUTE);
            echo "<img src='$LastMinOutGN?NoCache=" . time() . "' name=$LastMinOutGN>";
            echo "<BR><BR>";

	$ActConnsGN = GraphPerfCounters("Active Connections", array($Data["UnacceleratedConnections"]["Rate"], $Data["UnacceleratedConnections"]["Rate"]),
		                              array("Uncompressed Bytes Sent","Compressed Bytes Sent"),
		                              array(COLOR_PASS_BYTES, COLOR_PAYLOAD_BYTES), 8, 0, -1, 0, RESOLUTION_ONE_MINUTE);
	echo "<img src='$ActConnsGN?NoCache=" . time() . "' name=$ActConnsGN>";
	echo "<BR><BR>";
	
}elseif ($SelectedTab == "LastHour"){

   $LastHourOutGN = GraphPerfCounters("Last Hour " . ($Bidirectional ? "(Outbound)":""), array($Data["SlowProgressTransmitted"]["LastHour"]["Rate"], $Data["SlowProgressTransmitted"]["LastHour"]["Rate"]),
                               array("Uncompressed Bytes Sent","Compressed Bytes Sent"),
                               array(COLOR_PASS_BYTES, COLOR_PAYLOAD_BYTES), BITS_IN_BYTE, 0, -1, 0, RESOLUTION_ONE_HOUR);
         echo "<img src='$LastHourOutGN?NoCache=" . time() . "' name=$LastHourOutGN>";
         echo "<BR><BR>";

}elseif ($SelectedTab == "LastDay"){

	$LastDayOutGN = GraphPerfCounters("Last Day " . ($Bidirectional ? "(Outbound)":""), array($Data["SlowProgressTransmitted"]["LastDay"]["Rate"], $Data["SlowProgressTransmitted"]["LastDay"]["Rate"]),
		array("Uncompressed Bytes Sent","Compressed Bytes Sent"),
		array(COLOR_PASS_BYTES, COLOR_PAYLOAD_BYTES), BITS_IN_BYTE, 0, -1, 0, RESOLUTION_ONE_DAY);
      echo "<img src='$LastDayOutGN?NoCache=" . time() . "' name=$LastDayOutGN>";
      echo "<BR><BR>";
}

var_dump( $Data["AcceleratedConnections"]["Rate"] );

?>