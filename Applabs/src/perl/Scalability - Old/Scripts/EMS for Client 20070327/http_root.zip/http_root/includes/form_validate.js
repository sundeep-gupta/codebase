// whitespace characters
var whitespace = " \t\n\r";

// Validate IP address
function IPAddressCheck(theControl, name)
{  
   if (theControl.value.length == 0)
      theControl.value = '0.0.0.0';           
   if (IPFormatCheck(theControl))
   {
      theControl.focus();
      theControl.select();    
      alert("Please specify the " + name + " in the format xxx.xxx.xxx.xxx,\nwith each field having a number in the range 0 to 255.");
      return 1;      
   }
   else
   {
      // The IP syntax is correct.
      return 0;
   }   
}

function IPFormatCheck(theControl)
{
   var error = 0;
   var tmp    = new Array('','','','');
   var pos    = 0;
   var i;
   var ch;
   
   for (i = 0; i < 4; i++)
   {
      ch = theControl.value.charAt(pos);
      while ((ch != '.') && (pos < theControl.value.length))
      {
         if (ch < '0' || ch > '9')
            error = 1;
         tmp[i] += ch;
         pos++;
         ch = theControl.value.charAt(pos);
      }
      if (tmp[i] == '')
         error = 1;

      while (tmp[i].length < 3)
      {
         tmp[i] = '0' + tmp[i];
      }
      if (tmp[i].length > 3)
         error = 1;
      if (tmp[i] < '000' || tmp[i] > '255')
         error = 1;
      pos++;
   }
   return error;
}

// Validate hostname
// Hostnames must be no longer than 64 characters in length. 
// You can use a-z,0-9, '-', '.', and '_'. A hostname cannot have any spaces nor 
// can it start with a '-'. 
function HostnameCheck(theControl, name)
{  
   var error = 0;
   var len = theControl.value.length;
   var ch;
   var pos    = 0;
   var dotCount = 0;
   
   if (len == 0 || len > 64)
   {      
      error = 1;      
   }
   else
   {      
      for(var i=0; i < len; i++)
      {
         ch = theControl.value.charAt(i); 
         if(!isLetterOrDigit(ch))
         {                       
            if(ch != '-' && ch != '_' && ch != '.')
            {   
               error = 1;   
               break;                
            }                               
         }         
      }      
   }
   
   if (error)
   {   
      if(len == 0)
         alert(name + " is empty.");
      else         
      if(len > 64)
         alert(name + " too big: 64 chars max.");
      else         
         alert(name + " is not valid: only alphanumeric, dash, period, or underbar");
      theControl.focus();
      theControl.select();
      return 1;
   }
   else
   {
      // The hostname syntax is correct.
      return 0;
   }      
}

// Returns true if all characters are numbers
function isNumber(value)
{
   if(value.length != 0)
   {
	   for (i = 0; i < value.length; i++)
	   {

	      if ( ! isDigit(value.charAt(i)))
	      {
	         return false;
	      }
	   }
	   return true;
   }
   else return false;
}

// Returns true if all characters are numbers and is in range
function isNumberInRange(value, begin, end)
{
   if (isNumber(value)) {
      intvalue = parseInt(value);
      if (intvalue >= begin && intvalue <= end) {
         return true;
      } else {
         return false;
      }
   } else {
      return false;
   }
}

// Returns true if all characters are numbers or .
function isFloatNumber(value)
{
   if(value.length != 0)
   {
	   for (i = 0; i < value.length; i++)
	   {

	      if ( ! isDigit(value.charAt(i)) && value.charAt(i) != '.')
	      {
	         return false;
	      }
	   }
	   return true;
   }
   else return false;
}


// Check whether string s is empty.
function isEmpty(s)
{  
   return ((s == null) || (s.length == 0))
}

// Returns true if string s is empty or
// whitespace characters only.

function isWhitespace(s)
{   
   var i;

   // Is s empty?
   if (isEmpty(s)) return true;
   
   // find a non-whitespace character
   for (i = 0; i < s.length; i++)
   {
      // Check that current character isn't whitespace.
      var c = s.charAt(i);
      if (whitespace.indexOf(c) == -1) return false;
   }
   // All characters are whitespace.
   return true;
}

function isLetter (c)
{  
   return ( ((c >= "a") && (c <= "z")) || ((c >= "A") && (c <= "Z")) )
}

// Returns true if character c is a digit
// (0 .. 9).
function isDigit (c)
{ 
   return ((c >= "0") && (c <= "9"))
}

// Returns true if character c is a letter or digit.
function isLetterOrDigit (c)
{
   return (isLetter(c) || isDigit(c))
}
