<?
   include("includes/header.php");
   $Auth->CheckRights(AUTH_LEVEL_VIEWER);

   if ( (isset($_GET["DisableNFS"])) || (isset($_GET["EnableNFS"]) ) )
   {
      $Auth->CheckRights(AUTH_LEVEL_ADMIN);

      if ( isset($_GET["DisableNFS"]) ) { SetParameter("RPC.PassThrough", true); }
      if ( isset($_GET["EnableNFS"] ) )  { SetParameter("RPC.PassThrough", false); }

      echo HTML::InsertRedirect("./nfs_config.php", 0);
   }
   $NfsEnabled = !GetParameter("RPC.PassThrough");
?>

<font class="pageheading">Configure Settings: NFS</font><BR><BR>
<TABLE class="settings_table" width="410">

   <!-- SYSTEM STATUS BLOCK -->
   <TR>
   <TH>
    NFS Acceleration:&nbsp;&nbsp;
   </TH>

   <TD>
         <FORM name="Enable" action="./nfs_config.php">

         <? if ($NfsEnabled)
            { ?>
               <FONT color="blue" size="+1">NORMAL</FONT>&nbsp;&nbsp;
               <INPUT type="submit" name="DisableNFS" value="Disable"></INPUT>
         <? }
            else
            {?>
               <FONT color="red" size="+1">DISABLED</FONT>&nbsp;&nbsp;
               <INPUT type="submit" name="EnableNFS" value="Enable">
         <? } ?>
         </FORM>

   </TD>
   </TR>
</TABLE>
<BR>
<BR>

<? include(HTTP_ROOT_INCLUDES_DIR . "footer.php"); ?>

