<?
   include("includes/header.php");
   $Auth->CheckRights(AUTH_LEVEL_VIEWER);
?>

      <script language="javascript">
      <!--//
      function show_popup_graph()
      {
         window.open("./popup_graph.php","_blank","toollbar=0,location=0,directories=0,status=0,menubar=0,scrollbars=no,resizable=yes,width=620,height=320");
      }  
      //-->
      </script>

<?
      //
      // Display Graph auto refresh toggle
      //
      $GraphRefreshRate = GetParameter("UI.Graph.RefreshRate");
      $AutoRefresh      = GetParameter("UI.Graph.AutoRefresh");

      if (isset($_GET["ToggleAutoRefresh"]))
      {
         $AutoRefresh = !$AutoRefresh;
         SetParameter("UI.Graph.AutoRefresh", $AutoRefresh);
      }


      $SelectedTimescaleTab = CreateTabs("ThroughputView", 
	      array("LastMinute" => "View Last Minute", 
		      "LastHour" => "View Last Hour",
		      "LastDay" => "View Last Day")
	      );
?>

   <br>
   <BODY>
      <div align="center">
         Auto-refresh <B><?=$AutoRefresh?"ON":"OFF"?></B>: <A href="./throughput.php?ToggleAutoRefresh">Toggle</A>
         
         &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<A href="javascript:show_popup_graph()" alt="foo">Popup Graph</a>

         &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
         <A href="./ui_configuration.php">Graph Settings</A>
      
      <BR>

   <!-- Display the throughput graph -->
   <?
      $Grapher = new PERF_GRAPHER();
      $Grapher->SetGraphAckProgress( GetParameter("UI.Graph.GraphSeqNumAdv") );
      $Grapher->SetGraphTimescale( $SelectedTimescaleTab );
      echo $Grapher->Render();
      GenerateInplaceUpdateJavascript($AutoRefresh, $GraphRefreshRate);
   ?>
   <img src="throughput.php" height="1" width="1" name="redrawimage">

<br>


<? include(HTTP_ROOT_INCLUDES_DIR . "footer.php"); ?>

</HTML>

<?
//
// Copyright 2002,2003 Orbital Data Corporation
//
?>
