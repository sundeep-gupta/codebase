<?
   include("includes/header.php");

   if (isset($_GET["InstanceNumber"]))
   {
      $InstanceNumber = (int)$_GET["InstanceNumber"];
   }
   else
   {
      ThrowException("Instance Number not specified on get request line.",true);
   }

   $Adapter = OrbitalGet("ADAPTER", "", $InstanceNumber);

   if (array_key_exists("Fault",$Adapter)) {
      ThrowException("Adapter Instance " . $InstanceNumber . " Not Found",true);
   }

   
?>

<font class="pageheading">Detailed Information For Adapter <?=$Adapter["DisplayName"]?></font><br><br>

<?
   $ThisAdapter = $Adapter["DeviceName"];

   $NonTrafficAdapter = GetNonTrafficAdapter();
   $found = 0;
   for ( $MyIndex=0; $MyIndex < sizeof($NonTrafficAdapter); $MyIndex++) { 
       if ( $ThisAdapter == $NonTrafficAdapter[ $MyIndex]) {
           $found = 1;
           break;
       }
   }

   $Grapher = new PERF_GRAPHER();
   $Grapher->LoadData("ADAPTER", (int)$_GET["InstanceNumber"]);

   if ( $found) {
      $Grapher->SetShowSlowSide(false);
	 //
         // Elimanate the legend 
	 // In the case of the any non-Traffic Adapter, it also puts an <== arrow to the left of the 
	 // legend, which is a href to "log_record.php", which is the wrong
	 // function for an adapter.  I think this somehow is related to
	 // partner adapater.
         //   setting $Grapher->PrevRecord = 0;
         //           $Grapher->NextRecord = 0;  doesn't solve this problem.
	 //
      // $Grapher->DisplayLegend = false;    Check with Craig
   }

   echo $Grapher->Render();

if (0) {
?>

<br><br> <h2> <center> Loss Statistics </center> </h2>
<?
   //
   // Show Loss Statistic
   //
   $LossPercent = array();
   for ($i=0;
        $i < sizeof($Adapter["PacketsTransmitted"]["Rate"]) -1;
        $i++)
   {
      if ($Adapter["PacketsTransmitted"]["Rate"][$i] > 0)
      {
         $LossPercent[$i] = ($Adapter["PacketsTransmitted"]["Rate"][$i] -
                             $Adapter["PacketsTransmittedGood"]["Rate"][$i])  /
                            $Adapter["PacketsTransmitted"]["Rate"][$i];
         $LossPercent[$i] = $LossPercent[$i] * 100;
      }
      else
      {
         $LossPercent[$i] = 0;
      }
   }

   $PerLossGN = GraphPerfCounters("Percent Loss",
                     array($LossPercent),
                     array("Percent Loss"),
                     array("darkgreen"));

   echo "<img src='$PerLossGN?NoCache=" . time() . "' name=$PerLossGN>";
}
?>


<?
   //
   // Show FEC Graph
   //
   if ($Adapter["TotalFECBytesCorrected"] != 0) {

      echo "<br> <h2> <center> FEC Statistics </center> </h2>";

      $WanCorrGN = GraphPerfCounters("WAN Correction",
                        array($Adapter["FECBytesCorrected"]["Rate"], $Adapter["PayloadReceivedGood"]["Rate"]),
                        array("Dynamically Corrected Bits","Goodput Bits"),
                        array("red:1.5", "red"), 8, 0);
      echo "<img src='$WanCorrGN?NoCache=" . time() . "' name=$WanCorrGN>";
   }
?>

   <CENTER>
   <BR>
   <TABLE class=settings_table>
<?
   $Info = AdapterInfo($Adapter,$InstanceNumber);
   // $i = 0;
   foreach ($Info as $Label => $Value)
   {
?>
         <TR class="row-1">
            <TH><?=$Label?></TH>
            <TD align=center><?=$Value?></TD>
         </TR>
<?
   }
?>
   </TABLE>
   </CENTER>
