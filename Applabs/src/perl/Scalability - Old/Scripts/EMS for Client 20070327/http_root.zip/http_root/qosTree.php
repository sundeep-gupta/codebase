
   <font class="pageheading">WAN Link Egress Traffic Class Hierarchy</font><BR><BR>

<!--
<TABLE cellspacing=0 cellpadding=1 border=0>
<TR><TD><BUTTON onclick='menuexpandall();'>Expand all</BUTTON></TD></TR>
</TABLE>
-->

<?php
   include ("service_lib.php");

   $serviceClassArray = getServiceClasses();
   $serviceClassArray = orderServiceClasses($serviceClassArray);

    require_once('HTML_TreeMenu-1.2.0/TreeMenu.php');


    $icon         = 'folder.gif';
    $expandedIcon = 'folder-expanded.gif';
    $leafIcon     = 'leaf.gif';

    $menu  = new HTML_TreeMenu();

    $node1   = new HTML_TreeNode(array('text' => "Accelerated TCP Traffic", 'link' => "qosAccelerated.php", 'icon' => $icon, 'expandedIcon' => $expandedIcon, 'leafIcon' => $leafIcon, 'aggregate' => true, 'expanded' => false), array('onclick' => "qos.php; return false", 'onexpand' => "qosAccelerated.php; return false", 'oncollapse' => "qos.php; return false"));
    $node1_1   = &$node1->addItem(new HTML_TreeNode(array('text' => "Queue A", 'link' => "qosAccelerated.php", 'icon' => $icon, 'expandedIcon' => $expandedIcon, 'leafIcon' => $leafIcon, 'aggregate' => true, 'expanded' => false), array('onclick' => "qosAccelerated.php; return false", 'onexpand' => "", 'oncollapse' => "qosAccelerated.php; return false")));

    for ($i=0;$i<count($serviceClassArray);$i++) {
      $serviceClass =&  $serviceClassArray[$i];
      if (getServiceID($serviceClass) > 100 && getServiceQueue($serviceClass) == "queueA" && getFlowControl($serviceClass))
         $node1_1_1 = &$node1_1->addItem(new HTML_TreeNode(array('text' => getServiceName($serviceClass), 'link' => "qosAccelerated.php", 'icon' => $icon, 'expandedIcon' => $expandedIcon, 'leafIcon' => $leafIcon, 'aggregate' => false)));
    }

    $node1_2   = &$node1->addItem(new HTML_TreeNode(array('text' => "Queue B", 'link' => "qosAccelerated.php", 'icon' => $icon, 'expandedIcon' => $expandedIcon, 'aggregate' => true, 'expanded' => false), array('onclick' => "qosAccelerated.php; return false")));
    for ($i=0;$i<count($serviceClassArray);$i++) {
      $serviceClass =&  $serviceClassArray[$i];
      if (getServiceID($serviceClass) > 100 && getServiceQueue($serviceClass) == "queueB" && getFlowControl($serviceClass))
         $node1_2_1 = &$node1_2->addItem(new HTML_TreeNode(array('text' => getServiceName($serviceClass), 'link' => "qosAccelerated.php", 'icon' => $icon, 'expandedIcon' => $expandedIcon, 'leafIcon' => $leafIcon, 'aggregate' => false)));
    }

    $node1_3   = &$node1->addItem(new HTML_TreeNode(array('text' => "Queue C", 'link' => "qosAccelerated.php", 'icon' => $icon, 'expandedIcon' => $expandedIcon, 'expanded' => false, 'aggregate' => true), array('onclick' => "qosAccelerated.php; return false", 'onexpand' => "")));
    for ($i=0;$i<count($serviceClassArray);$i++) {
      $serviceClass =&  $serviceClassArray[$i];
      if (getServiceID($serviceClass) != 2 && getServiceQueue($serviceClass) == "queueC" && getFlowControl($serviceClass))
         $node1_3_1 = &$node1_3->addItem(new HTML_TreeNode(array('text' => getServiceName($serviceClass), 'link' => "qosAccelerated.php", 'icon' => $icon, 'expandedIcon' => $expandedIcon, 'leafIcon' => $leafIcon, 'aggregate' => false)));
    }
    
    $node1_4   = &$node1->addItem(new HTML_TreeNode(array('text' => "Queue D", 'link' => "qosAccelerated.php", 'icon' => $icon, 'expandedIcon' => $expandedIcon, 'expanded' => false, 'aggregate' => true), array('onclick' => "qosAccelerated.php; return false", 'onexpand' => "")));
    for ($i=0;$i<count($serviceClassArray);$i++) {
      $serviceClass =&  $serviceClassArray[$i];
      if (getServiceID($serviceClass) > 100 && getServiceQueue($serviceClass) == "queueD" && getFlowControl($serviceClass))
         $node1_4_1 = &$node1_4->addItem(new HTML_TreeNode(array('text' => getServiceName($serviceClass), 'link' => "qosAccelerated.php", 'icon' => $icon, 'expandedIcon' => $expandedIcon, 'leafIcon' => $leafIcon, 'aggregate' => false)));
    }
    
    $node1_5   = &$node1->addItem(new HTML_TreeNode(array('text' => "Queue E", 'link' => "qosAccelerated.php", 'icon' => $icon, 'expandedIcon' => $expandedIcon, 'expanded' => false, 'aggregate' => true), array('onclick' => "qosAccelerated.php; return false", 'onexpand' => "")));
    for ($i=0;$i<count($serviceClassArray);$i++) {
      $serviceClass =&  $serviceClassArray[$i];
      if (getServiceID($serviceClass) > 100 && getServiceQueue($serviceClass) == "queueE" && getFlowControl($serviceClass))
         $node1_5_1 = &$node1_5->addItem(new HTML_TreeNode(array('text' => getServiceName($serviceClass), 'link' => "qosAccelerated.php", 'icon' => $icon, 'expandedIcon' => $expandedIcon, 'leafIcon' => $leafIcon, 'aggregate' => false)));
    }
    
    $node1_6   = &$node1->addItem(new HTML_TreeNode(array('text' => "Dynamic", 'link' => "qosAccelerated.php", 'icon' => $icon, 'expandedIcon' => $expandedIcon, 'expanded' => false, 'aggregate' => true), array('onclick' => "qosAccelerated.php; return false", 'onexpand' => "")));
    for ($i=0;$i<count($serviceClassArray);$i++) {
      $serviceClass =&  $serviceClassArray[$i];
      if (getServiceID($serviceClass) > 100 && getServiceQueue($serviceClass) == "dynamic" && getFlowControl($serviceClass))
         $node1_6_1 = &$node1_6->addItem(new HTML_TreeNode(array('text' => getServiceName($serviceClass), 'link' => "qosAccelerated.php", 'icon' => $icon, 'expandedIcon' => $expandedIcon, 'leafIcon' => $leafIcon, 'aggregate' => false)));
    }
    $menu->addItem($node1);
    
    $node2   = new HTML_TreeNode(array('text' => "Unaccelerated Traffic", 'link' => "qos.php", 'icon' => $icon, 'expandedIcon' => $expandedIcon, 'expanded' => false, 'aggregate' => true), array('onclick' => "qos.php; return false", 'onexpand' => ""));
    $node2_1   = &$node2->addItem(new HTML_TreeNode(array('text' => "TCP", 'link' => "qos.php", 'icon' => $icon, 'expandedIcon' => $expandedIcon, 'expanded' => false, 'aggregate' => true), array('onclick' => "qos.php; return false", 'onexpand' => "")));
    for ($i=0;$i<count($serviceClassArray);$i++) {
      $serviceClass =&  $serviceClassArray[$i];
      if (getServiceID($serviceClass) == 2 || !getFlowControl($serviceClass))
         $node2_1_1 = &$node2_1->addItem(new HTML_TreeNode(array('text' => getServiceName($serviceClass), 'link' => "qos.php", 'icon' => $icon, 'expandedIcon' => $expandedIcon, 'leafIcon' => $leafIcon, 'aggregate' => false)));
    }
    $node2_2   = &$node2->addItem(new HTML_TreeNode(array('text' => "Pass-Thru (UDP,...)", 'link' => "qos.php", 'icon' => $icon, 'expandedIcon' => $expandedIcon, 'expanded' => false, 'aggregate' => true), array('onclick' => "qos.php; return false", 'onexpand' => "")));
    $menu->addItem($node2);
    
    // Create the presentation class
    $treeMenu = &new HTML_TreeMenu_DHTML($menu, array('images' => 'HTML_TreeMenu-1.2.0/images', 'defaultClass' => 'treeMenuDefault'));
    $listBox  = &new HTML_TreeMenu_Listbox($menu, array('linkTarget' => '_self'));
?>
<html>
<head>
    <style type="text/css">
        body {
            font-family: Georgia;
            font-size: 11pt;
        }
        
        .treeMenuDefault {
            font-style: italic;
        }
        
        .treeMenuBold {
            font-style: italic;
            font-weight: bold;
        }
    </style>
    <script src="HTML_TreeMenu-1.2.0/TreeMenu.js" language="JavaScript" type="text/javascript"></script>
</head>
<body>

<script language="JavaScript" type="text/javascript">
<!--
    a = new Date();
    a = a.getTime();
//-->
</script>

<?$treeMenu->printMenu()?><br /><br />
<!--
<?$listBox->printMenu()?>
-->

<script language="JavaScript" type="text/javascript">
<!--
    b = new Date();
    b = b.getTime();
    
//-->
</script>


</body>
</html>
<!--
<? include(HTTP_ROOT_INCLUDES_DIR ."footer.php"); ?>
-->

