<?
   include("includes/header.php");
   include_once("includes/orbital_lib.php");
   $Auth->CheckRights(AUTH_LEVEL_VIEWER);

function GetAllSerializedNonDefaultParameters($System=RPC_SERVER)
{
    $Result = xu_rpc_http_concise(
                                  array(
                                        'method' => "SerializeAllNonDefaultParameters",
                                        'args'   => "",
                                        'host'   => $System,
                                        'uri'    => RPC_URI,
                                        'port'   => RPC_PORT
                                        )
                                  );

    $Settings = $Result["ParameterStream"];
   
    return $Settings;
}

?>

<?

   //$Parameters = OrbitalGet("PARAMETER");
   $Settings = GetAllSerializedNonDefaultParameters();
   $Parameters = explode("\r\n", $Settings);

   print("<H2><CENTER>System Parameters</CENTER></H2>\n");
   
   echo("<TABLE>");
   echo("<TR>");
      echo("<TH>Attribute</TH>");
      echo("<TH>Value</TH>");
   echo("</TR>");
   
   foreach ($Parameters as $param)
   {
      $param = trim($param);
      if (empty($param) || substr($param, 0, 1) == '#')
         continue;
      $pos = strpos($param, ' ');
      if ($pos === FALSE)
         continue;
      $Name = substr($param, 0, $pos);
      $Value = htmlspecialchars(substr($param, $pos + 1));
      echo("<TR class=\"row-1\">");
         echo("<TH align=left>" . $Name . "</TH>");
         echo("<TD align=left>" . $Value . "</TD>");
      echo("</TR>");
   }
   print("</TABLE>\n");

   $InstanceNumber = 1;
   $Adapters = OrbitalGet("ADAPTER");
   
   foreach($Adapters as $ix => $value) {
      $InstanceNumber = $value["InstanceNumber"];
      $DisplayName = $value["DisplayName"];

      $Info = AdapterInfo($value,$InstanceNumber);
      echo("<h2> Detailed Information For Adapter " . $DisplayName . "</h2>");
   
   
      echo("<TABLE class=\"width500\" >");
      echo("<TR align=center class=\"table_header\">");
         echo("<TD>Attribute</TD>");
         echo("<TD>Value</TD>");
      echo("</TR>");

   
      foreach ($Info as $Label => $Value)
      {
         echo("<TR class=\"row-1\">");
            echo("<TD align=center>" . $Label . "</TD>");
            echo("<TD align=center>" . $Value . "</TD>");
         echo("</TR>");
      }
      echo("</TABLE>");
   }
      ?>
