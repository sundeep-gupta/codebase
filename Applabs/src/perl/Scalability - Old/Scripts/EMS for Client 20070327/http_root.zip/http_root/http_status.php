<?
   include("includes/header.php");
   $Auth->CheckRights(AUTH_LEVEL_VIEWER);

      $GraphRefreshRate = GetParameter("UI.Graph.RefreshRate");
      $AutoRefresh      = GetParameter("UI.Graph.AutoRefresh");

      if (isset($_GET["ToggleAutoRefresh"]))
      {
         $AutoRefresh = !$AutoRefresh;
         SetParameter("UI.Graph.AutoRefresh", $AutoRefresh);
      }

      if ($AutoRefresh){
         echo HTML::InsertRedirect("", $GraphRefreshRate);
      }
 ?>
      <BR>
      <div align="center">
         Auto-refresh <B><?=$AutoRefresh?"ON":"OFF"?></B>: <A href="./cifs_status.php?ToggleAutoRefresh">Toggle</A>
      </div>
      <BR>

<?    /////////////////////////////////////////////////////////////////
      // Display the graphs page
      //////////////////////////////////////////////////////////////////               
      $S = OrbitalGet("SYSTEM",
   		   array("HttpWanBytes",
   			   "HttpProcessedCount",
   			   "HttpProcessedBytes",
   			   "HttpCacheHitCount",
   			   "HttpCacheHitBytes",
   			   "HttpCacheObjectCount",
   			   "HttpCacheObjectBytes"
   			   ));

      $WB = $S["HttpWanBytes"]["Rate"];
      $PC = $S["HttpProcessedCount"]["Rate"];
      $PB = $S["HttpProcessedBytes"]["Rate"];
      $HC = $S["HttpCacheHitCount"]["Rate"];
      $HB = $S["HttpCacheHitBytes"]["Rate"];
      
      $WanBytes = $S["HttpWanBytes"]["Total"];
      $ProcessedCount = $S["HttpProcessedCount"]["Total"];
      $ProcessedBytes = $S["HttpProcessedBytes"]["Total"];
      $CacheHitCount = $S["HttpCacheHitCount"]["Total"];
      $CacheHitBytes = $S["HttpCacheHitBytes"]["Total"];
      $CacheObjectCount = $S["HttpCacheObjectCount"];
      $CacheObjectBytes = $S["HttpCacheObjectBytes"];
?>

<font class="pageheading">HTTP Status</font><BR><BR>

<TABLE class=settings_table width="600">

   <!-- HTTP STATUS BLOCK -->
   <TR><TH>Bytes sent on WAN</TH><TD> <?=FormatBytes($WanBytes)?></TD></TR>
   <TR><TH>Number of HTTP requests handled</TH><TD> <?=$ProcessedCount?></TD></TR>
   <TR><TH>Bytes of HTTP requests handled</TH><TD> <?=FormatBytes($ProcessedBytes)?></TD></TR>
   <TR><TH>HTTP cache hit count</TH><TD> <?=$CacheHitCount?></TD></TR>
   <TR><TH>HTTP cache hit bytes</TH><TD> <?=FormatBytes($CacheHitBytes)?></TD></TR>
   <TR><TH>HTTP cache object count</TH><TD> <?=$CacheObjectCount?></TD></TR>
   <TR><TH>HTTP cache object bytes</TH><TD> <?=FormatBytes($CacheObjectBytes)?></TD></TR>

</TABLE>
<? include(HTTP_ROOT_INCLUDES_DIR . "footer.php"); ?>
