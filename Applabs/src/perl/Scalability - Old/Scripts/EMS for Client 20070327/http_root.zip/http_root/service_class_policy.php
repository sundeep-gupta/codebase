<?
	/***********************************************************************
	 * Include section
	 **********************************************************************/
	include("includes/header.php");
	include("service_lib.php");
	$Auth->CheckRights(AUTH_LEVEL_ADMIN);

	/***********************************************************************
	 * Parameter section
	 **********************************************************************/
	$action = (isset($HTTP_GET_VARS['action']) ? $HTTP_GET_VARS['action'] : '');
	$serviceID = (isset($HTTP_GET_VARS['serviceID']) ? $HTTP_GET_VARS['serviceID'] : '');
	$flowControl = (isset($HTTP_GET_VARS['flowControl']) ? $HTTP_GET_VARS['flowControl'] : '');
	$compression  = (isset($HTTP_GET_VARS['compression']) ? $HTTP_GET_VARS['compression'] : '');
	$serviceQueue  = (isset($HTTP_GET_VARS['serviceQueue']) ? $HTTP_GET_VARS['serviceQueue'] : '');
	$cifs = (isset($HTTP_GET_VARS['cifs']) ? $HTTP_GET_VARS['cifs'] : '');
	$serviceArray = (isset($HTTP_GET_VARS['serviceArray']) ? $HTTP_GET_VARS['serviceArray'] : '');

	$priorityArray  = (isset($HTTP_GET_VARS['priorityArray']) ? $HTTP_GET_VARS['priorityArray'] : '');
        $QueueName = GetParamAsStruct("AcceleratedTcpQueueName");

        /**********************************************************************
         *  Set up variables
         **********************************************************************/
        getQosNameArrays($IcaPriorityName, $InternalQueueName);

	/***********************************************************************
	 * Action section
	 **********************************************************************/
	if (value_not_null($action)) {
		switch ($action) {

			// Server Actions
			case 'setPolicy':
				$resp = setPolicy($serviceID, $flowControl, $compression, $serviceQueue);
				//echo '<br><br>Response: ';
				//var_dumper($resp);
				//echo '<br>';
				break;

			// UI Actions
			case 'moveUp':
				$resp = moveServiceClass($serviceID, "UP");
				//echo '<br>Move Up: ' . $serviceID;
				//echo '<br><br>Response: ';
				//var_dumper($resp);
				break;
			case 'moveDown':
				$resp = moveServiceClass($serviceID, "DOWN");
				//echo '<br>Move Down: ' . $serviceID;
				//echo '<br><br>Response: ';
				//var_dumper($resp);
				break;
			case 'applyChanges':
				//echo 'APPLY:' . $serviceArray;
				setPolicies($serviceArray);
				$resp2 = setServiceClassOrder($serviceArray);
				//echo '<br><br>Response: ';
				//var_dumper($resp);
			    break;
			case 'updateIcaPriorityMapping':
				$resp = setPriority2queueMapping($priorityArray);
			    break;
			default:
				break;
		}
	}

	/***********************************************************************
	 * Variables section
	 **********************************************************************/
	$serviceClassArray  = getServiceClasses();
	$error = false;
	$processed = false;

	$serviceClassArray  = orderServiceClasses($serviceClassArray);

	/***********************************************************************
	 * JavaScript section
	 **********************************************************************/
?>



<script type="text/javascript" src="./includes/library.js"></script>
<script type="text/javascript" src="serviceScript.js"></script>

<script language="javascript">
<!--


	function onSetPolicy(id, flowControl, compression, serviceQueue/*, cifs*/) {
		document.location = "./service_class_policy.php?serviceID=" + id;
		/*
		document.location = "./service_class_policy.php?serviceID=" + id + 
		                    "&flowControl=" + flowControl.checked +
		                    "&compression=" + compression.checked +
		                    "&cifs=" + "true"cifs.checked +
							"&action=setPolicy";
	*/
	}


	function onMoveUp(id) {
		//document.location = "./service_class_policy.php?serviceID=" + id + 
		//					"&action=moveUp";
		var table = getServiceTable();

	    // Find the current index
		var curIndex = selectedRowIndex(table);

		// Swap with above
		//DebugOut("start");
		//DebugOut(curIndex);
		if (curIndex > 1) {
			swapRow(table, curIndex-1, curIndex);
		}
		enableApplyCancel();
	}

	function onMoveDown(id) {
		//document.location = "./service_class_policy.php?serviceID=" + id + 
		//					"&action=moveDown";
		var table = getServiceTable();

	    // Find the current index
		var curIndex = selectedRowIndex(table);

		// Swap with above
		//DebugOut("start");
		//DebugOut(table.rows.length);
		if (curIndex < table.rows.length-3) {
			swapRow(table, curIndex, curIndex+1);
		}
		enableApplyCancel();
	}

	function onApply() {
		var serviceIDArray = "";
		var curID = "";
		var flowControlObjects = document.getElementsByName("flowControl");
		var selectObjects = document.getElementsByName("compression");
		var selectPriorityObjects = document.getElementsByName("serviceQueue");
	    for (var i=0; i<flowControlObjects.length; i++) {
			var curID = flowControlObjects[i].id;
			if (i == 0) {
				serviceIDArray = serviceIDArray + curID;
			} else {
				serviceIDArray = serviceIDArray + " " + curID;
			}
			serviceIDArray = serviceIDArray + "-" + flowControlObjects[i].checked + "-" + selectObjects[i].value + "-" + selectPriorityObjects[i].value;
		}
	    var serviceID = selectedRowServiceID();
		document.location = "./service_class_policy.php?serviceID=" + 
		                     serviceID + "&serviceArray=" + serviceIDArray + 
							"&action=applyChanges";
	}

	function onCancel() {
		document.location = "./service_class_policy.php";
	}


	function enableApplyCancel()
	{
	    var el = document.getElementsByName("policyApply");
		el[0].disabled = false;
	    var el = document.getElementsByName("policyCancel");
		el[0].disabled = false;
	}

	function disableMoveUpDown()
	{
	    var el = document.getElementsByName("policyMoveUp");
		el[0].disabled = true;
	    var el = document.getElementsByName("policyMoveDown");
		el[0].disabled = true;
	}

	function enableMoveUpDown()
	{
	    var el = document.getElementsByName("policyMoveUp");
		el[0].disabled = false;
	    var el = document.getElementsByName("policyMoveDown");
		el[0].disabled = false;
	}

	function enableUpdate()
	{
	    var el = document.getElementsByName("priorityMappingUpdate");
		el[0].disabled = false;
	}

        function onUpdate() {
           var priorityIdArray = "";
           var selectQueueObjects = document.getElementsByName("serviceGroup");
           for (var i=0; i<selectQueueObjects.length; i++) {
              if (i == 0) {
                 priorityIdArray += i;
              } else {
                 priorityIdArray += " " + i;
              }
              priorityIdArray += "-" + selectQueueObjects[i].value;
           }
           var priorityId = null;
           var priorityMappingTable = document.getElementById("icaPriorityMappingTable");
           // Find the current index
           var selectedIndex = selectedRowIndex(priorityMappingTable);
           var inputs = priorityMappingTable.rows[selectedIndex].getElementsByTagName("input");
           if (!inputs || !inputs[0])
              priorityId = null;
           else {
              var a = inputs[0].name.split("_");
              priorityId = a[1];
           }

           document.location = "./service_class_policy.php?priorityId=" + priorityId + "&priorityArray=" + priorityIdArray + "&action=updateIcaPriorityMapping";
              
        }


// Alistair Lattimore begins
window.onload = function() {
        if (document.getElementsByTagName) {
                var s = document.getElementsByTagName("select");

                if (s.length > 0) {
                        window.select_current = new Array();

                        for (var i=0, select; select = s[i]; i++) {
                                select.onfocus = function(){ window.select_current[this.id] = this.selectedIndex; }
                                select.onchange = function(){ restore(this); }
                                emulate(select);
                        }
                }
        }
}

function restore(e) {
        if (e.options[e.selectedIndex].disabled) {
                e.selectedIndex = window.select_current[e.id];
        }
}

function emulate(e) {
        for (var i=0, option; option = e.options[i]; i++) {
                if (option.disabled) {
                        option.style.color = "graytext";
                }
                else {
                        option.style.color = "menutext";
                }
        }
}
// Alistair Lattimore ends


//-->
</script>

    <!--*******************************************************************
     * Main HTML Block
     ********************************************************************-->
<TABLE cellspacing=0 cellpadding=0><TR><TD width=700/></TR></TABLE>
<form name="serviceClassPolicy">

<font class="pageheading">Configure Settings: Service Class Policy</font><BR><BR>

<table border="0" width=600 cellspacing="0" cellpadding="0">
  <tr>
    <td valign="top">
	  <table id="serviceTable" border="1" width="100%" cellspacing="0" cellpadding="2" rules="none">
	    <tr class="tableHeadingRow">
		  <td class="headingContent">Service Name</td>
		  <td class="headingContent" align="center">Flow Control</td>
		  <td class="headingContent" align="center">Compression</td>
		  <td class="headingContent" align="center">QoS Traffic class</td>
		  <!--<td class="headingContent" align="center">CIFS</td>-->
	    </tr>

<?
	$i = 0;
	if (isset($serviceClassArray)) foreach ($serviceClassArray as $serviceClassRec) {

		// only display classes that need it
		if (!getServiceDisplayable($serviceClassRec)) continue;
		$curID = getServiceID($serviceClassRec);
		if ($curID  == $serviceID) {
			$selServiceClassRec = $serviceClassRec;
			$trID = 'id="defaultSelected"';
			$trClass = 'dataTableRowSelected';
			$actionFragment = '&action=modifyUI';
			$tdClass = 'dataTableContentSelected';
		} else {
			$trClass = 'dataTableRow';
			if (($i % 2) == 0)  {
				$trID = '';
				$actionFragment = '';
				$tdClass = '"dataTableContentEvenRow"';
			} else {
				$trID = '';
				$actionFragment = '';
				$tdClass = '"dataTableContent"';
			}
		}
?>

	    <tr <?php echo $trID; ?>  class=<?php echo $trClass; ?> 
		    onmouseover="rowOverEffect(this)" 
		    onmouseout="rowOutEffect(this)" 
			onclick="selectRow(this)"
		    <?php /*echo "onclick=\"onSetPolicy(" . $curID . ", " .
			  "document.serviceClassPolicy.flowControl_" . $curID . ", " .
			  "document.serviceClassPolicy.compression_" . $curID . ", " .
			  "document.serviceClassPolicy.cifsBox" . $curID .
			  ")\" ";*/ ?>>
		  <td class=<?php echo $tdClass; ?>>
		    <?php echo getServiceName($serviceClassRec); ?>
		  </td>
		  <td class=<?php echo $tdClass; ?> align="center">
		    <input type=checkbox name=flowControl id=<?php echo $curID; ?>
			  <?php if (getFlowControl($serviceClassRec)) echo 'checked'; ?>
			       onclick="enableApplyCancel()"/>
		  </td>
		  <td class=<?php echo $tdClass; ?> align="center">
		    <select name=compression id=<?php echo $curID; ?> onclick="enableApplyCancel()">
          <? $CompressionType = getCompression($serviceClassRec);
             if ($DbcSupported) {
                echo '<option value="disk" ';
                if ($CompressionType == "disk") echo 'selected ';
                echo '>Disk</option>';
             }
             if ($CompressionSupported) {
                echo '<option value="memory" ';
                if ($CompressionType == "memory") echo 'selected ';
                echo '>Memory</option>';
             }
             echo '<option value="none" ';
             if ($CompressionType == "none") echo 'selected ';
             echo '>None</option>';
          ?>
		    </select>
		  </td>

		  <td class=<?php echo $tdClass; ?> align="center">
		    <select name=serviceQueue id=<?php echo $curID; ?> onclick="enableApplyCancel()">
          <?

             $Queue = getServiceQueue($serviceClassRec);
             if ($Queue == "dynamic") {
                echo '<option value="dynamic" ';
                if ($Queue == "dynamic") echo 'selected ';
                echo '>Dynamic</option>';
                // next, greyout menu is added to keep "Dynamic" drop-down have
                // equal width of other static menu when user modify queue name
                // to longer one.
                // html 4 "disabled option" works for FireFox, not IE 6,7
                // use optionDisabledSupport.js
                //$BrowserIE = strpos($_SERVER['HTTP_USER_AGENT'], "MSIE");
                //if ($BrowserIE == false) {
                   for ($j=0; $j<count($InternalQueueName)-1; $j++) {
                      echo '<option value="', $InternalQueueName[$j], '" ';
                      echo 'disabled>', $QueueName[$j], '</option>';
                   }
                //}
             } else {
                for ($j=0; $j<count($InternalQueueName)-1; $j++) {
                   echo '<option value="', $InternalQueueName[$j], '" ';
                   if ($Queue == $InternalQueueName[$j]) echo 'selected ';
                   echo '>', $QueueName[$j], '</option>';
                }
             }
          ?>
		    </select>
		  </td>
	    </tr>

<?
	    $i++;
	} // For statement - looping through rules
?>

         <tr>
           <td colspan="5">
		     <table border="0" width="100%" cellspacing="0" cellpadding="2">
               <tr>
                 <td align="right" class="smallText">
                   <INPUT type="button" name="policyMoveUp" value="Move Up" 
				          title=" Move Up " 
						  <?php if (!isset($selServiceClassRec) || !isUserDefinedClass($selServiceClassRec)) echo 'disabled'; ?>
						  <?php echo "onclick=\"onMoveUp(this)\""?> />
                   <INPUT type="button" name="policyMoveDown" value="Move Down"
				          title=" Move Down " 
						  <?php if (!isset($selServiceClassRec) || !isUserDefinedClass($selServiceClassRec)) echo 'disabled'; ?>
						  <?php echo "onclick=\"onMoveDown(" . $serviceID . ")\""?> />
                   <INPUT type="button" name="policyCancel" value="Cancel"
				          title=" Cancel " disabled
						  onclick="onCancel()"/>
                   <INPUT type="button" name="policyApply" value="Apply"
				          title=" Apply " disabled
						  onClick="onApply()"/>
                    
						  
           &nbsp;
                 </td>
               </tr>
	         </table>
	       </td>
	     </tr>

	  </table>
	</td>
  </tr>

</table>

<?
function setPriority2queueMapping($priorityArray)
{
   $queueList = array();
   $line = explode(' ', $priorityArray);
   foreach ($line as $token) {
      $fields = explode('-', $token);
      $priority = $fields[0];
      $queue = $fields[1];
      array_push($queueList, $queue);
   }
   SetParamAsStruct("IcaPriorityToServiceGroupQueueMapping", $queueList);
}
?>

<BR><BR>
<font class="pageheading">Dynamic Mapping of ICA Priority To QoS Traffic Class</font><BR><BR>
<table border="0" width=300 cellspacing="0" cellpadding="0">
  <tr>
    <td valign="top">
          <table id="icaPriorityMappingTable" border="1" width="100%" cellspacing="0" cellpadding="2" rules="none">
            <tr class="tableHeadingRow">
                  <td class="headingContent">ICA Priority</td>
                  <td class="headingContent" align="center">QoS Traffic Class</td>
            </tr>
<?
        $queueName = GetParamAsStruct("AcceleratedTcpQueueName");
        $queueArray = GetParameters("IcaPriorityToServiceGroupQueueMapping");
        $i = 0;
        if (isset($queueArray)) foreach ($queueArray["IcaPriorityToServiceGroupQueueMapping"]["XML"] as $QueueIdx) {
			$trClass = 'dataTableRow';
			$trID = '';
			if (($i % 2) == 0)  {
				$tdClass = '"dataTableContentEvenRow"';
			} else {
				$tdClass = '"dataTableContent"';
			}
?>
            <tr <?php echo $trID; ?>  class=<?php echo $trClass; ?>
                    onmouseover="rowOverEffect(this)"
                    onmouseout="rowOutEffect(this)"
                        onclick="selectRow(this)">

                  <td class=<?php echo $tdClass; ?>>
                    <?php echo $IcaPriorityName[$i]; ?>
                  </td>

                  <td class=<?php echo $tdClass; ?> align="center">
                    <select name=serviceGroup id=<?php echo $curID; ?> onclick="enableUpdate()">
          <?
                for ($j=0; $j<sizeof($queueName); $j++) {
                   // $j is also queue index
                   echo '<option value=', $j, ' ';
                   if ($QueueIdx == $j) echo 'selected ';
                   echo '>', $queueName[$j], '</option>';
                }
          ?>
                    </select>
                  </td>
            </tr>
<?
            $i++;
        } // For statement - looping through ICA priorities
?>
         <tr>
           <td colspan="5">
                     <table border="0" width="100%" cellspacing="0" cellpadding="2">
               <tr>
                 <td align="right" class="smallText">
                   <INPUT type="button" name="priorityMappingUpdate" value="Update"
                                          title=" Update " disabled
                                                  onClick="onUpdate()"/>
           &nbsp;
                 </td>
               </tr>
                 </table>
               </td>
             </tr>

          </table>
        </td>
  </tr>

</table>

</form>

<? include(HTTP_ROOT_INCLUDES_DIR . "footer.php"); ?>
