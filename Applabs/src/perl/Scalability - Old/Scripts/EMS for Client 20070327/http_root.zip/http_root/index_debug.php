<?
	include("includes/header.php");
   $Auth->CheckRights(AUTH_LEVEL_VIEWER);


   //
   // Display Graph auto refresh toggle
   //
   $GraphRefreshRate = GetParameter("UI.Graph.RefreshRate");
   $AutoRefresh      = GetParameter("UI.Graph.AutoRefresh");

   if (isset($_GET["ToggleAutoRefresh"]))
   {
      $AutoRefresh = !$AutoRefresh;
      SetParameter("UI.Graph.AutoRefresh", $AutoRefresh);
   }

?>
   <BODY>
   <div align="center">
	Auto-refresh <B><?=$AutoRefresh?"ON":"OFF"?></B>: <A href="./index_debug.php?AutoRefresh=<?=$AutoRefresh?0:$GraphRefreshRate?>">Toggle</A>

	<!-- DISPLAY THE CURRENT SYSTEM TIME -->
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	<B>Time: <?=strftime ("%b %d %Y %H:%M:%S")?></B>
	<BR><BR>


   <?
   $Grapher = new PERF_GRAPHER();
   echo $Grapher->Render();


   $Counters = OrbitalGet("SYSTEM",
         array("CompressionBigMatcherBytes",
   	           "CompressionDiskMatchBytes",
         	   "CompressionLZSBytes",
               "CompressionZLIBBytes",
               "CompressionRAWBytes",
               "DecompressionBigMatcherBytes",
    	       "DecompressionDiskMatchBytes",
			   "DecompressionLZSBytes",
               "DecompressionZLIBBytes",
               "DecompressionRAWBytes",
               "ChunkReads",
               "ChunkWrites",
               "SpindleWrites",
               "TraceWrites",
               "ReadBuffers",
               "WriteBuffers",
               "SpindleBuffers",
               "FreeBuffers",
               "CompressionWaitTime",
               "DecompressionWaitTime",
               "IoDistance",
         	   "CompressConnectionCount",
               "CompressionClearTextBytes",
               "CompressionCipherTextBytes",
               "DecompressionClearTextBytes",
               "DecompressionCipherTextBytes",
               "CompressionRewinds",
               "CompressionPrewinds",
               "DecompressionRewinds",
               "CompressionRewindTextBytes",
               "CompressionPrewindTextBytes",
               "CompressionDiskHashLookups",
               "CompressionDiskHashHits",
               "SlowPacketsReceived",
               "SlowBytesReceived",
               "SlowPacketsTransmitted",
               "SlowBytesTransmitted",
               "FastPacketsReceived",
               "FastBytesReceived",
               "FastPacketsTransmitted",
               "FastBytesTransmitted",
               "CompressionBootOuts",
               "CompressionDiskWriteBootOuts",
               "CompressionDiskReadBootOuts",
               "DecompressionDiskReadBootOuts",
               "DecompressionDiskWriteBootOuts",
   		       "MainCPUIdleTime",
   		       "MainCPUUsageTime",
   			   "FastWindowStops",
   			   "SlowWindowStops",
   			   "FastWindowZeros",
   			   "SlowWindowZeros",
   			   "FastRTOs",
   			   "SlowRTOs",
               "UnixTime",
               "CompressionBacklog",
               "IoFactor"
               ));

   $Spindle = OrbitalGet("SPINDLE");

   // Now 'stack' the data...
   $CDRE = $Counters["CompressionDiskMatchBytes"]["Rate"];
//   Set $CDRR to be the sum of $Counters["ChunkReads"]["Rate"] across all spindles.
   $CDRR = array_fill(0,60,0);
   for ($i = 0; $i < sizeof($Spindle); $i = $i + 1) {
      $ThisSpindle = &$Spindle[$i]["ChunkReads"]["Rate"];
      for ($j = 0; $j < sizeof($ThisSpindle); $j = $j + 1) {
         $CDRR[$j] = $CDRR[$j] + $ThisSpindle[$j];
      }
   }
  for ($i = 0; $i < sizeof($CDRE); $i = $i + 1) {
	 if ($CDRR[$i] != 0) {
		$CDRE[$i] = $CDRE[$i] / $CDRR[$i];
	 }
  }

   if (array_sum($CDRE) != 0) {
	   echo "<br>Legend (Disk Read Efficiency -- BytesMatched/Read) <BR>";
	   GraphPerfCountersLinked("Disk Read Efficiency",
			 array($CDRE),
			 array(""),
			 array("red"),1,0,0,0,$Counters["UnixTime"]);
	   echo "<br>";
   }

   $CDHL = $Counters["CompressionDiskHashLookups"]["Rate"];
   $CDHH = $Counters["CompressionDiskHashHits"]["Rate"];

   if (array_sum($CDHL) != 0) {
	   echo "<br>Legend (Disk Hash Table) -- Red: Lookups, Blue: Hits <BR>";
	   GraphPerfCountersLinked("Disk Hash Table Activity",
			 array($CDHL, $CDHH),
			 array("", ""),
			 array("red", "blue"),1,0,0,0,$Counters["UnixTime"]);
	   echo "<br>";
   }

   // Now 'stack' the data...
   $CDSK = $Counters["CompressionDiskMatchBytes"]["Rate"];
   $CBMB = AddArrays($CDSK, $Counters["CompressionBigMatcherBytes"]["Rate"]);
   $CZLB = AddArrays($CBMB, $Counters["CompressionZLIBBytes"]["Rate"]);
   $CLZS = AddArrays($CZLB, $Counters["CompressionLZSBytes"]["Rate"]);
   $CRAW = AddArrays($CLZS, $Counters["CompressionRAWBytes"]["Rate"]);

   if (array_sum($CRAW) != 0) {
      echo        "<br" .
                  "<center>" .
                  "<img src='images/compression_breakdown_legend.png'><br><br>" .
                  "</center>";
	   GraphPerfCountersLinked("Compression Breakdown",
          array($CRAW, $CLZS, $CZLB, $CBMB, $CDSK),
			 array("", "", "", ""),
			 array("red", "green", "green:0.5", "blue:0.5","blue:1.5"),8,0,0,0,$Counters["UnixTime"]);
	   echo "<br>";
   }

   // Now 'stack' the data...
   $DDSK = $Counters["DecompressionDiskMatchBytes"]["Rate"];
   $DBMB = AddArrays($DDSK, $Counters["DecompressionBigMatcherBytes"]["Rate"]);
   $DLZS = AddArrays($DDSK, $Counters["DecompressionLZSBytes"]["Rate"]);
   $DZLB = AddArrays($DLZS, $Counters["DecompressionZLIBBytes"]["Rate"]);
   $DRAW = AddArrays($DZLB, $Counters["DecompressionRAWBytes"]["Rate"]);

   if (array_sum($DRAW) != 0) {
      echo        "<br>" .
                  "<center>" .
                  "<img src='images/compression_breakdown_legend.png'><br><br>" .
                  "</center>";
	   GraphPerfCountersLinked("Decompression Breakdown",
			 array($DRAW, $DZLB, $DLZS, $DBMB, $DDSK),
			 array("", "", "", ""),
			 array("red", "green", "green:0.5", "blue:0.5","blue:1.5"),8,0,0,0,$Counters["UnixTime"]);
	   echo "<br>";
   }
   function ShowDisk($DeviceName,&$S,$Time,$IoF,$ShowOS) {
      $ShowQueueDepth = GetParameter("ui.Debug.ShowQueueDepth");
      $IoFactor = array_fill(0,60,$ShowOS ? $IoF : 1);
	  $DWRITES =                    MultiplyArrays($S["ChunkWrites"]["Rate"],  $IoFactor);
	  $DREADS  = AddArrays($DWRITES,MultiplyArrays($S["ChunkReads"]["Rate"],   $IoFactor));
	  $SWRITES = AddArrays($DREADS, MultiplyArrays($S["SpindleWrites"]["Rate"],$IoFactor));
	  $OREADS  = AddArrays($SWRITES,$S["OSReadCount"]["Rate"]);
	  $OWRITES = AddArrays($OREADS, $S["OSWriteCount"]["Rate"]);
     $SAMPL   = $ShowOS ? $OWRITES : $SWRITES;
      if (is_array($SAMPL) && array_sum($SAMPL) != 0) {
		 if ($ShowOS) {
			 echo "<br> Disk " . $DeviceName . " Red(Reads), Blue(Writes), Yellow(FS), Purple(OReads) Black(OWrites)<BR>";
			 GraphPerfCountersLinked("Disk Activity ".$DeviceName." Operations",
				array($OWRITES,$OREADS,$SWRITES,$DREADS,$DWRITES),
				array("",""),
				array("black","purple","yellow","red","blue"),1,0,0,0,$Time);

			 $DKWRITES = $S["ChunkWriteKBytes"]["Rate"];
			 $DKREADS  =  AddArrays($DKWRITES,$S["ChunkReadKBytes"]["Rate"]);
			 $SKWRITES =  AddArrays($DKREADS, $S["SpindleWriteKBytes"]["Rate"]);
			 //
			 // Remove our read / write traffic from the total read/write traffic
			 //
			 $TrueOReads = SubtractArrays($S["OSReadKBytes"]["Rate"],$S["ChunkReadKBytes"]["Rate"]);
			 $TrueOWrites = SubtractArrays($S["OSWriteKBytes"]["Rate"],$S["ChunkWriteKBytes"]["Rate"]);
			 $TrueOWrites = SubtractArrays($TrueOWrites,$S["SpindleWriteKBytes"]["Rate"]);
			 $OKREADS  =  AddArrays($SKWRITES,$TrueOReads);
			 $OKWRITES  = AddArrays($OKREADS, $TrueOWrites);
			 echo "<br> Disk Activity (KBytes) " . $DeviceName . " Read(Reads), Blue(Writes), Yellow(FS), Purple(OReads), Black(OWrites)<br>";
			 GraphPerfCountersLinked("Disk Activity ".$DeviceName." (KBytes Transferred)",
				array($OKWRITES,$OKREADS,$SKWRITES,$DKREADS,$DKWRITES),
				array("",""),
				array("black","purple","yellow","red","blue"),1,0,0,0,$Time);
		 } else {
			 echo "<br> Disk " . $DeviceName . " Red(Reads), Blue(Writes), Yellow(FS)<BR>";
			 GraphPerfCountersLinked("Disk Activity ".$DeviceName." MegaByte Io Operations",
				array($SWRITES,$DREADS,$DWRITES),
				array("",""),
				array("yellow","red","blue"),1,0,0,0,$Time);
			 //
			 // Non-standard stacking. We show the averages as a portion of the total....
			 //
			 $AverageReadIoTime = DivideArrays($S["ReadIoTime"]["Rate"],$S["ChunkReads"]["Rate"]);
			 $AverageWriteIoTime = DivideArrays($S["WriteIoTime"]["Rate"],AddArrays($S["ChunkWrites"]["Rate"],$S["SpindleWrites"]["Rate"]));
			 $AverageWriteIoTime = AddArrays($AverageWriteIoTime,$S["ReadIoTime"]["Rate"]);
			 $WriteIoTime = AddArrays($S["ReadIoTime"]["Rate"],$S["WriteIoTime"]["Rate"]);
			 echo "<br> I/O Time (MilliSeconds) Total Read: Red, Average: Lite Read Total Write: Blue Average: Lite Blue<br>";
			 GraphPerfCountersLinked("Disk Io Time ".$DeviceName." MilliSeconds",
			    array($WriteIoTime,$AverageWriteIoTime,$S["ReadIoTime"]["Rate"],$AverageReadIoTime),
			    array("",""),
			    array("blue","blue:1.5","red","red:1.5"),1,0,0,0,$Time);
		 }
		 if ($ShowQueueDepth) {
		    $DQWRITE = AddArrays($S["ReadQueueDepth"]["Rate"],$S["WriteQueueDepth"]["Rate"]);
		    echo "<br> Disk " . $DeviceName . " Queue Depth: Red: Read, Blue: Write<br>";
		    GraphPerfCountersLinked("Disk " . $DeviceName . " Queue Depth",
		       array($DQWRITE,$S["ReadQueueDepth"]["Rate"]),
		       array("",""),
		       array("blue","red"),1,0,0,0,$Time);
		 }
	  }
   }
   $ShowOS = GetParameter("UI.Debug.ShowOS");
   $ShowDisks = GetParameter("UI.Debug.ShowDisks");
   if (sizeof($Spindle) > 0) {
	   if ($ShowDisks) {
		   for ($i = 0; $i < sizeof($Spindle); $i = $i + 1) {
			  ShowDisk($Spindle[$i]["DeviceName"],$Spindle[$i],$Counters["UnixTime"],$Counters["IoFactor"],$ShowOS);
		   }
	   } else {
		  $Fields = array("ChunkWrites","ChunkReads","SpindleWrites","ChunkWriteKBytes","ChunkReadKBytes","SpindleWriteKBytes",
						  "OSReadCount","OSWriteCount","OSReadKBytes","OSWriteKBytes","ReadIoTime","WriteIoTime","ReadQueueDepth","WriteQueueDepth");
		  for ($i = 0; $i < sizeof($Fields); $i = $i + 1) {
			 $S[$Fields[$i]] = sizeof($Spindle) > 0 ? $Spindle[0][$Fields[$i]] : 0;
			 for ($j = 1; $j < sizeof($Spindle); $j = $j + 1) {
				$S[$Fields[$i]]["Rate"] = AddArrays($S[$Fields[$i]]["Rate"],$Spindle[$j][$Fields[$i]]["Rate"]);
			 }
		  }
		  ShowDisk("All",$S,$Counters["UnixTime"],$Counters["IoFactor"],$ShowOS);
	   }
   }
   if ((array_sum($Counters["CompressionWaitTime"]["Rate"]) + array_sum($Counters["DecompressionWaitTime"]["Rate"])) != 0) {
      $DCWAIT = $Counters["CompressionWaitTime"]["Rate"];
      $DDWAIT = AddArrays($DCWAIT,$Counters["DecompressionWaitTime"]["Rate"]);
      echo "<br> Connection Wait Time (MilliSec) Red:Compression Blue:Decompression<BR>";
      GraphPerfCountersLinked("Connection Wait Time (Stacked)",
            array($DDWAIT,$DCWAIT),
            array("",""),
            array("blue","red"),1,0,0,0,$Counters["UnixTime"]);
   }
   $Idle = $Counters["MainCPUIdleTime"]["Rate"];
   $CPU  = $Counters["MainCPUUsageTime"]["Rate"];


   /* Convert time to cpu utilized percent */
   $Timer = array();
   for ($i = 0; $i < sizeof($CPU); ++$i) {
      $CountersampTime = $CPU[$i] + $Idle[$i];
      $Tm = $CountersampTime * 1e-4; // 100.0 * 1e-6
      $Timer[$i] = $Tm > 115 ? 115 : $Tm;
      if ($CountersampTime <= 0) {
         $CountersampTime = 1;
      }
      $CPU[$i] = 100 * $CPU[$i] / $CountersampTime; // % of CPU Used (Idle time in Microseconds)
      $Idle[$i] = $CPU[$i] + (100 * $Idle[$i] / $CountersampTime); // % Of CPU unused (in microseconds)
   }
   echo "<br> CPU Usage (Blue: Slow Timer, DarkRed: Packet, LightRed: Idle<br>";
   GraphPerfCountersLinked("CPU Usage",
         array($Idle,$CPU,$Timer),
         array("CPU Idle %","CPU Used %"),
         array("red:1.5","red","blue"),1,115,0,0,$Counters["UnixTime"],true,array(0,0,1));
   if (0) {
	   if (array_sum($Counters["CompressionClearTextBytes"]["Rate"]) > 0 ||
		   array_sum($Counters["DecompressionClearTextBytes"]["Rate"]) > 0) {
		  DoCompressionGraphs($Counters);
	   }
   }

   if (array_sum($Counters["CompressionBacklog"]["Rate"]) > 0) {
       echo "<br>Bytes Red:Pending Compression<br>";
       GraphPerfCountersLinked("Compression Queues",
          array($Counters["CompressionBacklog"]["Rate"]),
          array("Pending Compression"),
          array("red"),1,0,0,0,$Counters["UnixTime"]);
   }

   if (array_sum($Counters["CompressionRewindTextBytes"]["Rate"]) > 0 ||
       array_sum($Counters["CompressionPrewindTextBytes"]["Rate"]) > 0 ||
       array_sum($Counters["CompressionRewinds"]["Rate"]) > 0 ||
       array_sum($Counters["CompressionPrewinds"]["Rate"]) > 0 ||
       array_sum($Counters["DecompressionRewinds"]["Rate"]) > 0) {
       echo "<br>";
       GraphPerfCountersLinked("Rewind Received(Red) Rewind Sent(DarkRed) Prewinds(Blue)",
             array($Counters["CompressionRewinds"]["Rate"],$Counters["DecompressionRewinds"]["Rate"],$Counters["CompressionPrewinds"]["Rate"]),
             array("Compression","Decompression","Compression Prewinds"),
             array("red","red:1.5","blue"),1,0,0,0,$Counters["UnixTime"]);
       echo "<br>";
       GraphPerfCountersLinked("Rewind Bytes (Red) Prewind Bytes (Blue)",
             array($Counters["CompressionRewindTextBytes"]["Rate"],$Counters["CompressionPrewindTextBytes"]["Rate"]),
             array("Compression Rewind Bytes","Compression Prewind Bytes"),
             array("red","blue"),1,0,0,0,$Counters["UnixTime"]);

   }
   if (array_sum($Counters["FastWindowStops"]["Rate"]) != 0 ||
       array_sum($Counters["SlowWindowStops"]["Rate"]) != 0) {
	    echo "<br>";
   		GraphPerfCountersLinked("Window Stops (Fast = Bright Red) ",
   	       	 array($Counters["FastWindowStops"]["Rate"],$Counters["SlowWindowStops"]["Rate"]),
   		     array("Fast","Slow"),
   		     array("red","red:1.5"),1,0,0,0,$Counters["UnixTime"]);
   }
   if (array_sum($Counters["FastWindowZeros"]["Rate"]) != 0 ||
       array_sum($Counters["SlowWindowZeros"]["Rate"]) != 0) {
	    echo "<br>";
   		GraphPerfCountersLinked("Window Zeros (Fast = Bright Red)",
   	       	 array($Counters["FastWindowZeros"]["Rate"],$Counters["SlowWindowZeros"]["Rate"]),
   		     array("Fast","Slow"),
   		     array("red","red:1.5"),1,0,0,0,$Counters["UnixTime"]);
   }

   if (array_sum($Counters["FastRTOs"]["Rate"]) != 0 ||
       array_sum($Counters["SlowRTOs"]["Rate"]) != 0) {
	    echo "<br>";
   		GraphPerfCountersLinked("RTOs (Fast = Bright Red)",
   	       	 array($Counters["FastRTOs"]["Rate"],$Counters["SlowRTOs"]["Rate"]),
   		     array("Fast","Slow"),
   		     array("red","red:1.5"),1,0,0,0,$Counters["UnixTime"]);
   }
   if ((array_sum($Counters["CompressionBootOuts"]["Rate"]) +
        array_sum($Counters["CompressionDiskReadBootOuts"]["Rate"]) +
        array_sum($Counters["CompressionDiskWriteBootOuts"]["Rate"]) +
        array_sum($Counters["DecompressionDiskWriteBootOuts"]["Rate"]) +
        array_sum($Counters["DecompressionDiskReadBootOuts"]["Rate"]))
   		!= 0) {
      $CBO = $Counters["CompressionBootOuts"]["Rate"];
      $CRBO = AddArrays($CBO,$Counters["CompressionDiskReadBootOuts"]["Rate"]);
      $CWBO = AddArrays($CRBO,$Counters["CompressionDiskWriteBootOuts"]["Rate"]);
      $DRBO = AddArrays($CWBO,$Counters["DecompressionDiskReadBootOuts"]["Rate"]);
      $DWBO = AddArrays($DRBO,$Counters["DecompressionDiskWriteBootOuts"]["Rate"]);
      echo "<br>Boot Outs: Purple: D-Write, Green: D-Read, Blue:C-Write, Yellow:C-Read, Red:Memory <br>";
      GraphPerfCountersLinked("Boot Outs",
         array($DWBO,$DRBO,$CWBO,$CRBO,$CBO),
         array("DWrite","DRead","CWrite","CRead","Memory"),
         array("purple","green","blue","yellow","red"),1,0,0,0,$Counters["UnixTime"]);
   }
   if (0) {
      echo "<br>";
      GraphPerfCountersLinked("Virtual Memory Usage",
            array($Counters["MemoryPressureEvents"]["Rate"],$Counters["VMUsage"]["Rate"]),
            array("VM","VM"),
            array("red","red"),1,0,0,0,$Counters["UnixTime"]);
   }
   echo "<br>";
   for ($i = 0; $i < 60; $i = $i + 1) {
      $x = $Counters["SlowPacketsTransmitted"]["Rate"][$i];
      if ($x == 0) {
         $CountersendSize[$i] = 0;
      } else {
         $CountersendSize[$i] = $Counters["SlowBytesTransmitted"]["Rate"][$i] / $x;
      }
      $x = $Counters["SlowPacketsReceived"]["Rate"][$i];
      if ($x == 0) {
         $RecvSize[$i] = 0;
      } else {
         $RecvSize[$i] = $Counters["SlowBytesReceived"]["Rate"][$i] / $x;
      }
   }
   if (array_sum($CountersendSize) != 0 || array_sum($RecvSize) != 0) {
      GraphPerfCountersLinked("Slow Packet Sizes (Bright Red=Send)",
         array($CountersendSize,$RecvSize),
         array("Send","Recv"),
         array("red","red:1.5"),1,0,0,0,$Counters["UnixTime"]);
   }
   echo "<br>";
   for ($i = 0; $i < 60; $i = $i + 1) {
      $x = $Counters["FastPacketsTransmitted"]["Rate"][$i];
      if ($x == 0) {
         $CountersendSize[$i] = 0;
      } else {
         $CountersendSize[$i] = $Counters["FastBytesTransmitted"]["Rate"][$i] / $x;
      }
      $x = $Counters["FastPacketsReceived"]["Rate"][$i];
      if ($x == 0) {
         $RecvSize[$i] = 0;
      } else {
         $RecvSize[$i] = $Counters["FastBytesReceived"]["Rate"][$i] / $x;
      }
   }
   if (array_sum($CountersendSize) != 0 || array_sum($RecvSize) != 0) {
      GraphPerfCountersLinked("Fast Packet Sizes (Bright Red=Send)",
         array($CountersendSize,$RecvSize),
         array("Send","Recv"),
         array("red","red:1.5"),1,0,0,0,$Counters["UnixTime"]);
   }

   ?>

<br>




<!-- THIS IS THE MAIN SETTINGS BLOCK -->
<TABLE  class="settings_table">

	<!-- SYSTEM STATUS BLOCK -->
	<TR cellspacing="40" cellpading="40">
	<TH>
		WANScaler Status:&nbsp;&nbsp;
	</TH>

	<TD>

			<?php
				$PassThrough = GetParameter("PassThrough");
				if (!$PassThrough)
				{
					echo "<FONT color=\"red\" size=\"+1\">NORMAL</FONT>&nbsp;&nbsp;<br></TD>";
				}
				else
				{
					echo "<FONT color=\"red\" size=\"+1\">STOPPED</FONT>&nbsp;&nbsp;<br>";
				}
			?>
		<BR>
	</TD>
	</TR>

	<!-- SYSTEM THROUGHPUT BLOCK -->
	<TR>
	<TH>
		Throughput:&nbsp;&nbsp;
	</TH>

	<TD>
      <?
         $CountersendRate = GetParameter("SlowSendRate");
         $RecvRate = GetParameter("SlowRecvRate");
         $CountersplitRate = GetParameter("UI.UseSplitRates");
         if (!$CountersplitRate) {
            echo "Max: <B>" . FormatThroughput($CountersendRate). "</B>";
         } else {
            echo "Max Send: <B> " . FormatThroughput($CountersendRate) . " </B> Max Recv: <B> " . FormatThroughput($RecvRate) . "</B>";
         }
      ?>
			<br>
			<a href="bw_scheduler.php">Adjust Using BW Scheduler</a>

	</TD>
	</TR>

</TR>
</TABLE>
</DIV>

<!-- DISPLAY THE CONNECTION LIST -->
<BR>
<?

if (GetParameter("UI.DisplayDebugInfo")) {

		$Counters = OrbitalGet("CONNECTION",
									array("ClientLogicalAddress", "ClientPhysicalAddress",
									"ServerLogicalAddress", "ServerPhysicalAddress",
									"Duration", "InstanceNumber", "BytesTransferred", "IdleTime", "Accelerated", "Agent") );

		$AcceleratedConnections = 0;
		foreach ($Counters as $OneConnection)
		{
			if ($OneConnection["Accelerated"]) $AcceleratedConnections++;
		}


	?>


		<TABLE class="width950" align="center">
			<TR align=center class="table_header"><TD colspan=8><?=$AcceleratedConnections?> Active Connections</TD></TR>
	<? if ($AcceleratedConnections != 0) { ?>
			<TR align=center class="table_header">
				<TD>Details</TD>
				<TD>Initiator</TD>
				<TD><=></TD>
				<TD>Responder</TD>
				<TD>Duration</TD>
				<TD>Idle</TD>
				<TD>Bytes Xfered</TD>
				<TD>WANScaler Partner</TD>
			</TR>
	<? } ?>

	<?
		foreach ($Counters as $OneConnection)
		{
			if ($OneConnection["Accelerated"]) {
				$ClientAddress = FormatIPAddressPort($OneConnection["ClientLogicalAddress"], false);
				$CounterserverAddress = FormatIPAddressPort($OneConnection["ServerLogicalAddress"]);
				$Duration 	   = $OneConnection["Duration"];
				$InstanceNumber = $OneConnection["InstanceNumber"];
				$IdleTime = $OneConnection["IdleTime"];
				$BytesTransferred = $OneConnection["BytesTransferred"];
				if ($OneConnection["Agent"]["Accelerated"]) {
					$Agent = FormatAgent($OneConnection["Agent"]);
				} else {
					$Agent = "<i>None</i>";
				}
		?>
				<TR class="row-1">
					<TD align="center"><a href="./connection_info.php?InstanceNumber=<?=$InstanceNumber?>">
						<img src="./images/icon-info.gif" border="0" alt="Click Here For Detailed Connection Information"> </a></TD>
					<TD><?=$ClientAddress?></TD>
					<TD align="center"><=></TD>
					<TD><?=$CounterserverAddress?></TD>
					<TD align="center"><?=(int)$Duration?>&nbsp;Secs</TD>
					<TD align="center"><?=(int)$IdleTime?>&nbsp;Secs</TD>
					<TD align="center"><?=$BytesTransferred?></TD>
					<TD align="center"><?=$Agent?></TD>
				</TR>
	<?
			}
		}

	?>
		</TABLE>

   </TABLE>

<? } ?>

   <br> <br> <center> <h2> Detailed System Information</h2> </center>

   <TABLE class="settings_table">
      <TR align=center class="table_header">
         <TH>Attribute</TH>
         <TD>Value</TD>
      </TR>

   <?
		$Values = OrbitalGet("SYSTEM",array(
			                  "Version", "ActiveRecvEndPoints", "DesiredRecvWindow",
			                  "AvailablePackets", "TotalPacketCount", "RecvWindowRatio", "InverseDecompressionRatio",
			                  "VMConsumption", "SocketCount", "SkbuffTotal", "SkbuffActive", "CifsPacketCount", "TotalMemoryPressureEvents",
                           "ProcessID", "TotalCompressionRewinds", "TotalDecompressionRewinds",
                           "TotalDecompressionRewindMisses",
                           "TotalDecompressionRewindLosses",
                           "RecentRate",
                           "TotalCompressionPrewinds",
                           "TotalCompressionBootOuts",
                           "TotalCompressionSendCompactedBytes",
                           "TotalCompressionRecvCompactedBytes",
		                     "DBC.ChunkCount",
   		                  "DBC.FreeChunkCount",
   		                  "DBC.PendingDeleteChunkCount",
   		                  "DBC.UnderConstructionChunkCount",
   		                  "DBC.DirtyNameBlocks",
   		                  "DBC.DirtyPrintBlocks",
                           "DBC.ListCountSendWrite",
                           "DBC.ListCountSendRead",
                           "DBC.ListCountRecvWrite",
                           "DBC.ListCountRecvRead",
                           "SackCompactionAttempts",
                           "SackCompactionFrees"
		));
      $Values["VMPoolSize"] = GetParameter("System.MaxVMPoolSize");
      $ProcStatus = "/proc/" . $Values["ProcessID"] . "/status";
      if (file_exists($ProcStatus)) {
         $ProcStatus = file($ProcStatus);
         foreach ($ProcStatus as $Line) {
            if (strncmp("Vm", $Line, 2) == 0) {
               $Tokens = split("[:\s]+", $Line);
               $Values[array_shift($Tokens)] = implode(" ", $Tokens);
            }
         }
      }
      $Param["Class"] = "NORB_CONNECTION";
      $Param["InstanceCount"] = 0;
      $Param["FirstInstance"] = 0;
      $Instances = xu_rpc_http_concise(
                     array(
                        'method' => "GetInstances",
                        'args'   => $Param,
                        'host'   => RPC_SERVER,
                        'uri'    => RPC_URI,
                        'port'   => RPC_PORT
                     ));
      $Values["Unaccelerated Connections"] = $Instances["Count"];

      $Param["Class"] = "CONNECTION";
      $Param["InstanceCount"] = 0;
      $Param["FirstInstance"] = 0;
      $Instances = xu_rpc_http_concise(
                     array(
                        'method' => "GetInstances",
                        'args'   => $Param,
                        'host'   => RPC_SERVER,
                        'uri'    => RPC_URI,
                        'port'   => RPC_PORT
                     ));
      $Values["Accelerated Connections"] = $Instances["Count"];
      foreach ($Values as $Label => $Value)
      {
      ?>
            <TR>
               <TH align=center><?=$Label?></TH>
               <TD align=center><?=$Value?></TD>
            </TR>
      <?
      }
   ?>
   </TABLE>
   <br> <br> <center> <h2> Packet Memory Allocation Details</h2> </center>
   <TABLE class="settings_table2">
      <TR align=center class="table_header">
         <TH> <i> Path </i> </TH>
         <TH>TCP Reserve    </TH>
         <TH>TCP Send      </TH>
         <TH>TCP Receive   </TH>
         <TH>Compression    </TH>
         <TH>History Owned  </TH>
         <TH>History Shared </TH>
         <TH>Cifs           </TH>
         <TH>History (MB)   </th>
         <TH>Context Allocated</TH>
         <TH>Context In Use</TH>
      </TR>

   <?
   function DoCol($Name, $Data, $fields) {
      echo "<td> <i> " . $Name . " </i> </td>";
      for ($i = 0; $i < sizeof($fields); $i = $i + 1) { echo " <td align=right> ".$Data[$fields[$i]]["Packets"]."</td>"; }
   }

   function DoRow($Name, $Data, $TotalHistory, $OtherData, $fields, &$Sum) {
      echo "<TR>";
      DoCol($Name, $Data, $fields);
      echo "<TD align=right> " . (int)($TotalHistory / (1 << 20)) . "</td>";
      $Sum["TotalHistory"] = $Sum["TotalHistory"] + $TotalHistory;
      foreach ($OtherData as $OneCol){
         echo "<TD align=right>" . $OneCol . "</TD>";
      }
      echo "</TR>\n";
   }
   $fields = array("TCPReserve","TCPSend", "TCPRecv","Compression","HistoryUnshared","HistoryShared","Filter");

   $Flows = OrbitalGet("SLOW_FLOW",array("DestinationAgent", "SendPathAccounting", "RecvPathAccounting",
                                         "SenderContextAllocated", "SenderContextInUse", "ReceiverContextAllocated", "ReceiverContextInUse"));

   for ($i = 0; $i < sizeof($fields); $i = $i + 1) {
      $Sum[$fields[$i]]["Packets"] = 0;
   }

   $Sum["Allocated"] = 0;
   $Sum["InUse"] = 0;
   $Sum["TotalHistory"] = 0;

   function SumPath(&$Dst,$Src,$fields) {
      for ($i = 0; $i < sizeof($fields); $i = $i + 1) {
         $Dst[$fields[$i]]["Packets"] = $Dst[$fields[$i]]["Packets"] + (int)($Src[$fields[$i]]["Packets"]);
      }
   }

   for ($i = 0; $i < sizeof($Flows); $i = $i + 1) {
      DoRow($Flows[$i]["DestinationAgent"]["Printable"]."&nbsp;Send",$Flows[$i]["SendPathAccounting"],
            ($Flows[$i]["SendPathAccounting"]["Compression"]["Bytes"] + $Flows[$i]["SendPathAccounting"]["HistoryUnshared"]["Bytes"]-
             $Flows[$i]["SendPathAccounting"]["HistoryShared"]["Bytes"]),
            array($Flows[$i]["SenderContextAllocated"], $Flows[$i]["SenderContextInUse"]),$fields,$Sum);
      SumPath($Sum,$Flows[$i]["SendPathAccounting"],$fields);
      DoRow($Flows[$i]["DestinationAgent"]["Printable"]."&nbsp;Recv",$Flows[$i]["RecvPathAccounting"],
            ($Flows[$i]["RecvPathAccounting"]["HistoryShared"]["Bytes"] + $Flows[$i]["RecvPathAccounting"]["HistoryUnshared"]["Bytes"]),
            array($Flows[$i]["ReceiverContextAllocated"], $Flows[$i]["ReceiverContextInUse"]),$fields,$Sum);
      SumPath($Sum,$Flows[$i]["RecvPathAccounting"],$fields);
      $Sum["Allocated"] = $Sum["Allocated"] + $Flows[$i]["SenderContextAllocated"] + $Flows[$i]["ReceiverContextAllocated"];
      $Sum["InUse"] = $Sum["InUse"] + $Flows[$i]["SenderContextInUse"] + $Flows[$i]["ReceiverContextInUse"];
   }

   DoRow("System&nbsp;Total",$Sum,$Sum["TotalHistory"],array($Sum["Allocated"],$Sum["InUse"]  ), $fields,$Sum);

   ?>

   </TABLE>

</BODY>

<?  GenerateInplaceUpdateJavascript($AutoRefresh, $GraphRefreshRate); ?>

<?	include(HTTP_ROOT_INCLUDES_DIR ."footer.php"); ?>

</HTML>

<?
//
// Copyright 2002-2006 Citrix Systems, Inc.
//
?>
