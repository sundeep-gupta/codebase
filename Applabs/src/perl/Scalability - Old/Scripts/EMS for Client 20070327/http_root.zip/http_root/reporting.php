<?
   include_once('includes/orbital_lib.php');
   include_once('reporting_lib.php');
   include_once('service_lib.php');

   function generatePerformanceReport($GraphTimescale, $ReportName){

      /************************************************************************
       *  Get the basic stats from the WANScaler Core
	   ************************************************************************/
      
      $SystemValues = OrbitalGet("PARAMETER", array("UI.Softboost", 
                                                    "SlowSendRate",
                                                    "UI.Branding.ProductNumber") );
      
      $IsSoftboost  = $SystemValues["UI.Softboost"]["XML"];
      $SlowSendRate = $SystemValues["SlowSendRate"]["XML"];
      $ProductNum   = $SystemValues["UI.Branding.ProductNumber"]["XML"];
                  
      $SystemValues = OrbitalGet("SYSTEM", array("UpTime", 
                                                 "VersionCompact",
                                                 "CompressionClearTextBytes",
                                                 "CompressionClearTextBytes",
                                                 "CompressionCipherTextBytes",
                                                 "DecompressionClearTextBytes",
                                                 "DecompressionCipherTextBytes") );
      $Version      = $SystemValues["VersionCompact"];
      $Uptime       = $SystemValues["UpTime"];
      
      $UncompressedSent = $SystemValues["CompressionClearTextBytes"]["Total"];
      $CompressedSent   = $SystemValues["CompressionCipherTextBytes"]["Total"];

      $UncompressedRecv = $SystemValues["DecompressionClearTextBytes"]["Total"];
      $CompressedRecv   = $SystemValues["DecompressionCipherTextBytes"]["Total"];

      $SendCompRatio    = FormatRatio($UncompressedSent,	$CompressedSent);
      $RecvCompRatio    = FormatRatio($UncompressedRecv, $CompressedRecv);
      $TotalCompRation  = FormatRatio($UncompressedSent + $UncompressedRecv, $CompressedSent + $CompressedRecv);
      
      
      /************************************************************************
       *  Create the PDF document
	   ************************************************************************/
      $pdf=new ORBITAL_REPORT();
      $pdf->SetCreator("WANScaler");
      $pdf->SetTitle("WANScaler Performance Report");
      $pdf->AliasNbPages();


      /************************************************************************
       *  Create and add elements to page 1
	   ************************************************************************/
      $pdf->AddPage();
      $pdf->Ln(10);
      $pdf->AddTableHeader("Summary Data");
      if ($ReportName != "") { $pdf->AddTableRow("Report Name", $ReportName); }
      $pdf->AddTableRow("Generated On",        strftime ("%b %d, %Y %H:%M:%S"));
      $pdf->AddTableRow("Running Time",        ToPrintableTime($Uptime));
      $pdf->AddTableRow("Version",             $Version);
      if (!$IsSoftboost){ $pdf->AddTableRow("Bandwidth",             FormatThroughput($SlowSendRate));}
      $pdf->AddTableRow("Appliance Name",      GetHostname() );
      $pdf->AddTableRow("Appliance Hardware", $ProductNum );
      $pdf->AddTableRow("Compression Ratio",   $TotalCompRation);
    
      $SendChartname = DrawCompressionBarChart_Send();
      $pdf->Image("$SendChartname", 20, 100, 70, 55);        

      $RecvChartname = DrawCompressionBarChart_Recv();
      $pdf->Image("$RecvChartname", 120, 100, 70, 55);
      $AcceleratedSCGraphname = GraphProtocolBytes_ByAcceleratedSC(false);
      $pdf->Image("$AcceleratedSCGraphname", 10, 180, 90, 65);

      $UnacceleratedSCGraphname = GraphProtocolBytes_ByUnacceleratedSC(false);
      $pdf->Image("$UnacceleratedSCGraphname", 110, 180, 90, 65); 

      /************************************************************************
       *  Page 2 - Throughput graphs and Compression breakdown graphs
	   ************************************************************************/
      $pdf->AddPage();
      $pdf->SetFont('Times','',12);

      $Grapher = new PERF_GRAPHER();
      $Grapher->SetGraphAckProgress( GetParameter("UI.Graph.GraphSeqNumAdv") );
      $Grapher->SetGraphTimescale($GraphTimescale);
      $Grapher->SetShowFastSide(true);
      $Grapher->SetShowSlowSide(true);
      $Grapher->SetCombineSendRecv(false);
      $Grapher->Render();

      $pdf->Image("temp/WANBytesTransmitted($GraphTimescale).png", 10, 30, 90, 55);        
      $pdf->Image("temp/WANBytesReceived($GraphTimescale).png",    110, 30, 90, 55);        

      $pdf->Image("temp/LANBytesReceived($GraphTimescale).png",    10, 100, 90, 55);        
      $pdf->Image("temp/LANBytesTransmitted($GraphTimescale).png", 110, 100, 90, 55);        

      $BreakdownChartname = DrawCompressionBreakdownChart($GraphTimescale);
      $pdf->Image($BreakdownChartname,   10, 170, 90, 55);        
      $pdf->Image('images/compression_breakdown_legend.png', 24, 176, 70, 4);
      
      $ProtocolBytesGraphName = GraphProtocolBytes_BySC_AsBarChart(false);
      $pdf->Image("$ProtocolBytesGraphName", 110, 170, 90, 55);        

      $pdf->Output("WANScalerPerformanceReport.pdf", "I");
   }

      /************************************************************************
       *  User viewable report configuration section
      ************************************************************************/

      if (!isset($_GET["GenerateReport"])) {
         include_once("includes/header.php");

      ?>
         <font class="pageheading">Monitoring: Generate Report</font><BR><BR>

         <form name="GenerateReport">
         <table class="settings_table">
         <tr>
         <th>
         Report Name:
         </th>
         <td>
         <input name="ReportName" type="text" value="">&nbsp;(Optional)
         </td>
         <tr>
         </tr>
         <th>
         Time Duration:
         </th>
         <td>
         <select name="TimeDuration">
         <option value="LastDay">Last Day</option>
         <option value="LastHour">Last Hour</option>
         <option value="LastMinute">Last Minute</option>
         </select>
         </td>
         </tr>

         <tr>
         <th>
         </th>
         <td>
         <input name="GenerateReport" type="submit" value="Create">
         </td>
         </tr>

         </table>
         </form>

   <?
      /************************************************************************
       *  Call the generator
      ************************************************************************/
      }elseif (isset($_GET["GenerateReport"])) {

         $Timescale  = $_GET["TimeDuration"];
         $ReportName = $_GET["ReportName"];

         generatePerformanceReport($Timescale, $ReportName);
      } 
   ?>

