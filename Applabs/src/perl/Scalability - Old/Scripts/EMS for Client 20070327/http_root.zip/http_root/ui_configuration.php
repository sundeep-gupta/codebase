<?
   include("includes/header.php");
   $Auth->CheckRights(AUTH_LEVEL_ADMIN);
?>

<?
   if (isset($_POST["FormName"]) && $_POST["FormName"] == "ui_config3") {
      if (isset($_POST[EscapeParamName("Http.Port")])
          && isset($_POST[EscapeParamName("Http.SslCert")])
          && isset($_POST[EscapeParamName("Http.SslPrivateKey")])) {

         $UseHttps = isset($_POST[EscapeParamName("Http.UseHttps")]);
         $Port = $_POST[EscapeParamName("Http.Port")];
         $SslCert = $_POST[EscapeParamName("Http.SslCert")];
         $SslPrivateKey = $_POST[EscapeParamName("Http.SslPrivateKey")];

         $Param["Class"] = "SYSTEM";
         $Param["Attribute"]["HttpPortConfiguration"]["UseHttps"] = $UseHttps;
         $Param["Attribute"]["HttpPortConfiguration"]["Port"] = $Port;
         $Param["Attribute"]["HttpPortConfiguration"]["SslCert"] = $SslCert;
         $Param["Attribute"]["HttpPortConfiguration"]["SslPrivateKey"] = $SslPrivateKey;

         $Results = xu_rpc_http_concise(
                                        array(
                                              'method'    => "Set",
                                              'args'      => $Param,                 
                                              'host'      => RPC_SERVER,
                                              'uri'       => RPC_URI,
                                              'port'      => RPC_PORT
                                              ));
         ShowStatusMessage("Updating HTTP Configuration...");
         echo HTML::InsertRedirect("ui_configuration.php", 10);
         exit;
      } else {
         ThrowException("Incomplete HTTP configuration submitted.", true);
      }
   }
?>

<?
   echo "<font class=pageheading>Configure Settings: UI</font><BR><BR>";
   echo "<font class=pageheading>UI: Graphing</font><BR><BR>";
   $Table = new HTML_TABLE();
   $ParamForm = new HTML_PARAMETER_FORM();
   echo
      $Table->Begin("settings_table"),
      $ParamForm->Begin("ui_config1"),
      $Table->AddEntry("Display WAN Side Graph:",   $ParamForm->AddBooleanParam("UI.Graph.ShowWANGraph")),
      $Table->AddEntry("Display LAN Side Graph:",   $ParamForm->AddBooleanParam("UI.Graph.ShowLANGraph")),
      $Table->AddEntry("Combine Send/Receive Graphs:", $ParamForm->AddBooleanParam("UI.Graph.CombineSndRecvGraph") ),
      $Table->AddEntry("Autoscale Graphs:", $ParamForm->AddBooleanParam("UI.Graph.AutoScale") ),
      $Table->AddEntry("Graph Refresh Rate:", $ParamForm->AddTextParam("UI.Graph.RefreshRate", 4) . "seconds" ),
      $Table->AddEntry("Autorefresh Graph:", $ParamForm->AddBooleanParam("UI.Graph.AutoRefresh") ),
      $Table->AddEntry("", $ParamForm->AddSubmit() ),
      $ParamForm->End(),
      $Table->End();
   echo "</CENTER><BR>";

?>

<?
   echo "<font class=pageheading>UI: Miscellaneous</font><BR><BR>";
   $Table = new HTML_TABLE();
   $ParamForm = new HTML_PARAMETER_FORM();
   echo
      $Table->Begin("settings_table"),
      $ParamForm->Begin("ui_config2"),
      $Table->AddEntry("Lock Changes Via LCD:", $ParamForm->AddBooleanParam("UI.XF633.Lock") ),
      $Table->AddEntry("Max Connections Shown On Connection Page:", $ParamForm->AddTextParam("UI.ConnList.ConnectionsShown", 3) ),
      $Table->AddEntry("", $ParamForm->AddSubmit() ),
      $ParamForm->End(),
      $Table->End();
   echo "</CENTER><br>";

?>

<script>
function UseHttpOnClick() {
   var CheckBoxElement = document.getElementsByName("Http_UseHttps");
   var CheckBoxValue = CheckBoxElement[0].value;

   var PortElement = document.getElementsByName("Http_Port");
   var PortValue = PortElement[0].value;

   if (PortValue == 80 && CheckBoxValue == 0) {
      PortElement[0].value = "443";
      CheckBoxElement[0].value = 1;
   } else if (PortValue == 443 && CheckBoxValue == 1) {
      PortElement[0].value = "80";
      CheckBoxElement[0].value = 0;
   }
}
</script>

<?
   $Param["Class"] = "SYSTEM";
   $Param["Attribute"] = "HttpPortConfiguration";
   $Request = xu_rpc_http_concise(
                                  array(
                                        'method' => "Get",
                                        'args' => array($Param),
                                        'host' => RPC_SERVER,
                                        'uri'  => RPC_URI,
                                        'port' => RPC_PORT
                                        )
                                  );

   $Port = $Request["HttpPortConfiguration"]["Port"];
   $UseHttps = $Request["HttpPortConfiguration"]["UseHttps"];
   $SslCert = $Request["HttpPortConfiguration"]["SslCert"];
   $SslPrivateKey = $Request["HttpPortConfiguration"]["SslPrivateKey"];

   echo "<font class=pageheading>UI: HTTP Configuration</font><BR><BR>";
   $Table = new HTML_TABLE();
   $ParamForm = new HTML_PARAMETER_FORM();

   echo
      $Table->Begin("settings_table"),
      $ParamForm->Begin("ui_config3", "", "post"),
      $Table->AddEntry("Use HTTPS:", $ParamForm->AddCheckBox_onClick(EscapeParamName("Http.UseHttps"), $UseHttps, "UseHttpOnClick()")),
      $Table->AddEntry("WebUI Port:", $ParamForm->AddTextParam("Http.Port", 3) ),
      $Table->AddEntry("SSL Certificate", $ParamForm->AddTextArea(EscapeParamName("Http.SslCert"), $SslCert, 70, 24) ),
      $Table->AddEntry("SSL Private Key", $ParamForm->AddTextArea(EscapeParamName("Http.SslPrivateKey"), $SslPrivateKey, 70, 16) ),
      $Table->AddEntry("", $ParamForm->AddSubmit() ),
      $ParamForm->End(),
      $Table->End();
   echo "</CENTER>";

?>

<? include(HTTP_ROOT_INCLUDES_DIR . "footer.php");  ?>
