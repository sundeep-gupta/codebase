<?
   //
   // This html is adapted from the m0n0wall project
   //
   $CurrentPage      = substr($_SERVER['PHP_SELF'], 1, strlen($_SERVER['PHP_SELF']));
   $DisplayedPages   = array("") ;

   //
   // If we are in sales tool mode, only display a subset of links get displayed
   //
   array_push($DisplayedPages, "System Status", "Service Class", "Save / Restore", "Update Software",
                               "Update License", "Restart System", "Diagnostic Tool", "Remote Debug", "Logout");

   if ($CifsSupported){
      array_push($DisplayedPages, "CIFS", "CIFS Status");
   }
   if ($HTTPSupported){
      array_push($DisplayedPages, "HTTP", "HTTP Status");
   }
   if ($CompressionSupported) {
      array_push($DisplayedPages,"Compression","Compression Status");
   }

   array_push($DisplayedPages, "Usage Graph", "Active Connections",
                               "Service Class Statistics", 
                               "QoS Statistics",
                               "Bandwidth Management",
                               "Proxy", "Interface", "Tuning", "SNMP", "Date/Time",
                               "Logging", "Alert", "UI", "NFS", 
                               "Service Class", "Service Class Policy",
                               "QoS", 
                               "IP Address", "High Availability", "View Logs",
                               "Manage Users", "Access", "Group Mode", "WANScaler Client", "Generate Report");


   //
   // Add a sidebar entry...checking is done to see if it should really
   // be added depending on the mode
   //
   function AddSidebarEntry($PageName, $LinkName, $bEnabled = TRUE){
      global $CurrentPage, $DisplayedPages;

      if (!in_array($LinkName, $DisplayedPages)){return;}

      if (!$bEnabled)
         echo "<li class='inactive'>$LinkName</li>";
      else if ($CurrentPage == $PageName){
         echo "<li class='active'><a href='$PageName'>$LinkName</a></li>";
      }else{
         echo "<li><a href='$PageName'>$LinkName</a></li>";
      }
   }
?>

<table border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td valign="top" style="padding-top: 0px; padding-bottom: 0px; padding-right: 0px; padding-left: 0px">
      <table width="170" border="0" cellspacing="0" cellpadding="0">
        <tr>
         <td class="navtbl">
         <div class="nav">
         <ul>
            <li class="title">Monitoring</li>
            <?
               AddSidebarEntry("status.php", "System Status");
               AddSidebarEntry("throughput.php", "Usage Graph");
               AddSidebarEntry("active_connections.php", "Active Connections");
               AddSidebarEntry("cifs_status.php", "CIFS Status", $CifsLicensed);
               AddSidebarEntry("sc_statistics.php", "Service Class Statistics");
               AddSidebarEntry("performance_profiler.php", "Performance Profiler");
               AddSidebarEntry("compression_status.php","Compression Status");
               AddSidebarEntry("qos_statistics.php","QoS Statistics");
            ?>
         </ul>

         <ul>
            <li class="title">Configure Settings</li>
            <?
               AddSidebarEntry("bw_scheduler.php", "Bandwidth Management");
               AddSidebarEntry("proxies.php", "Proxy");
               AddSidebarEntry("ethernet.php", "Interface");
               AddSidebarEntry("tuning.php", "Tuning");
               AddSidebarEntry("snmp.php", "SNMP");
               AddSidebarEntry("datetime.php", "Date/Time");
               AddSidebarEntry("log_configuration.php", "Logging");
               AddSidebarEntry("alert_configuration.php", "Alert");
               AddSidebarEntry("ui_configuration.php", "UI");
               AddSidebarEntry("cifs_configuration.php", "CIFS", $CifsLicensed);
               AddSidebarEntry("http_config.php", "HTTP");
               AddSidebarEntry("nfs_config.php", "NFS");
               AddSidebarEntry("service_class.php", "Service Class");
               AddSidebarEntry("service_class_policy.php", "Service Class Policy");
               AddSidebarEntry("qos.php", "QoS");
               AddSidebarEntry("managementip.php", "IP Address");
               AddSidebarEntry("ha_config.php", "High Availability");
               AddSidebarEntry("group.php", "Group Mode");
               AddSidebarEntry("performance_profiler_configuration.php", "Performance Profiler");
               if ($EdgeModeSupported) AddSidebarEntry("edge_mode.php", "WANScaler Client");
            ?>
         </ul>

         <ul>
            <li class="title">Reporting</li>
            <?
               AddSidebarEntry("reporting.php",  "Generate Report");
            ?>
         </ul>

         <ul>
            <li class="title">System Tools</li>
            <?
               AddSidebarEntry("backup.php",  "Save / Restore");
               AddSidebarEntry("patch.php",   "Update Software");
               AddSidebarEntry("license.php", "Update License");
               AddSidebarEntry("restart.php", "Restart System");
               AddSidebarEntry("logging.php", "View Logs");
            ?>
         </ul>

         <ul>
            <li class="title">Security</li>
            <?
               AddSidebarEntry("user_config.php", "Manage Users");
               AddSidebarEntry("access_config.php", "Access");
               AddSidebarEntry("logout.php", "Logout");
            ?>
         </ul>

         <ul>
            <li class="title">Diagnostics</li>
         <?
               AddSidebarEntry("debug.php", "Diagnostic Tool");
               AddSidebarEntry("debug_extender.php", "Remote Debug");
         ?>
         </ul>

         </div>
         </td>

        </tr>
      </table>
   </table>
