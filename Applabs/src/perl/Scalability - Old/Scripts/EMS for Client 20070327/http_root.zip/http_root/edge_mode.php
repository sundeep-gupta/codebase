<?
   include("includes/header.php");
   $Auth->CheckRights(AUTH_LEVEL_ADMIN);
?>
<Script>

<!--
   function confirmSubmit()
   {

      var subform=document.OrbitalEdgeMode;
      subform.submit();
   }
// -->
</Script>

<?
   function GetRedirectorIP(){
      $EdgeIP  = "";
      $results = GetParameters("Jibeline.Vips");
      if (sizeof( $results["Jibeline.Vips"]["XML"]) > 0){
         $EdgeIP  = $results["Jibeline.Vips"]["XML"][0]["Dotted"];
      }
      return $EdgeIP;
   }

   if ( isset($_GET["EdgeIP"]))
   {
      //
      // First lets check to see if the Redirector IP is not already 
      // being used on this Appliance, if so display an error
      //
      $NewEdgeIP = $_GET["EdgeIP"];
      $OldEdgeIP = GetRedirectorIP();
      if ( $NewEdgeIP != $OldEdgeIP ){
         if ( $NewEdgeIP!="" && HostHasIP($NewEdgeIP) ){
            echo "<font color='red'>The Redirector IP you are attempting to use is already " .
                 "used by this Orbital. Please choose a different IP.</font><br><br>";
         }else{
            SetParameterText("Jibeline.Vips", $NewEdgeIP );
         }
      }

      SetParameterText("System.TunnelPort", $_GET["EdgePort"] );
      SetParameterText("OMS.Controller.Hostname", $_GET["OmsIP"] );
      SetParameterText("OMS.Controller.Port",     $_GET["OmsPort"] );
      echo HTML::InsertRedirect("", 15);
   }
   
   $EdgeIP              = GetRedirectorIP();
   $EdgePort            = GetParameter("System.TunnelPort");
   $OmsIP               = GetParameter("OMS.Controller.Hostname");
   $OmsPort             = GetParameter("OMS.Controller.Port");
   $OmsConnectionStatus = GetSystemParam("OMSIsConnected");

?>

<font class="pageheading">Configure Settings: WANScaler Client</font><BR><BR>
    <form name="OrbitalEdgeMode">
      <table class="settings_table">
        <tr>
          <th>
            Redirector IP:
          </th>
          <td>
            <input name="EdgeIP" type="text" value="<?=$EdgeIP?>">
            <?
               if ( !HostHasIP($EdgeIP) ){
                  echo "<font color='red'>Couldn't add IP: $EdgeIP</font>";
               }
            ?>
          </td>
        </tr>
        <tr>
          <th>
            Redirector Port:
          </th>
          <td>
            <input name="EdgePort" type="text" value="<?=$EdgePort?>">
          </td>
        </tr>
        <tr>
          <th>
            WANScaler Controller IP Address:
          </th>
          <td>
            <input name="OmsIP" type="text" value="<?=$OmsIP?>">
          </td>
        </tr>
        <tr>
          <th>
            WANScaler Controller Port:
          </th>
          <td>
            <input name="OmsPort" type="text" value="<?=$OmsPort?>">
          </td>
        </tr>
        <tr>
          <th>
          </th>
          <td>
            <input name="EdgeModeUpdateSettings" type="button" value="Update" onClick="confirmSubmit()">
          </td>
        </tr>
      </table>
    </form>
    
    
   <br/><br/>
   <table class="settings_table">
     <tr>
       <th>
         WANScaler Client Controller Connection Status:
       </th>
       <td>
         <b><?= $OmsConnectionStatus ? "Connected" : "Not Connected" ?></b>
       </td>
     <tr>

   </table>



<? include(HTTP_ROOT_INCLUDES_DIR ."footer.php"); ?>
