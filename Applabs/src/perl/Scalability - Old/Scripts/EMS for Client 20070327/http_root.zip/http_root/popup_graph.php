<?
   require("includes/configure.php");
   include("includes/orbital_lib.php");

   $Auth = new OD_AUTH();
   $Auth->CheckLogin();
   $Auth->CheckRights(AUTH_LEVEL_VIEWER);

   $GraphRefreshRate = GetParameter("ui.graph.refreshrate");
?>

<HTML>
   <HEADER>
      <TITLE>WANScaler Throughput: <?=GetHostname()?></TITLE>
      <META http-equiv="refresh" content="<?=$GraphRefreshRate?>;URL=./popup_graph.php">
      <META http-equiv="Expires" content="<?=$GraphRefreshRate?>">
      <META http-equiv="Pragma" content="no-cache">
      <META http-equiv="Cache-control" content="no-cache">      
   </HEADER>
   <BODY>
<?
   $Grapher = new PERF_GRAPHER();
   $Grapher->SetCombineSendRecv(true);
   $Grapher->SetShowFastSide(false);
   $Grapher->SetShowSlowSide(true);
   $Grapher->SetDisplayLegend(false);
   $Grapher->SetIsResizable(true);
   echo $Grapher->Render();

?>
   </BODY>
</HTML>
