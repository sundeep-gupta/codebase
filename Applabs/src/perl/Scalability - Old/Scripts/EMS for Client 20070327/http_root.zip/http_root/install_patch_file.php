<?
   define('PAGE_IS_HA_CLUSTER_INDEPENDANT', true);
   define('DONT_REQUIRE_RUNNING_SERVER', true);
   include("includes/header.php");
   $Auth->CheckRights(AUTH_LEVEL_ADMIN);
?>

<BR><BR><BR>
<CENTER>
<?
   $PatchFilename = "update.bin";
   $UpgradeDir = SYSTEM_TEMP_DIR . "odupgrade/";
   
   @mkdir ($UpgradeDir);   
   chdir($UpgradeDir);

   if (isset($_POST["AddPatchButton"]))
   {
      //
      // Move the patch file too the temp directory
      //
      if ($_FILES['userFile']['name']== "")
      {
         ThrowException("No patch file uploaded. Did you correctly select the patch file?", true);
      }
      else if ($_FILES['userFile']['size']== 0)
      {
         ThrowException("Unable to upload patch. Patch size may be too large!", true);
      }      

      //
      // Now verify that the patch was valid
      //
      $ReturnCode = 0;
      $Results = array();
      exec("/orbital/util/upgrade --verify " . $_FILES['userFile']['tmp_name'], $Results, $ReturnCode);

      if ($ReturnCode != 0) // Bad patch
      {

         ThrowException("Patch file was bad. Please retry the upload.", false);
         ThrowException("If this error persists, please contact customer support.", false);

         echo "<hr>\n";
         foreach ($Results  as $Line)
         {
            if (ereg('^Error:(.*)', $Line, $Pruned)) {
               echo("$Pruned[1]<br>\n");
            }
         } 

         echo "<hr>\n";
         foreach ($Results  as $Line)
         {
            echo("$Line<br>\n");
         }      
         exit;
      }
      
      //
      // Now move the file into the final location that the upgrade script will use
      //
      @unlink ($UpdateDir . $PatchFilename);
      move_uploaded_file($_FILES['userFile']['tmp_name'], $UpgradeDir . $PatchFilename);


      ShowStatusMessage("Patch upload was successful.");
   }


   if (MSG_BOX::Ask("Restart Unit?", "Patch file upload was successful. You must restart your unit for it to take effect. Do you wish to reboot now?") == MSG_BOX_YES){
      //
      // User opted to reboot right now
      //
      HTML::InsertCountdownRedirect(INSTALL_TIME, "./index.php", "(Please wait while the new software is installed)");
      exec("/usr/bin/sudo /sbin/reboot");
   }else{
      //
      // User opted to defer the reboot until later. A banner will be shown indicating a reboot is required
      //
      SetSystemParam("UnitRequiresReboot", true);
      echo HTML::InsertRedirect("status.php", 0);
   }
   
?>
</CENTER>

<? 
//
// Copyright 2002,2003 Orbital Data Corporation
//
/*
 * $Author: Mark Cooper $ 
 * $Modtime: 5/20/03 5:58p $ 
 */
?>
