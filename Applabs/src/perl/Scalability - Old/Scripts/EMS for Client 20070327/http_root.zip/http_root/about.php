
<?	
   include("includes/header.php");
   $Auth->CheckRights(AUTH_LEVEL_VIEWER);
?>

<br><br><br>
<b><center>More about info coming soon</center></b>

<?	
//
// Copyright 2002,2003 Orbital Data Corporation
//
/*
 * $Author: Mark Cooper $ 
 * $Modtime: 5/02/03 12:32p $ 
 * $Log: /source/vpn_filter/http_root/About.php $
 * 
 * 2     5/02/03 12:35p Mark Cooper
 */
?>
