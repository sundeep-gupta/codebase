<?
   define('PAGE_IS_HA_CLUSTER_INDEPENDANT', true);
   define('DONT_REQUIRE_RUNNING_SERVER', true);
   include("includes/header.php");
   $Auth->CheckRights(AUTH_LEVEL_ADMIN);
?>

<font class="pageheading">System Tools: Update Software</font><BR><BR>

<?
   //
   // Downgrade to an old release
   //   
   if (isset($_GET["ChangeRelease"]) )
   {      
       
      exec ("/usr/bin/sudo /orbital/util/orbsys --setcurrentrelease=" . $_GET["Release"] );

      ShowStatusMessage("Restarting system with selected version...");
      ShowStatusMessage("(this will take several minutes)");

      // *** Do not use restart.php it will be pointing to the new http_root which is not compatible
      // *** with the running orbital_server.
      //
      // Reboot the box.
      //
      if ($HaRunning && isServerMatchVMIP()) {
         // Secondary system takes it over. Approximately time is 3-5 seconds
         echo HTML::InsertRedirect("patch.php", RESTART_TIME_HA);
      }else {
         echo HTML::InsertRedirect("patch.php", 240);
      }
      SendCommand("reboot", "");

      exit();
   }


   //
   // Change to the production or debug Orbital binary
   //
   $POSSIBLE_RELEASES = array("server", "level1", "level2", "server_mc", "level1_mc", "level2_mc");
   
   if (isset($_GET["ChangeVersionType"]) )
   {
      $Type = $_GET["Type"];
         
      if (!in_array($Type, $POSSIBLE_RELEASES)){
         ThrowException("You passed in an invalid release type ($Type)!", true);
      }

      if ($_GET["Type"] == $_GET["OldType"]){
         ThrowException("You did not change the version type before clicking 'Change'", true);
      }
      
      exec ("/usr/bin/sudo /orbital/util/orbsys --setexecutable=" . $_GET["Type"] );

      echo HTML::InsertRedirect("restart.php", 1);

      exit();
   }

?>


   <FORM action="./install_patch_file.php" method="post" enctype="multipart/form-data">
      <TABLE width=500 class=settings_table2>
      <TR><TH> 
         Upgrade System Software
      </TH><TH></TH></TR>

      <TR>
      <TD>
      Patch File:
         <INPUT TYPE="hidden" name="MAX_FILE_SIZE" value="100000000">
         <INPUT type="hidden" name="UpdateOrbital" value="">
         <input type=file name=userFile size=25>
      </TD>
      <TD>
         <INPUT type="Submit" name="AddPatchButton" value="Upload Patch" type="Get">
      </TD>
      </TD></TR>
      </TABLE>
   </FORM>

<?
   //
   // show the downgrade options
   //
   exec ("/orbital/util/orbsys --releases", $Releases);
   $CurrentRelease = exec ("/orbital/util/orbsys --currentrelease");      
   $Releases = array_reverse($Releases);
   $CurReleaseNum = array_search($CurrentRelease, $Releases, false);
   
   $Table = new HTML_TABLE();
   $ParamForm = new HTML_PARAMETER_FORM();
   echo 
      "<BR>",
      $Table->Begin("settings_table"),
      $ParamForm->Begin("ChangeRelease"),
      $Table->AddHeader1("Downgrade Release"),
      
      $Table->AddEntry2("Currently Running Version:&nbsp;&nbsp;" . $CurrentRelease, "row-1-center"),
      
      $Table->AddEntry("Releases:&nbsp;&nbsp;"  . 
                                     $ParamForm->AddDropdown("Release", $Releases, $Releases, $CurReleaseNum) ,
                                     $ParamForm->AddSubmit("ChangeRelease", "Change")),
      $ParamForm->End(),
      $Table->End();
      

   //
   // Show the "change to a debug version" options
   //
   if (!RUNNING_WINDOWS){
      exec ("/orbital/util/orbsys --currentexecutable", $CurrentExecutable);
      $CurrentExecutable = $CurrentExecutable[0];
   }else{
      $CurrentExecutable = "server";
   }

   $VersionTypesNames = array("Default", "Level 1", "Level 2", "Default MC", "Level 1 MC", "Level 2 MC");
   $VersionTypesValues = array("server", "level1", "level2", "server_mc", "level1_mc", "level2_mc");
   $Table = new HTML_TABLE();
   $ParamForm = new HTML_PARAMETER_FORM();
   echo
      "<BR><BR>", 
      $Table->Begin(),
      $ParamForm->Begin("ChangeVersionType"),
      $Table->AddHeader1("Change Version Type"),
      
      $Table->AddEntry("Type:&nbsp;&nbsp;"  . 
                                     $ParamForm->AddDropdown("Type", $VersionTypesNames, $VersionTypesValues, array_search($CurrentExecutable, $VersionTypesValues)) .
                                     "<INPUT type=hidden name=OldType value=$CurrentExecutable>",
                                     $ParamForm->AddSubmit("ChangeVersionType", "Change")),
      $ParamForm->End(),
      $Table->End();        

?>

</BODY>
</HTML>

<? include(HTTP_ROOT_INCLUDES_DIR ."footer.php"); ?>
