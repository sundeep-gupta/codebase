<?
   include("includes/header.php");
   $Auth->CheckRights(AUTH_LEVEL_VIEWER);

   if ( (isset($_GET["DisableHTTP"])) || (isset($_GET["EnableHTTP"]) ) )
   {
      $Auth->CheckRights(AUTH_LEVEL_ADMIN);

      if ( isset($_GET["DisableHTTP"]) ) { SetParameter("HTTP.PassThrough", true); }
      if ( isset($_GET["EnableHTTP"] ) )  { SetParameter("HTTP.PassThrough", false); }

      echo HTML::InsertRedirect("./http_config.php", 0);
   }
   $HTTPEnabled = !GetParameter("HTTP.PassThrough");
?>

<font class="pageheading">Configure Settings: HTTP</font><BR><BR>
<TABLE class="settings_table" width="410">

   <!-- SYSTEM STATUS BLOCK -->
   <TR>
   <TH>
    HTTP Acceleration:&nbsp;&nbsp;
   </TH>

   <TD>
         <FORM name="Enable" action="./http_config.php">

         <? if ($HTTPEnabled)
            { ?>
               <FONT color="blue" size="+1">NORMAL</FONT>&nbsp;&nbsp;
               <INPUT type="submit" name="DisableHTTP" value="Disable"></INPUT>
         <? }
            else
            {?>
               <FONT color="red" size="+1">DISABLED</FONT>&nbsp;&nbsp;
               <INPUT type="submit" name="EnableHTTP" value="Enable">
         <? } ?>
         </FORM>

   </TD>
   </TR>
</TABLE>
<BR>
<BR>

   <!-- Accelerated/Unaccelerated IPs -->
   <?
      echo "<font class=pageheading>HTTP Ports</font><BR><BR>";
      $Results = GetParameter("Ports.HTTP");

      if (isset($_GET["Set"])){
         $Results = $_GET["NewPorts"];
         SetParameter("Ports.HTTP", $Results);
      }

      $Form = new HTML_PARAMETER_FORM();
      echo
         "<TABLE class=settings_table>",
         $Form->Begin("HTTPPorts"),
         "<TR>",
            "<TH>Ports:</TH>" ,
            "<TD>", $Form->AddTextParam("Ports.HTTP", 15) . "<BR>Example: {80}</TD>",
            "<TD align=center>", $Form->AddSubmit() .
         "</TR>",
         $Form->End(),
         "</TABLE>";
   ?>

<? include(HTTP_ROOT_INCLUDES_DIR . "footer.php"); ?>

