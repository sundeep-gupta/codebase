<?
//
// Every WebUI page should include this header as well as footer.php
//
include_once('configure.php');
include_once("orbital_lib.php");
$Auth = new OD_AUTH();
$Auth->CheckLogin();
UpdateHttpRefreshSig();

$HaRunning            = GetParameter("HA.Enabled");
$HaPrimaryAddress     = GetParameter("HA.VRRP.Vmip");
$HaPrimaryAddress     = $HaPrimaryAddress["Dotted"];
$HaState              = GetSystemParam("HaState");
$HaSupported          = GetSystemParam("HaSupported");
$CompressionSupported = GetSystemParam("UI.Branding.CompressionSupported");
$CompressionLicensed  = GetLimit("COMPRESSION");
$DbcSupported         = GetSystemParam("UI.Branding.DbcSupported");
$DbcLicensed          = GetLimit("DBC");
$CifsSupported        = GetSystemParam("UI.Branding.CifsSupported");
$HTTPSupported        = true;
$CifsLicensed         = GetLimit("CIFS");
$EdgeModeSupported    = GetParameter("UI.Branding.PlatformSupportsEdge");


/*
basic function, has two tests currently, 'browser', returns shorthand for browser name,
or 'number', which returns browser number, or in mozilla's case, the rv number. You can
also use the 'full' parameter to get back both results at once, in an array.
if you need more precise browser information, get our full featured browser detection script:
http://TechPatterns.com/downloads/browser_detection_php_ar.txt
*/


function browser_detection( $which_test ) 
{
	// initialize variables
	$browser_name = '';
	$browser_number = '';
	// get userAgent string
	$browser_user_agent = ( isset( $_SERVER['HTTP_USER_AGENT'] ) ) ? strtolower( $_SERVER['HTTP_USER_AGENT'] ) : '';
	//pack browser array
	// values [0]= user agent identifier, lowercase, [1] = dom browser, [2] = shorthand for browser,
	$a_browser_types[] = array('opera', true, 'op' );
	$a_browser_types[] = array('msie', true, 'ie' );
	$a_browser_types[] = array('konqueror', true, 'konq' );
	$a_browser_types[] = array('safari', true, 'saf' );
	$a_browser_types[] = array('gecko', true, 'moz' );
	$a_browser_types[] = array('mozilla/4', false, 'ns4' );

	for ($i = 0; $i < count($a_browser_types); $i++)
	{
		$s_browser = $a_browser_types[$i][0];
		$b_dom = $a_browser_types[$i][1];
		$browser_name = $a_browser_types[$i][2];
		// if the string identifier is found in the string
		if (stristr($browser_user_agent, $s_browser)) 
		{
			// we are in this case actually searching for the 'rv' string, not the gecko string
			// this test will fail on Galeon, since it has no rv number. You can change this to 
			// searching for 'gecko' if you want, that will return the release date of the browser
			if ( $browser_name == 'moz' )
			{
				$s_browser = 'rv';
			}
			$browser_number = browser_version( $browser_user_agent, $s_browser );
			break;
		}
	}
	// which variable to return
	if ( $which_test == 'browser' )
	{
		return $browser_name;
	}
	elseif ( $which_test == 'number' )
	{
		return $browser_number;
	}

	/* this returns both values, then you only have to call the function once, and get
	 the information from the variable you have put it into when you called the function */
	elseif ( $which_test == 'full' )
	{
		$a_browser_info = array( $browser_name, $browser_number );
		return $a_browser_info;
	}
}

// function returns browser number or gecko rv number
// this function is called by above function, no need to mess with it unless you want to add more features
function browser_version( $browser_user_agent, $search_string )
{
	$string_length = 8;// this is the maximum  length to search for a version number
	//initialize browser number, will return '' if not found
	$browser_number = '';

	// which parameter is calling it determines what is returned
	$start_pos = strpos( $browser_user_agent, $search_string );
	
	// start the substring slice 1 space after the search string
	$start_pos += strlen( $search_string ) + 1;
	
	// slice out the largest piece that is numeric, going down to zero, if zero, function returns ''.
	for ( $i = $string_length; $i > 0 ; $i-- )
	{
		// is numeric makes sure that the whole substring is a number
		if ( is_numeric( substr( $browser_user_agent, $start_pos, $i ) ) )
		{
			$browser_number = substr( $browser_user_agent, $start_pos, $i );
			break;
		}
	}
	return $browser_number;
}


/* sample:
include('browser_detection.php');
$a_browser_data = browser_detection('full');
if ( $a_browser_data[0] !== 'msie' )
{
	execute the non msie conditions
}
else// if it is msie, that is
{
	if ( $a_browser_data[1] >= 5 )
	{
		execute the ie stuff
	}
}
*/
function DisplayAlertCount()
{
   if (IsServerRunning()){
      $NumAlerts = NumberOfOutstandingAlerts();
      if ($NumAlerts < 0) {
         $FatalErrors = 1;
         $NumAlerts = -$NumAlerts;
      } else {
         $FatalErrors = 0;
      }
      if ($NumAlerts != 0) {
      
         echo "<div style='position: absolute; left: 730px; top: 110px; width: 150px; font-size: 18px; color: white; font-weight: bold; font-family: Verdana, Arial, sans-serif;'>"; 
      
         echo "<a href='alerts.php'>";
         echo "$NumAlerts Alert(s)";         
         echo " <img src=\"./images/";
         if ($FatalErrors) {
            echo "icon-error.gif";
         } else {
            echo "icon-warning.gif";
         }
         echo "\"  border=\"0\" alt=\"Click Here For Detailed Error Information\"> </a></div>";
      }
   }
}

/*
 * Component mode means only the content section of
 * the page gets displayed and the header and sidebar are stripped off.
 * This is used with version 1.0 of the OMS
 */
function PageInComponentMode(){
   $InCompMode = false;

   if (isset($_GET["COMPONENT_MODE"])){
      $_SESSION["COMPONENT_MODE"] = $_GET["COMPONENT_MODE"];
      $InCompMode = $_GET["COMPONENT_MODE"];
   }elseif (isset($_SESSION["COMPONENT_MODE"])){
      $InCompMode = $_SESSION["COMPONENT_MODE"];
   }
      
   return $InCompMode;
}


?>

<?if (!PageInComponentMode()){?>
   <HTML>
   <HEAD>
   </HEAD>
<?}?>

   <HEAD>
   <META http-equiv="Pragma" content="no-cache">
   <META http-equiv="Cache-control" content="no-cache">
   <link rel=stylesheet type="text/css" href="./css/orbital.css">
   <script type="text/javascript" src="includes/library.js"></script>
   <script language="javascript" src="includes/form_validate.js"></script>
   </HEAD>

<BODY bgcolor="white"
   <?
      // If we are the slave in a VRRP cluster, and we are on a page
      // whose settings are controlled from the master, disable oll the 
      // buttons on this page
      if($HaRunning && $HaState != 'primary' && !defined('PAGE_IS_HA_CLUSTER_INDEPENDANT') 
         || defined('PAGE_REQUIRES_HA_SUPPORTED') && !$HaSupported){ 
         echo "onload='DisablePage()'";
      }
   ?>
   <?
      if(defined('PAGE_REQUIRES_COMPRESSION_LICENSE') && !$CompressionLicensed) {
         echo "onload='DisablePage()'";
      }
   ?>
   <?
      if(defined('PAGE_REQUIRES_CIFS_LICENSE') && !$CifsLicensed) {
         echo "onload='DisablePage()'";
      }
   ?>
>

<?if (PageInComponentMode()){
     echo "<table cellspacing=0><tr><td>"; 
     return;
  }
?>


<IMG src='./images/<? echo ProdLogo(); ?>' \>

<div style="position: absolute; left: 10px; top: 110px; font-size: 18px; color: #cccccc; font-weight: bold;font-family: Verdana, Arial, sans-serif;">
   <?=GetHostname()?> / <?=ProdName()?> <SMALL><SUP>TM</SUP></SMALL>
</div>
<!-- <br>&nbsp;<br>&nbsp; -->
<? 
    $startHeight = 50;
    if (browser_detection("browser") == "ie") {
	    $startHeight = 35;
    }
    echo '<IMG height=' . $startHeight . ' width="700" src="./images/spacer.gif" />';
?>

<TABLE width="860">
<TR valign=top>
<TD>
   <TABLE cellspacing=0 width=100%>
   <TR width=100% >
      <TD valign=top cellspacing=0 cellpadding=0>
         <?
         DisplayAlertCount();
         include("sidebar.php");
         ?>
      </TD>
      <TD valign=top cellspacing=0 cellpadding=0  width=100%>
         <TABLE cellspacing=0 cellpadding=0><TR><TD width=600></TD></TR></TABLE>
<?
   DisplayRebootRequired();
   DisplayPassthroughState();
   DisplayLicenseExpirationCountdown();

   if($HaRunning && $HaState != 'primary' && !defined('PAGE_IS_HA_CLUSTER_INDEPENDANT')){ 
      echo "<DIV class=giant_warning>\n";
      echo "<TABLE width=100%>\n";
      echo "<TR><TD>\n";
      echo "Warning: This unit is the currently serving as the Secondary unit in a ";
      echo "High Availability Configuration. All ";
      echo "settings on this page should be modified on the High Availability Primary ";
      echo "unit. ";
      echo "<A href='http://$HaPrimaryAddress'>Click here to go to the Primary unit.</A>";
      echo "</TD></TR>\n";
      echo "</TABLE>\n";
      echo "</DIV>\n";
      echo "<BR>\n";           
   }
     
   if(defined('PAGE_REQUIRES_COMPRESSION_LICENSE') && !$CompressionLicensed ||
      defined('PAGE_REQUIRES_CIFS_LICENSE') && !$CifsLicensed) {
      echo "<DIV class=giant_warning>\n";
      echo "<TABLE width=100%>\n";
      echo "<TR><TD>\n";
      echo "Features on this page are unavailable with current license.";
      echo "</TD></TR>\n";
      echo "</TABLE>\n";
      echo "</DIV>\n";
      echo "<BR>\n";           
   }

   if (!defined('DONT_REQUIRE_RUNNING_SERVER') )
   {
      if (!IsServerRunning())
      {
         echo "<BR><BR>";
         echo "<center><img src='./images/warning-large.gif'></center>";
         ThrowException("WANScaler process is not running!", false);
         ThrowException("(Please try restarting your WANScaler unit)", false);
         echo " </td> <tr> </table>";
         include("footer.php");
         exit();
      }
   }
?>
