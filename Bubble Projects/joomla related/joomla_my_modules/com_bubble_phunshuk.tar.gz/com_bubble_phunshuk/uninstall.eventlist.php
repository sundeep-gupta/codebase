
<?php
function com_uninstall()
{
?>
<p>
    You have successfully removed the movie lister component and all of its
    database tables.
</p>
<?php
}
?>