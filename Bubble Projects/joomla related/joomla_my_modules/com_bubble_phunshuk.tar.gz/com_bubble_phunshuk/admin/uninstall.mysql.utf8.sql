DROP TABLE IF EXISTS `#__phunshuk_account`;
DROP TABLE IF EXISTS `#__phunshuk_menu`;
DROP TABLE IF EXISTS `#__phunshuk_subscription`;
DROP TABLE IF EXISTS `#__phunshuk_delivered`;
