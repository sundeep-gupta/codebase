//Copyright (C) 2007 McAfee, Inc.  All rights reserved.
	// global variables   
	var swapper;
	var adder1;
	var exclude1;
	var ERR = new Array(); //Error list
    var MAXURLLENGTH = 1024 // the maximum number of charcter that can be handled by epo interface 
    // the default function called when a page is loaded
	var g_szExcludedFileName;
	var g_MaxPathLength = 1024;
	var	ENTRYVERYLONG = -2;
	var INVALIDENTRY = -1;
	var oasAVPrimaryELements = ["wfclean","wfdelete","wfnotify","wfquarantine"];
	var oasAVsecondaryAll = ["oassecwfdelete","oassecwfnotify","oassecwfquarantine"];
	var oasASPrimaryElements = ["oasASPrclean","oasASPrdelete","oasASPrnotify","oasASPrquarantine"];
	var oasASSecondaryAll = ["oasASSecdelete","oasASSecnotify","oasASSecquarantine"];
	var odsAVPrimaryElements = ["odswfclean","odswfdelete","odswfnotify","odswfquarantine"];
	var odsAVsecondaryAll = ["odssecwfdelete","odssecwfnotify","odssecwfquarantine"];
	var odsASPrimaryElements = ["odsASPrclean","odsASPrdelete","odsASPrnotify","odsASPrquarantine"];
	var odsASsecondaryAll = ["odsASSecdelete","odsASSecnotify","odsASSecquarantine"];
	

	// this is the function called when an  page load occurs
	    OrionCore.addLoadHandler(function()
	{   _setTabStrip();
		_setDefaults();
	//	_toggleEntries();
		//_setButtonEnabler();
		epoEnableApplyButton();// enable the save button on ui launch 
		OrionForm.setStateChangeHandler(stateChangeHandler);
	});
	
	// This is used by the actions tab to determine which secondary option to show.
function _toggleSecondary(me)
{
    var map = 
	{
        "wfnotify":["oassecwfnotify"],
        "wfclean":["oassecwfquarantine", "oassecwfdelete", "oassecwfnotify"],
        "wfdelete":["oassecwfnotify"],
        "wfquarantine":["oassecwfdelete", "oassecwfnotify"],
        "oasASPrclean":["oasASSecquarantine", "oasASSecdelete", "oasASSecnotify"],
		"oasASPrdelete":["oasASSecnotify"],
		"oasASPrnotify":["oasASSecnotify"],
		"oasASPrquarantine":["oasASSecdelete", "oasASSecnotify"],
		"odswfclean":["odssecwfquarantine", "odssecwfdelete","odssecwfnotify"],
		"odswfdelete":["odssecwfnotify"],
		"odswfnotify":["odssecwfnotify"],
		"odswfquarantine":["odssecwfdelete","odssecwfnotify"],
		"odsASPrclean":["odsASSecquarantine", "odsASSecdelete","odsASSecnotify"],
		"odsASPrdelete":["odsASSecnotify"],
		"odsASPrnotify":["odsASSecnotify"],
		"odsASPrquarantine":["odsASSecdelete","odsASSecnotify"]
    };

    var start ;
	var name = me.getAttribute("name");
	if ( name == "oasASAction" )
	{
	 start = oasASSecondaryAll;
	}
	else if ( name == "oasAction" )
	{
	start = oasAVsecondaryAll;
	}
	else  if ( name == "odsAction" )
	{
	start = odsAVsecondaryAll;
	}
	else
	{
		start = odsASsecondaryAll;
	}
	
	
    for(var a=0;a<start.length;a++)
	{
        var get = document.getElementById(start[a]);
        get.checked = false;
        OrionCore.setEnabled(get,false);
    }

    var id = me.getAttribute("id");
    var end = map[id];
    var ck = 0;
    for(var b=0;b<end.length;b++)
	{
	  	if ( b == 0)
			{ 
			document.getElementById(end[b]).checked = true;
			}
		if(end.length == 1)
		{
		break;
		}
	
        OrionCore.setEnabled(document.getElementById(end[b]),true);
        ck++;
    }
    if(ck < 2){ //auto click single option
       document.getElementById(end[0]).checked = true;
    }

}

	
	
	function validatepolicy()
	{
	 stateChangeHandler(true, valid);
	
	}
	
function stateChangeHandler( isDirty, isValid )
{
    if( isDirty && isValid )
    {
        epoEnableApplyButton();
    }
    else
    {
        epoDisableApplyButton();    
    }
}

// This function runs on page load. It runs through the form elements
// and adds an onchange event to enable the save button. Alternatively
// it adds a validation event if the field calls for it.
function _setButtonEnabler(){
    var formy = document.forms[0];
    for(var i=0;i<formy.elements.length;i++)
	{
            OrionEvent.registerHandler(formy.elements[i],epoEnableApplyButton,"","change",true);
        
    }
}

// This is the default funciton called by the save button on the UI
function epoApplyPolicySettings(){
	// Submit
	 	var returnvalue = true ;
	if ( finalvalidate() == true )
	{
		collectinputvalues(adder1,"ExcludedItems");
		OrionCore.doAsyncFormAction("/VSCANMAC9000/save.do", null,  _epoApplyPolicySuccess, _epoApplyPolicyFailure);
		return true;
	}
	else
	{
		return false;
	}
}

function collectinputvalues(obj,which)
{

   var list = obj.getRows();
   var save = new Array();
   var exclusionState=new Array();
   for(i in list){
        var its =  document.getElementById("excl_"+i).value;
		var oasexcl = document.getElementById("oas_"+i).checked;
        var odsexcl = document.getElementById("ods_"+i).checked;
		var exclcount=-1;
		if(oasexcl && odsexcl)
		{
		count = 2;
		}
		else if (oasexcl)
		{
		count = 0
		}
		else if (odsexcl)
		{
		count = 1;
		}
		else
		{
		continue;
		}
		
		if(its.length > 0)
		{   
		    exclusionState.push(count);
            save.push(its);
        }
    }
	document.getElementById("dwExclusionCount").value = save.length;
    document.getElementById(which).value = save.join("#");
	document.getElementById("ExcludedStatus").value = exclusionState.join(",");
}

function checkforduplicateentry(me)
{  
  var list = adder1.getRows();
  for(i in list)
    {
       if (document.getElementById("excl_"+i) != me  && me.value == document.getElementById("excl_"+i).value )
		{
		 return true;
		}
	}
	   return false;
}

// Displays the Exclusions AddWidget if the checkbox is checked
function _toggleWhatNot()
{
  
}

function _disableifcleanfailed()
{
	
}


function _validateFields()
{
return true;
}


