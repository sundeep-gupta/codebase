//Copyright (C) 2007 McAfee, Inc.  All rights reserved.
function getValidPath(inputvalue)
{ 
var is_protocol_ok = inputvalue.indexOf('/');
	if(is_protocol_ok == -1)
	{	
	stateChangeHandler(true, false);
	return false;

	}
	stateChangeHandler(true, true);
   	return true;
}