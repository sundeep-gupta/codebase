//Copyright (C) 2007 McAfee, Inc.  All rights reserved.
// setting the global variables here
var g_szExcludedFileName;
var g_MaxPathLength = 1024;
var	ENTRYVERYLONG = -2;
var INVALIDENTRY = -1;
var odsaddwidget;
// Core Load handler for things to run when the page loads.
OrionCore.addLoadHandler(function()
	{
    _setodsDefaults();
    });

	
function _setodsDefaults()
{	
	var addvar = "test" ;
    odsaddwidget = new majic.AddWidget(
	{
	    container:"odsaddwidget",
		content:document.getElementById("odsaddwidgetcontent").innerHTML,
		addCallback:function(row){
		this.addValidator(row,"ods_@ID",getValidPath);}
	}
	);
	
	var x=0; // initialised to zero just for safety
	x=document.getElementById("NumInclusion").value;
	var odsaddwidgetlist = document.getElementById("OdsValue").value.split(":");
	for(var i=0;i<odsaddwidgetlist.length;i++)
	{
	    if(odsaddwidgetlist[i].length>0)
		{
	        odsaddwidget.add();
			odsaddwidget.rowDefaults({
	            "ods_@ID":odsaddwidgetlist[i]
	        });
	        x++;
	    }
	}
	if(x==0){
		odsaddwidget.add();
	}
		
		
		OrionForm.setStateChangeHandler(stateChangeHandler);	
}
function validateTask(input)
{
  var inputvalue = input.value;
    var is_protocol_ok = -1;
	g_szExcludedFileName = inputvalue;
	is_protocol_ok = g_szExcludedFileName.indexOf('/');
	if(is_protocol_ok == -1)
	{	
	  return false;
	   stateChangeHandler(true, false);
	}
   	return true;
	 stateChangeHandler(true, true);
}

function stateChangeHandler( isDirty, isValid )
{
    OrionWizard.setNextButtonEnabled(isValid);
}


function checkforduplicateentry(me)
{  
  var list = odsaddwidget.getRows();
  for(i in list)
    {
       if (document.getElementById("ods_"+i) != me  && me.value == document.getElementById("ods_"+i).value )
		{
		 return true;
		}
	}
	   return false;

}

function epoOnBeforeSubmit()
{
var returnvalue = true ;
if ( finalvalidate() == true )
	{
	collectinputvalues();
	return true;
	}
else
	{
	return false;
	}



}
// collects all the input from the add widget and save it into an database
function collectinputvalues()
{ 
   var list = odsaddwidget.getRows();
   var save = new Array();
   for(i in list){
        var its =  document.getElementById("ods_"+i).value;
        
		if(its.length > 0)
		{
            save.push(its);
        }
    }
	document.getElementById("NumInclusion").value = save.length;
    document.getElementById("OdsValue").value = save.join(":");
}

