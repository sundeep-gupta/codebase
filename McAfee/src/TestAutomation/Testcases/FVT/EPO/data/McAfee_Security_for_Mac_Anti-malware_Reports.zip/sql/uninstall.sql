IF EXISTS ( SELECT name FROM sysobjects 
			 WHERE name = 'EPOReports_AddMSMEvent'
			   AND type = 'P' )
	DROP PROCEDURE dbo.EPOReports_AddMSMEvent
GO
-----------------------------------Copyright (C) 2007 McAfee, Inc.  All rights reserved.-------------------------------------------
