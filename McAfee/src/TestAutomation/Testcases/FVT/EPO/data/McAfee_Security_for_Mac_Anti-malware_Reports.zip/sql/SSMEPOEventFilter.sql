--Copyright (C) 2009 McAfee, Inc. All Rights Reserved
-- Author: Kumar Kantheti
-------------------EPO Event Filters-------------------

declare @category int;
declare @eventID int;
declare @flag int;

select @category = EventCategoryID from EPOEventCategory where Name = 'APPLICATION_EXECUTION'
select @eventID = 20601
select @flag = 0x0000001

IF exists(select EventId from EPOEventFilter where EventId=@eventID)
    update EPOEventFilter set EventCategory=@category, HideInFilterTab=0, Flag=@flag where EventId=@eventID;
ELSE
    insert into EPOEventFilter (EventId, Flag, EventCategory, HideInFilterTab) 
        values(@eventID, @flag, @category, 0)


select @category = EventCategoryID from EPOEventCategory where Name = 'NETWORK_EXECUTION'
select @eventID = 20602
select @flag = 0x0000001

IF exists(select EventId from EPOEventFilter where EventId=@eventID)
    update EPOEventFilter set EventCategory=@category, HideInFilterTab=0, Flag=@flag where EventId=@eventID;
ELSE
    insert into EPOEventFilter (EventId, Flag, EventCategory, HideInFilterTab) 
        values(@eventID, @flag, @category, 0)

GO