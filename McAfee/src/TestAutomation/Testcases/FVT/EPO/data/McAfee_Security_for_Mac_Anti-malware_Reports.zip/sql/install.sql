IF EXISTS ( SELECT name FROM sysobjects 
			 WHERE name = 'EPOReports_AddMSMEvent'
			   AND type = 'P' )
	DROP PROCEDURE dbo.EPOReports_AddMSMEvent
GO
-----------------------------------EPOReports_AddMSMEvent-------------------------------------------
-----------------------------------Copyright (C) 2007 McAfee, Inc.  All rights reserved.-------------------------------------------
CREATE  PROCEDURE dbo.EPOReports_AddMSMEvent
(
	@ThreatEventID int,
	@AgentGUID uniqueidentifier,
	@Analyzer nvarchar(16),
	@AnalyzerName nvarchar(64),
	@AnalyzerVersion nvarchar(20),
	@DetectedUTC datetime,
	@ThreatSeverity tinyint,
	@AnalyzerHostName nvarchar(128),
	@AnalyzerIPV4 int,
	@AnalyzerMAC nvarchar(16),
	@AnalyzerEngineVersion nvarchar(20),
	@TargetIPV4 int,
	@AnalyzerDATVersion nvarchar(20),
	@ThreatActionTaken nvarchar(24),
	@ThreatName nvarchar(128),
	@TargetFileName nvarchar(266),
	@ThreatCategory nvarchar(128),
	@TargetUserName nvarchar(128),
	@TargetPort smallint,
	@TargetProtocol nvarchar(128),
	@TargetProcessName  nvarchar(128),
	@ThreatType nvarchar(32),
	@ThreatHandled tinyint
)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @EventID INT;
	IF (@TargetPort = -1)
	BEGIN
	EXEC EPOEvents_InsertEvent2
			DEFAULT,				-- @ServerID nvarchar(16) = 'ePO_SERVERNAME',
			@DetectedUTC,				-- @DetectedUTC datetime,
			@AgentGUID,				-- @AgentGUID uniqueidentifier,			
			@Analyzer,				-- @Analyzer nvarchar(16),
			@AnalyzerName,				-- @AnalyzerName nvarchar(64),
			@AnalyzerVersion,			-- @AnalyzerVersion nvarchar(20),         
			@AnalyzerHostName,			-- @AnalyzerHostName nvarchar(128),
			@AnalyzerIPV4,				-- @AnalyzerIPV4 int,
			DEFAULT,				-- @AnalyzerIPV6 binary(16) = NULL,
			@AnalyzerMAC,				-- @AnalyzerMAC nvarchar(16) = NULL,
			@AnalyzerDATVersion,			-- @AnalyzerDATVersion nvarchar(20),
			@AnalyzerEngineVersion,			-- @AnalyzerEngineVersion nvarchar(20),
			@TargetProcessName,			-- @AnalyzerDetectionMethod nvarchar(20) = NULL,
			DEFAULT,				-- @SourceHostName nvarchar(128),
			DEFAULT,				-- @SourceIPV4 int = NULL,
			DEFAULT,				-- @SourceIPV6 binary(16) = NULL,
			DEFAULT,				-- @SourceMAC nvarchar(16) = NULL,
			DEFAULT,				-- @SourceUserName nvarchar(128) = NULL,
			DEFAULT,				-- @SourceProcessName nvarchar(128) = NULL,
			DEFAULT,				-- @SourceURL nvarchar(256) = NULL,    		
			@AnalyzerHostName,			-- @TargetHostName nvarchar(128) = NULL,
			NULL,					-- @TargetIPV4 int = NULL,
			DEFAULT,				-- @TargetIPV6 binary(16) = NULL,
			DEFAULT,				-- @TargetMAC nvarchar(16) = NULL,
			@TargetUserName,			-- @TargetUserName nvarchar(128) = NULL,
			NULL,					-- @TargetPort smallint = NULL,
			@TargetProtocol,			-- @TargetProtocol nvarchar(16) = NULL,
			DEFAULT,				-- @TargetProcessName nvarchar(128) = NULL,
			@TargetFileName,			-- @TargetFileName nvarchar(266) = NULL,
			@ThreatCategory,			-- @ThreatCategory nvarchar(128),    ==> @SignatureID???
			@ThreatEventID,				-- @ThreatEventID int,
			@ThreatName,				-- @ThreatName nvarchar(128),
			@ThreatType,				-- @ThreatType nvarchar(32),
			@ThreatSeverity,			-- @ThreatSeverity tinyint = 1,
			@ThreatActionTaken,			-- @ThreatActionTaken nvarchar(24) = 'none',
			@ThreatHandled,				-- @ThreatHandled tinyint = 1,
			@EventID OUTPUT,			-- @AutoID int = NULL ,
			DEFAULT;				-- @AutoGUID uniqueidentifier = NULL OUTPUT
	  END
	ELSE
	 BEGIN
		EXEC EPOEvents_InsertEvent2
			DEFAULT,				-- @ServerID nvarchar(16) = 'ePO_SERVERNAME',
			@DetectedUTC,				-- @DetectedUTC datetime,
			@AgentGUID,				-- @AgentGUID uniqueidentifier,			
			@Analyzer,				-- @Analyzer nvarchar(16),
			@AnalyzerName,				-- @AnalyzerName nvarchar(64),
			@AnalyzerVersion,			-- @AnalyzerVersion nvarchar(20),         
			@AnalyzerHostName,			-- @AnalyzerHostName nvarchar(128),
			@AnalyzerIPV4,				-- @AnalyzerIPV4 int,
			DEFAULT,				-- @AnalyzerIPV6 binary(16) = NULL,
			@AnalyzerMAC,				-- @AnalyzerMAC nvarchar(16) = NULL,
			@AnalyzerDATVersion,			-- @AnalyzerDATVersion nvarchar(20),
			@AnalyzerEngineVersion,			-- @AnalyzerEngineVersion nvarchar(20),
			@TargetProcessName,			-- @AnalyzerDetectionMethod nvarchar(20) = NULL,
			DEFAULT,				-- @SourceHostName nvarchar(128),
			DEFAULT,				-- @SourceIPV4 int = NULL,
			DEFAULT,				-- @SourceIPV6 binary(16) = NULL,
			DEFAULT,				-- @SourceMAC nvarchar(16) = NULL,
			DEFAULT,				-- @SourceUserName nvarchar(128) = NULL,
			DEFAULT,				-- @SourceProcessName nvarchar(128) = NULL,
			DEFAULT,				-- @SourceURL nvarchar(256) = NULL,    		
			@AnalyzerHostName,			-- @TargetHostName nvarchar(128) = NULL,
			@TargetIPV4,				-- @TargetIPV4 int = NULL,
			DEFAULT,				-- @TargetIPV6 binary(16) = NULL,
			DEFAULT,				-- @TargetMAC nvarchar(16) = NULL,
			@TargetUserName,			-- @TargetUserName nvarchar(128) = NULL,
			@TargetPort,				-- @TargetPort smallint = NULL,
			@TargetProtocol,			-- @TargetProtocol nvarchar(16) = NULL,
			DEFAULT,				-- @TargetProcessName nvarchar(128) = NULL,
			@TargetFileName,			-- @TargetFileName nvarchar(266) = NULL,
			@ThreatCategory,			-- @ThreatCategory nvarchar(128),    ==> @SignatureID???
			@ThreatEventID,				-- @ThreatEventID int,
			@ThreatName,				-- @ThreatName nvarchar(128),
			@ThreatType,				-- @ThreatType nvarchar(32),
			@ThreatSeverity,			-- @ThreatSeverity tinyint = 1,
			@ThreatActionTaken,			-- @ThreatActionTaken nvarchar(24) = 'none',
			@ThreatHandled,				-- @ThreatHandled tinyint = 1,
			@EventID OUTPUT,			-- @AutoID int = NULL ,
			DEFAULT;				-- @AutoGUID uniqueidentifier = NULL OUTPUT
	  END 		  	
    	SELECT @EventID AS nResult;	
END
GO