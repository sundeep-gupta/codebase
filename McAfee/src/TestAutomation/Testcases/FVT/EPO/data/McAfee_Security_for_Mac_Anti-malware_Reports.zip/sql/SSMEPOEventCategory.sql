-- Copyright (C) 2009 McAfee, Inc. All Rights Reserved
-- Author: Kumar Kantheti

IF not exists(select EventCategoryID from EPOEventCategory where Name = 'APPLICATION_EXECUTION')
    insert into EPOEventCategory (Name, AssociateThreat)
        values('APPLICATION_EXECUTION', 0);
IF not exists(select EventCategoryID from EPOEventCategory where Name = 'NETWORK_EXECUTION')
    insert into EPOEventCategory (Name, AssociateThreat)
        values('NETWORK_EXECUTION', 0);

GO