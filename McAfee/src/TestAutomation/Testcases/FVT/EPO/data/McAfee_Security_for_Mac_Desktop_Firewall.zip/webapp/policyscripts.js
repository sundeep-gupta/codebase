//Copyright (C) 2007 McAfee, Inc.  All rights reserved.
// global variables   
   var trustedGrpArray = new Array();
	var rulesArray = new Array();
	var selectRuleRowFlag = false;

var firewallRulesList = null;
var firewallTrustedGroupList = null;
var firewallTrustedIpAddressList = null;	
	var swapper;
	
	// This is used by the actions tab to determine which secondary option to show.
function _toggleSecondary(me)
{

}

	function IPAddresses()
	{
		this.id=-1;
		this.ipaddress="";
	}

	function TrsustedGruops()
	{
		this.id=-1;
		this.groupName="";
		this.ipAddressList = new Array();
	}	

	function Rule()
	{
		this.id=-1;
		this.name="";
		this.action="";
		this.protocol="";
		this.direction="";
		this.Interface="";
		this.srcIp="";
		this.srcOtherIp="";
		this.dstIp="";
		this.dstOtherIp="";
		this.srcPort="";
		this.dstPort="";
		this.ActionId="";
		this.directionId=""
	}	

	function validatepolicy()
	{
	 stateChangeHandler(true, valid);
	
	}
	
function stateChangeHandler( isDirty, isValid )
{
    if( isDirty && isValid )
    {
        epoEnableApplyButton();
    }
    else
    {
        epoDisableApplyButton();    
    }
}

// This function runs on page load. It runs through the form elements
// and adds an onchange event to enable the save button. Alternatively
// it adds a validation event if the field calls for it.
function _setButtonEnabler(){
    var formy = document.forms[0];
    for(var i=0;i<formy.elements.length;i++)
	{
            OrionEvent.registerHandler(formy.elements[i],epoEnableApplyButton,"","change",true);
        
    }
}

// This is the default funciton called by the save button on the UI
function epoApplyPolicySettings()
{
	// Submit
 	var returnvalue = true ;		
	if ( finalvalidate() == true )
	{
        var ipAddresses = convertIpAddressesInString();
        var groupNames = convertGroupNamesInString();
		var rules = convertRulesInString();
        document.getElementById("groupNameList").value = groupNames;
        document.getElementById("ipAddressesList").value = ipAddresses;
		document.getElementById("rulesList").value = rules;
		document.getElementById("rulesListLength").value = rulesArray.length;
		document.getElementById("groupListLength").value = trustedGrpArray.length;
        OrionCore.doAsyncFormAction("/FWALLMAC1000/save.do", null,  _epoApplyPolicySuccess, _epoApplyPolicyFailure);
		return true;
	}
	else
	{
		return false;
	}
}

function convertRulesInString()
{
	var str="";
	if(rulesArray.length > 0)
	{
		var save = new Array();
		for(i=0;i<rulesArray.length;i++)
		{
			var innerSave = new Array();
			innerSave.push(rulesArray[i].name);
			innerSave.push(rulesArray[i].action);
			innerSave.push(rulesArray[i].protocol);
			innerSave.push(rulesArray[i].direction);
			if(rulesArray[i].Interface == "")
			{
				innerSave.push("all");		
			}
			else
			{
				innerSave.push(rulesArray[i].Interface);
			}
			innerSave.push(rulesArray[i].srcOtherIp);
			innerSave.push(rulesArray[i].dstOtherIp);
			innerSave.push(rulesArray[i].srcPort);
			innerSave.push(rulesArray[i].dstPort);
			innerSave.push(rulesArray[i].srcIp); 
			innerSave.push(rulesArray[i].dstIp);
			var its = innerSave.join("#");
			if(its.length > 0)
			{
				save.push(its);
			}
		}	
		str = save.join("!");
	}
	return str;
}

function convertIpAddressesInString()
{
	var str = "";
	if(trustedGrpArray.length > 0)
	{
		var finalSave = new Array() ;
		for(var i=0; i < trustedGrpArray.length; i++)
		{
			var save = new Array();
			if(trustedGrpArray[i].ipAddressList.length == 0)
			{
				save.push("0");
			}
			else
			{
				for(j=0;j<trustedGrpArray[i].ipAddressList.length;j++)
				{
					var its = trustedGrpArray[i].ipAddressList[j].ipaddress;
					if(its.length > 0)
					{
						save.push(its);
					}
				}
			}
			finalSave.push(save.join("#"));
		}
		str =  finalSave.join("!")
	}
    return str;
}

function convertGroupNamesInString()
{
	var str = "";
	if(trustedGrpArray.length > 0)
	{	
		var save = new Array();
		 for(var i=0; i < trustedGrpArray.length; i++)
		 {
			var its = trustedGrpArray[i].groupName;
			if(its.length > 0)
			{
				save.push(its);
			}
		 }
		str =  save.join("!");
	}
    return str;
}

function checkforduplicateentry(me)
{  
   
}

// Displays the Exclusions AddWidget if the checkbox is checked
function _toggleWhatNot()
{
  
}

function _disableifcleanfailed()
{
	
}


function _validateFields()
{
return true;
}
