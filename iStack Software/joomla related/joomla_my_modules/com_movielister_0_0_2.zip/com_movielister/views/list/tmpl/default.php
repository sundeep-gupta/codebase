<table width="100%" border="0" cellspacing="0" cellpadding="0">
<tr>
<th>Name</th>
<td><?php echo "My First View"; ?></td>
</tr>
<tr>
<th>Description</th>
<td><?php echo "I am happy";?></td>
</tr>
</table>