DROP TABLE IF EXISTS `#__movielister_movies`;
DROP TABLE IF EXISTS `#__movielister_cinemas`;
DROP TABLE IF EXISTS `#__movielister`;
DROP TABLE IF EXISTS `#__movielister_play`;

