<?php
/**
* @package	[ccNewsletter]
* @version      [1.0.7]
* @author       Chill Creations <info@chillcreations.com>
* @link         http://www.chillcreations.com
* @copyright	Copyright (C) [2008 - 2010] Chill Creations
* @license	GNU/GPL, Version 2, June 1991
*/

defined('_JEXEC') or die('Restricted access');
?>

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.


ccNewsletter includes or is derivative of works distributed under GPL license.
The full text for the GPL license can be found in the LICENSE.php file.
The original copyright notices have been preserved within the respective files and or packages.  Please refer to the specific files and/or packages for more detailed information about the authors, copyrights, and licenses.
---------------------------------------------------------------------------------------------

Communicator
-------
Author: Stefan Granholm, Erik Damke
Copyright: Copyright 2008 Stefan Granholm, Copyright 2009 Erik Damke - All rights reserved.


ccNewsletter elodig hack
-------
Author: Elodig
Copyright: Copyright (C) Copyright 2010 Elodig- All rights reserved


